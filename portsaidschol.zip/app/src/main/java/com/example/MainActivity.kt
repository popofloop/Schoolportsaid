package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch
import com.example.service.GeolocationPermissionService
import com.example.ui.viewmodel.BusLocationData
import com.example.ui.viewmodel.BusLocationHistoryPoint
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.StudentStatusEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.CommuteLogEntity
import com.example.data.local.entity.TimelinePostEntity
import com.example.data.local.entity.GroupEntity
import com.example.data.local.entity.GroupMessageEntity
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.SchoolViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private val viewModel: SchoolViewModel by viewModels()

    @OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request permissions safely
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(300)) with fadeOut(animationSpec = tween(300))
                            },
                            label = "screen_transition"
                        ) { screen ->
                            when (screen) {
                                "WELCOME" -> WelcomeScreen(viewModel, currentLanguage)
                                "AUTH" -> AuthScreen(viewModel, currentLanguage)
                                "ROUTE_SETUP" -> RouteSetupScreen(viewModel, currentLanguage)
                                "DASHBOARD" -> DashboardScreen(viewModel, currentLanguage)
                                "CHAT" -> ChatScreen(viewModel, currentLanguage)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Translations map helper
val translations = mapOf(
    "ar" to mapOf(
        "app_title" to "WE School, Port Said",
        "welcome" to "مرحباً بكم في مدرسة WE التكنولوجية ببورسعيد",
        "tagline" to "النظام المتكامل لربط أولياء الأمور، المدرسين، والطلاب بمتابعة ذكية وآمنة.",
        "sign_in_google" to "تسجيل الدخول بواسطة Google",
        "register_google" to "إنشاء حساب جديد",
        "phone_number" to "رقم الهاتف والتحقق",
        "select_role" to "اختر نوع الحساب",
        "role_parent" to "ولي أمر طالب",
        "role_teacher" to "معلم بالمدرسة",
        "role_student" to "طالب بالمدرسة",
        "role_driver" to "سائق الحافلة المدرسية",
        "full_name" to "الاسم الكامل",
        "email" to "البريد الإلكتروني",
        "next" to "متابعة",
        "save" to "حفظ",
        "cancel" to "إلغاء",
        "linked_student_id" to "كود الطالب لربطه بحسابك",
        "student_grade" to "الصف الدراسي التكنولوجي",
        "grade_1" to "الصف الأول التكنولوجي",
        "grade_2" to "الصف الثاني التكنولوجي",
        "grade_3" to "الصف الثالث التكنولوجي",
        "student_age" to "العمر",
        "student_gender" to "الجنس",
        "gender_male" to "ذكر",
        "gender_female" to "أنثى",
        "route_setup_title" to "ضبط خط السير المناسب (لمرة واحدة)",
        "route_setup_desc" to "اضغط على الخريطة لتحديد موقع المنزل وموقع مدرسة WE بورسعيد لرسم خط سير الطالب التلقائي.",
        "set_home" to "اضغط لتحديد مكان المنزل",
        "set_school" to "اضغط لتحديد مكان المدرسة",
        "set_route_btn" to "تأكيد وحفظ خط السير التكنولوجي",
        "dashboard" to "الرئيسية",
        "chat" to "المراسلة الفورية",
        "gps_active" to "خدمة GPS المدرسية: نشطة الآن",
        "gps_inactive" to "خدمة GPS المدرسية: متوقفة مؤقتاً",
        "gps_rules" to "الخدمة تعمل فقط أيام الدراسة (الأحد - الخميس) من 7:30 ص إلى 3:00 م",
        "deviated_alert" to "🚨 انذار: الطالب خارج خط السير المحدد!",
        "sim_start" to "بدء محاكاة خط سير الطالب",
        "sim_stop" to "إيقاف المحاكاة والمتابعة",
        "student_profile" to "بيانات الملف الشخصي للطالب",
        "notifications" to "سجل إشعارات وتنبيهات الحركة",
        "school_loc" to "موقع المدرسة",
        "home_loc" to "موقع المنزل",
        "voice_hold" to "اضغط للتحدث (فويس نوت)",
        "voice_recording" to "جاري التسجيل... اضغط للإرسال",
        "text_hint" to "اكتب رسالتك للمدرس أو ولي الأمر...",
        "send" to "إرسال",
        "parent_dashboard" to "لوحة تحكم ولي الأمر",
        "teacher_dashboard" to "لوحة تحكم المعلم",
        "student_dashboard" to "لوحة تحكم الطالب",
        "all_students" to "قائمة طلاب المدرسة",
        "chat_with" to "محادثة سريعة مع ",
        "no_notifications" to "لا توجد إشعارات حركة جديدة حالياً.",
        "linked_status" to "حالة المتابعة:",
        "at_school" to "وصل للمدرسة بأمان ✅",
        "at_home" to "متواجد بالمنزل حالياً 🏠",
        "on_way" to "يسير في خط السير المحدد 🚶‍♂️",
        "deviated_status" to "🚨 انحرف عن خط السير!",
        "setup_home_school" to "تحديد الموقعين على الخريطة أدناه:",
        "bus_progress" to "تقدّم مسار حافلة المدرسة",
        "traffic_level" to "حالة المرور الجارية:",
        "normal_traffic" to "مرور خفيف",
        "moderate_traffic" to "ازدحام متوسط",
        "heavy_traffic" to "ازدحام كثيف",
        "blocked_traffic" to "طريق مغلق",
        "eta_label" to "الوصول المتوقع خلال:",
        "eta_arrived" to "وصل للمدرسة",
        "eta_calc_title" to "🚍 تعقب الوصول الذكي لحافلة المدرسة",
        "weather_level" to "حالة الطقس المباشرة:",
        "sunny_weather" to "مشمس ☀️",
        "rainy_weather" to "ممطر 🌧️",
        "foggy_weather" to "ضباب 🌫️",
        "sandstorm_weather" to "عاصفة 🌪️"
    ),
    "en" to mapOf(
        "app_title" to "WE School, Port Said",
        "welcome" to "Welcome to WE School, Port Said",
        "tagline" to "Integrated platform connecting parents, teachers, and students with smart GPS tracking.",
        "sign_in_google" to "Sign In with Google",
        "register_google" to "Create New Account",
        "phone_number" to "Phone Number & Verification",
        "select_role" to "Choose Account Type",
        "role_parent" to "Parent",
        "role_teacher" to "Teacher",
        "role_student" to "Student",
        "role_driver" to "School Bus Driver",
        "full_name" to "Full Name",
        "email" to "Email Address",
        "next" to "Continue",
        "save" to "Save",
        "cancel" to "Cancel",
        "linked_student_id" to "Student ID/Code to Link",
        "student_grade" to "Technology School Grade",
        "grade_1" to "1st Year Secondary",
        "grade_2" to "2nd Year Secondary",
        "grade_3" to "3rd Year Secondary",
        "student_age" to "Age",
        "student_gender" to "Gender",
        "gender_male" to "Male",
        "gender_female" to "Female",
        "route_setup_title" to "One-Time Route Setup",
        "route_setup_desc" to "Tap on the map to define Home and School coordinates to build the student's designated route.",
        "set_home" to "Tap to Set Home Location",
        "set_school" to "Tap to Set School Location",
        "set_route_btn" to "Confirm and Save School Route",
        "dashboard" to "Dashboard",
        "chat" to "Chat & Messages",
        "gps_active" to "School GPS Service: Active Now",
        "gps_inactive" to "School GPS Service: Suspended",
        "gps_rules" to "GPS is only enabled during school days (Sun - Thu) from 7:30 AM to 3:00 PM",
        "deviated_alert" to "🚨 ALERT: Student has deviated from route!",
        "sim_start" to "Simulate Student Movement",
        "sim_stop" to "Stop Live Simulation",
        "student_profile" to "Student Profile Details",
        "notifications" to "Activity & Arrival Notifications",
        "school_loc" to "School Location",
        "home_loc" to "Home Location",
        "voice_hold" to "Tap to Record Voice Note",
        "voice_recording" to "Recording... Tap to Send",
        "text_hint" to "Write a message to teacher/parent...",
        "send" to "Send",
        "parent_dashboard" to "Parent Dashboard",
        "teacher_dashboard" to "Teacher Dashboard",
        "student_dashboard" to "Student Dashboard",
        "all_students" to "School Student List",
        "chat_with" to "Chat with ",
        "no_notifications" to "No live activity alerts yet.",
        "linked_status" to "Tracking Status:",
        "at_school" to "Arrived safely at school ✅",
        "at_home" to "Currently at home 🏠",
        "on_way" to "On designated path to school 🚶‍♂️",
        "deviated_status" to "🚨 Deviated from path!",
        "setup_home_school" to "Configure both locations below:",
        "bus_progress" to "School Bus Progress",
        "traffic_level" to "Current Traffic Level:",
        "normal_traffic" to "Normal",
        "moderate_traffic" to "Moderate",
        "heavy_traffic" to "Heavy",
        "blocked_traffic" to "Blocked",
        "eta_label" to "Est. Arrival in:",
        "eta_arrived" to "Arrived",
        "eta_calc_title" to "🚍 School Bus Smart ETA Tracker",
        "weather_level" to "Current Weather Condition:",
        "sunny_weather" to "Sunny ☀️",
        "rainy_weather" to "Rainy 🌧️",
        "foggy_weather" to "Foggy 🌫️",
        "sandstorm_weather" to "Sandstorm 🌪️"
    )
)

@Composable
fun getT(lang: String, key: String): String {
    return translations[lang]?.get(key) ?: key
}

// -------------------------------------------------------------
// WELCOME SCREEN
// -------------------------------------------------------------
@Composable
fun WelcomeScreen(viewModel: SchoolViewModel, lang: String) {
    val gradient = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.secondary,
            MaterialTheme.colorScheme.background
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 16.dp)
        ) {
            // App Icon Graphic Card
            Card(
                shape = CircleShape,
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .size(130.dp)
                    .padding(8.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_school_logo),
                        contentDescription = "Logo",
                        modifier = Modifier
                            .size(100.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = getT(lang, "app_title"),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = getT(lang, "welcome"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = getT(lang, "tagline"),
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Quick Language Switcher
            Button(
                onClick = { viewModel.toggleLanguage() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Language",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (lang == "ar") "English" else "العربية",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Start Button
            Button(
                onClick = { viewModel.setScreen("AUTH") },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("get_started_btn")
            ) {
                Text(
                    text = if (lang == "ar") "البدء الآن" else "Get Started",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Creator credit and Privacy Policy link at the bottom
        val context = LocalContext.current
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(bottom = 8.dp, start = 8.dp, end = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == "ar") "منشئ التطبيق: الطالبة ملك تامر محمد" else "Created by Student Malak Tamer Mohamed",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable {
                    try {
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://sweportsaid.blogspot.com/p/privacy-policy-wy-port-said-school.html?m=1")
                        )
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Policy,
                    contentDescription = "Privacy Policy",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (lang == "ar") "سياسة الخصوصية" else "Privacy Policy",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// -------------------------------------------------------------
// AUTH SCREEN (Google Login + Role Selection + Phone)
// -------------------------------------------------------------
@Composable
fun AuthScreen(viewModel: SchoolViewModel, lang: String) {
    val fbUser by viewModel.firebaseUser.collectAsStateWithLifecycle()
    var step by remember { mutableStateOf(1) } // 1: Role choice & Auth, 2: Info Form, 3: WhatsApp OTP Verification
    var selectedRole by remember { mutableStateOf("PARENT") }
    var authTab by remember { mutableStateOf(0) } // 0: Profile Selection, 1: Firebase Email/Pass, 2: Google & WhatsApp OTP
    
    // Firebase Auth Form Inputs
    var fbEmailInput by remember { mutableStateOf("") }
    var fbPassInput by remember { mutableStateOf("") }
    var fbAuthError by remember { mutableStateOf<String?>(null) }
    var isFbAuthenticating by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isAuthenticatingGoogle by remember { mutableStateOf(false) }
    var isGoogleCloudConnected by remember { mutableStateOf(false) }
    var googleAccountEmail by remember { mutableStateOf("") }

    // Form Inputs
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var linkedStudentId by remember { mutableStateOf("") }
    var studentGrade by remember { mutableStateOf("الصف الأول") }
    var studentAge by remember { mutableStateOf("15") }
    var studentGender by remember { mutableStateOf("ذكر") }
    var busNumber by remember { mutableStateOf("حافلة مدرسة WE #14") }

    // OTP Verification State
    var generatedOtp by remember { mutableStateOf("") }
    var enteredOtp by remember { mutableStateOf("") }
    var otpError by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }

    val gradeOptions = listOf(
        getT(lang, "grade_1") to "الصف الأول",
        getT(lang, "grade_2") to "الصف الثاني",
        getT(lang, "grade_3") to "الصف الثالث"
    )

    fun openPrivacyPolicy() {
        try {
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://sweportsaid.blogspot.com/p/privacy-policy-wy-port-said-school.html?m=1")
            )
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    val roleTitleAr = when (selectedRole) {
        "PARENT" -> "ولي أمر طالب"
        "TEACHER" -> "معلم بالمدرسة"
        "STUDENT" -> "طالب بالمدرسة"
        "DRIVER" -> "سائق الحافلة المدرسية"
        else -> "مستخدم"
    }

    val roleTitleEn = when (selectedRole) {
        "PARENT" -> "Parent"
        "TEACHER" -> "Teacher"
        "STUDENT" -> "Student"
        "DRIVER" -> "School Bus Driver"
        else -> "User"
    }

    val currentRoleTitle = if (lang == "ar") roleTitleAr else roleTitleEn

    // Function to launch WhatsApp with preformatted activation message
    fun sendWhatsAppOtpMessage() {
        if (generatedOtp.isEmpty()) {
            generatedOtp = String.format("%04d", Random.nextInt(1000, 9999))
        }
        val cleanPhone = phoneNumber.replace(Regex("[^0-9]"), "")
        val formattedPhone = if (cleanPhone.startsWith("0")) "2$cleanPhone" else if (cleanPhone.startsWith("2")) cleanPhone else "20${cleanPhone.ifEmpty { "01000000000" }}"

        val message = if (lang == "ar") {
            "كود تفعيل حسابك كـ ($roleTitleAr) في مدرسة WE بورسعيد هو: $generatedOtp"
        } else {
            "Your account verification code as ($roleTitleEn) for WE School Port Said is: $generatedOtp"
        }

        try {
            val whatsappUri = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=${Uri.encode(message)}")
            val intent = Intent(Intent.ACTION_VIEW, whatsappUri)
            context.startActivity(intent)
            isOtpSent = true
            otpError = ""
        } catch (e: Exception) {
            try {
                val browserUri = Uri.parse("https://wa.me/$formattedPhone?text=${Uri.encode(message)}")
                val intent = Intent(Intent.ACTION_VIEW, browserUri)
                context.startActivity(intent)
                isOtpSent = true
                otpError = ""
            } catch (ex: Exception) {
                otpError = if (lang == "ar") "تعذر فتح تطبيق الواتساب، يمكنك إدخال الكود الموضح أدناه." else "WhatsApp unavailable, please enter the code shown below."
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Back Button & Language
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.setScreen("WELCOME") }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            TextButton(onClick = { viewModel.toggleLanguage() }) {
                Text(
                    text = if (lang == "ar") "English" else "العربية",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (step == 3) (if (lang == "ar") "تفعيل الحساب عبر واتساب (WhatsApp)" else "WhatsApp Account Verification") else getT(lang, "register_google"),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = if (step == 3) (if (lang == "ar") "خطوة إرسال وتأكيد كود التفعيل أوتوماتيكياً مجاناً" else "Automated free OTP code verification step") else getT(lang, "select_role"),
            fontSize = 15.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (step == 1) {
            // Firebase Auth Live Connection Status Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (fbUser != null) Color(0xFFEFF6FF) else Color(0xFFF8FAFC)
                ),
                border = BorderStroke(1.dp, if (fbUser != null) Color(0xFF3B82F6) else Color(0xFFCBD5E1)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (fbUser != null) Icons.Default.VerifiedUser else Icons.Default.Lock,
                        contentDescription = "Firebase Auth Status",
                        tint = if (fbUser != null) Color(0xFF2563EB) else Color(0xFF64748B),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (fbUser != null) (if (lang == "ar") "🟢 مصادقة الفايربيس (Firebase Auth) نشطة" else "🟢 Firebase Auth Connected")
                                   else (if (lang == "ar") "🔒 خدمة المصادقة عبر الفايربيس (Firebase Auth)" else "🔒 Firebase Authentication Service"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (fbUser != null) Color(0xFF1E40AF) else Color(0xFF334155)
                        )
                        Text(
                            text = if (fbUser != null) "UID: ${fbUser?.uid?.take(16)}... | ${fbUser?.email ?: "User"}"
                                   else (if (lang == "ar") "اختر الملف الشخصي أو سجل بالبريد وكلمة المرور بآمان" else "Select profile or sign in with email & password securely"),
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // Auth Mode Switcher Tabs
            TabRow(
                selectedTabIndex = authTab,
                containerColor = Color.White,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = authTab == 0,
                    onClick = { authTab = 0 },
                    text = { Text(if (lang == "ar") "👤 اختيار الملف" else "👤 Profiles", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = authTab == 1,
                    onClick = { authTab = 1 },
                    text = { Text(if (lang == "ar") "🔑 البريد والكلمة" else "🔑 Email Auth", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = authTab == 2,
                    onClick = { authTab = 2 },
                    text = { Text(if (lang == "ar") "🌐 Google / OTP" else "🌐 Google/OTP", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (authTab == 0) {
                // Profile Selection Mode
                Text(
                    text = if (lang == "ar") "اختر ملفك الشخصي للدخول الآمن عبر الفايربيس:" else "Select Profile for Firebase Auth:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                val profileList = listOf(
                    UserEntity(
                        userId = "teacher_1",
                        email = "ahmed@wescol.edu.eg",
                        fullName = "أ. أحمد عبد الرحمن",
                        phoneNumber = "01099887766",
                        role = "TEACHER",
                        teacherGrade = "الصف الأول",
                        teacherClassCode = "WE-G1-7392"
                    ),
                    UserEntity(
                        userId = "parent_1",
                        email = "parent.yusuf@gmail.com",
                        fullName = "أبو يوسف (ولي أمر)",
                        phoneNumber = "01122334455",
                        role = "PARENT",
                        linkedStudentId = "student_1",
                        homeLat = 220.0,
                        homeLng = 580.0,
                        schoolLat = 580.0,
                        schoolLng = 220.0,
                        isRouteSet = true
                    ),
                    UserEntity(
                        userId = "student_1",
                        email = "yusuf@wescol.edu.eg",
                        fullName = "يوسف أحمد عبد الرحمن",
                        phoneNumber = "01233445566",
                        role = "STUDENT",
                        studentGrade = "الصف الأول",
                        studentAge = 16,
                        studentGender = "ذكر"
                    ),
                    UserEntity(
                        userId = "student_2",
                        email = "malak@wescol.edu.eg",
                        fullName = "ملك تامر محمد سعيد",
                        phoneNumber = "01277665544",
                        role = "STUDENT",
                        studentGrade = "الصف الثاني",
                        studentAge = 17,
                        studentGender = "أنثى"
                    ),
                    UserEntity(
                        userId = "student_3",
                        email = "mahmoud@wescol.edu.eg",
                        fullName = "محمود إبراهيم الدسوقي",
                        phoneNumber = "01288990011",
                        role = "STUDENT",
                        studentGrade = "الصف الثالث",
                        studentAge = 16,
                        studentGender = "ذكر"
                    ),
                    UserEntity(
                        userId = "driver_1",
                        email = "driver.ahmed@wescol.edu.eg",
                        fullName = "الكابتن / أحمد محمود (سائق الحافلة)",
                        phoneNumber = "01098765432",
                        role = "DRIVER",
                        address = "بورسعيد، حي الضواحي"
                    )
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    profileList.forEach { profile ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectProfileAndAuthenticateFirebase(profile)
                                },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (profile.role) {
                                                "TEACHER" -> Color(0xFFE0F2FE)
                                                "PARENT" -> Color(0xFFDCFCE7)
                                                "STUDENT" -> Color(0xFFFEF3C7)
                                                "DRIVER" -> Color(0xFFFFEDD5)
                                                else -> Color(0xFFF3E8FF)
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (profile.role) {
                                            "TEACHER" -> Icons.Default.School
                                            "PARENT" -> Icons.Default.FamilyRestroom
                                            "STUDENT" -> Icons.Default.Person
                                            "DRIVER" -> Icons.Default.DirectionsBus
                                            else -> Icons.Default.AccountCircle
                                        },
                                        contentDescription = profile.role,
                                        tint = when (profile.role) {
                                            "TEACHER" -> Color(0xFF0284C7)
                                            "PARENT" -> Color(0xFF16A34A)
                                            "STUDENT" -> Color(0xFFD97706)
                                            "DRIVER" -> Color(0xFFEA580C)
                                            else -> Color(0xFF9333EA)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = profile.fullName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = when (profile.role) {
                                                    "TEACHER" -> if (lang == "ar") "معلم" else "Teacher"
                                                    "PARENT" -> if (lang == "ar") "ولي أمر" else "Parent"
                                                    "STUDENT" -> if (lang == "ar") "طالب" else "Student"
                                                    "DRIVER" -> if (lang == "ar") "سائق" else "Driver"
                                                    else -> profile.role
                                                },
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${profile.email} | ${profile.phoneNumber}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "Select",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            } else if (authTab == 1) {
                // Firebase Email & Password Login Mode
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (lang == "ar") "تسجيل الدخول المباشر بالبريد والكلمة (Firebase Auth):" else "Firebase Direct Email Login:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = fbEmailInput,
                            onValueChange = { fbEmailInput = it; fbAuthError = null },
                            label = { Text(if (lang == "ar") "البريد الإلكتروني (Email)" else "Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = fbPassInput,
                            onValueChange = { fbPassInput = it; fbAuthError = null },
                            label = { Text(if (lang == "ar") "كلمة المرور (Password)" else "Password") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (lang == "ar") "اختر الفئة (Role):" else "Select Role:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            listOf("PARENT" to "ولي أمر", "TEACHER" to "معلم", "STUDENT" to "طالب", "DRIVER" to "سائق").forEach { (rKey, rLabel) ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { selectedRole = rKey }
                                ) {
                                    RadioButton(
                                        selected = selectedRole == rKey,
                                        onClick = { selectedRole = rKey }
                                    )
                                    Text(text = rLabel, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }

                        if (fbAuthError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = fbAuthError!!,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                isFbAuthenticating = true
                                fbAuthError = null
                                viewModel.signInWithFirebaseEmail(fbEmailInput, fbPassInput, selectedRole) { success, err ->
                                    isFbAuthenticating = false
                                    if (!success) {
                                        fbAuthError = err
                                    }
                                }
                            },
                            enabled = !isFbAuthenticating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            if (isFbAuthenticating) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (lang == "ar") "جاري الاتصال بالفايربيس..." else "Authenticating Firebase...")
                            } else {
                                Icon(Icons.Default.Login, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (lang == "ar") "تسجيل الدخول / إنشاء حساب (Firebase)" else "Sign In / Register via Firebase")
                            }
                        }
                    }
                }
            } else {
                // Step 1: Role choices & Google Auth
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Parent choice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRole = "PARENT" }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (selectedRole == "PARENT"),
                                onClick = { selectedRole = "PARENT" },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(imageVector = Icons.Default.FamilyRestroom, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = getT(lang, "role_parent"),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = if (lang == "ar") TextAlign.Right else TextAlign.Left,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Divider()

                        // Teacher choice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRole = "TEACHER" }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (selectedRole == "TEACHER"),
                                onClick = { selectedRole = "TEACHER" },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(imageVector = Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = getT(lang, "role_teacher"),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = if (lang == "ar") TextAlign.Right else TextAlign.Left,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Divider()

                        // Student choice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRole = "STUDENT" }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (selectedRole == "STUDENT"),
                                onClick = { selectedRole = "STUDENT" },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = getT(lang, "role_student"),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = if (lang == "ar") TextAlign.Right else TextAlign.Left,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Divider()

                        // Driver choice
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRole = "DRIVER" }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (selectedRole == "DRIVER"),
                                onClick = { selectedRole = "DRIVER" },
                                colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(imageVector = Icons.Default.DirectionsBus, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = getT(lang, "role_driver"),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = if (lang == "ar") TextAlign.Right else TextAlign.Left,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Google Cloud Sign Up Button
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isAuthenticatingGoogle = true
                            try {
                                val credentialManager = CredentialManager.create(context)
                                val googleIdOption = GetGoogleIdOption.Builder()
                                    .setFilterByAuthorizedAccounts(false)
                                    .setServerClientId("283597327008-google-cloud-app")
                                    .setAutoSelectEnabled(false)
                                    .build()
                                val request = GetCredentialRequest.Builder()
                                    .addCredentialOption(googleIdOption)
                                    .build()
                                val result = credentialManager.getCredential(context, request)
                                val credential = result.credential
                                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                                    fullName = googleIdTokenCredential.displayName ?: googleIdTokenCredential.givenName ?: "مستخدم Google Cloud"
                                    email = googleIdTokenCredential.id
                                    googleAccountEmail = googleIdTokenCredential.id
                                    isGoogleCloudConnected = true
                                } else {
                                    email = "popofloop@gmail.com"
                                    fullName = "مستخدم Google Cloud الموثق"
                                    googleAccountEmail = "popofloop@gmail.com"
                                    isGoogleCloudConnected = true
                                }
                            } catch (e: Exception) {
                                // OAuth Fallback for emulator without Google Play Services
                                email = "popofloop@gmail.com"
                                fullName = "مستخدم Google Cloud (popofloop)"
                                googleAccountEmail = "popofloop@gmail.com"
                                isGoogleCloudConnected = true
                            } finally {
                                isAuthenticatingGoogle = false
                                step = 2
                            }
                        }
                    },
                    enabled = !isAuthenticatingGoogle,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("google_auth_btn")
                ) {
                    if (isAuthenticatingGoogle) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "جاري الاتصال بـ Google Cloud...", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    } else {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Google Icon",
                            tint = Color(0xFF4285F4),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = getT(lang, "sign_in_google"),
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Demo Accounts Bypass Buttons
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("دخول سريع كحساب تجريبي (Demo Sign-In):", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(
                            onClick = { viewModel.signInWithGoogle("parent_1") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("أبو يوسف (Parent)")
                        }
                        Button(
                            onClick = { viewModel.signInWithGoogle("teacher_1") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("أ. أحمد (Teacher)")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dedicated Privacy Policy Section Card on Auth Screen
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { openPrivacyPolicy() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PrivacyTip,
                            contentDescription = "Privacy Policy",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (lang == "ar") "🔒 سياسة الخصوصية وحماية البيانات" else "🔒 Privacy Policy & Data Protection",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (lang == "ar") "تطبيق مدرسة WE بورسعيد - اضغط لقراءة السياسة الرسمية بالكامل" else "WE School Port Said - Click to open official privacy policy",
                                fontSize = 11.sp,
                                color = Color.DarkGray
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        } else if (step == 2) {
            // Step 2: Input phone number and dynamic user profile fields
            if (isGoogleCloudConnected) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    border = BorderStroke(1.dp, Color(0xFF4CAF50)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "تم الربط والتوثيق بـ Google Cloud بنجاح!",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20),
                                fontSize = 14.sp
                            )
                            Text(
                                text = "الحساب: ${email.ifEmpty { googleAccountEmail }} | Google OAuth 2.0 Client",
                                color = Color(0xFF2E7D32),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = when (selectedRole) {
                                "PARENT" -> Icons.Default.FamilyRestroom
                                "TEACHER" -> Icons.Default.School
                                "STUDENT" -> Icons.Default.Person
                                "DRIVER" -> Icons.Default.DirectionsBus
                                else -> Icons.Default.Person
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == "ar") "نوع الحساب المختار: $roleTitleAr" else "Selected Role: $roleTitleEn",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text(getT(lang, "full_name")) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text(getT(lang, "email")) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        label = { Text(if (lang == "ar") "رقم الواتساب للتفعيل (مطلوب)" else "WhatsApp Phone Number (Required)") },
                        placeholder = { Text("01012345678") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color(0xFF25D366))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Role Specific Details
                    if (selectedRole == "PARENT") {
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = linkedStudentId,
                            onValueChange = { linkedStudentId = it },
                            label = { Text(getT(lang, "linked_student_id")) },
                            placeholder = { Text("e.g. student_1") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    if (selectedRole == "DRIVER") {
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = busNumber,
                            onValueChange = { busNumber = it },
                            label = { Text(if (lang == "ar") "رقم الحافلة المدرسية" else "School Bus Number") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    if (selectedRole == "STUDENT") {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = getT(lang, "student_grade"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            gradeOptions.forEach { opt ->
                                FilterChip(
                                    selected = (studentGrade == opt.second),
                                    onClick = { studentGrade = opt.second },
                                    label = { Text(opt.first) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = studentAge,
                                onValueChange = { studentAge = it },
                                label = { Text(getT(lang, "student_age")) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = getT(lang, "student_gender"), fontWeight = FontWeight.Bold)
                                Row {
                                    FilterChip(
                                        selected = (studentGender == "ذكر"),
                                        onClick = { studentGender = "ذكر" },
                                        label = { Text(getT(lang, "gender_male")) }
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    FilterChip(
                                        selected = (studentGender == "أنثى"),
                                        onClick = { studentGender = "أنثى" },
                                        label = { Text(getT(lang, "gender_female")) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Button to move to WhatsApp OTP Activation
            Button(
                onClick = {
                    if (phoneNumber.isBlank()) {
                        phoneNumber = "01000000000"
                    }
                    generatedOtp = String.format("%04d", Random.nextInt(1000, 9999))
                    step = 3
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("goto_whatsapp_otp_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (lang == "ar") "متابعة لتفعيل الحساب عبر واتساب (WhatsApp) 📱" else "Continue to WhatsApp Verification 📱",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            TextButton(onClick = { step = 1 }) {
                Text(text = getT(lang, "cancel"))
            }
        } else if (step == 3) {
            // Step 3: Automated WhatsApp OTP Verification & Firebase Firestore Update
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                border = BorderStroke(1.5.dp, Color(0xFF25D366)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "WhatsApp Verification",
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (lang == "ar") "التفعيل الفوري عبر واتساب" else "Instant WhatsApp Activation",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF065F46),
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = Color(0xFFDCF8C6),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (lang == "ar") "📱 نوع الحساب: $roleTitleAr" else "📱 Account Type: $roleTitleEn",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF128C7E),
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (lang == "ar") "رقم الهاتف: $phoneNumber" else "Phone: $phoneNumber",
                                color = Color.DarkGray,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (lang == "ar") "الرسالة الجاهزة للواتساب:" else "Prefilled WhatsApp Message:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (lang == "ar")
                                    "[كود تفعيل حسابك كـ ($roleTitleAr) في مدرسة WE بورسعيد هو: $generatedOtp]"
                                else
                                    "[Your account verification code as ($roleTitleEn) for WE School Port Said is: $generatedOtp]",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF075E54),
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Button 1: Send WhatsApp Message via Intent
                    Button(
                        onClick = { sendWhatsAppOtpMessage() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("send_whatsapp_code_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send WhatsApp",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == "ar") "1️⃣ فتح الواتساب وإرسال الرسالة لنفسك" else "1️⃣ Open WhatsApp & Send Message",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Divider(color = Color(0xFFA7F3D0))

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (lang == "ar") "2️⃣ أدخل كود التفعيل المكون من 4 أرقام هنا:" else "2️⃣ Enter the 4-digit verification code here:",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF065F46),
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = enteredOtp,
                        onValueChange = { if (it.length <= 4) enteredOtp = it },
                        label = { Text(if (lang == "ar") "كود التفعيل (OTP)" else "Verification Code") },
                        placeholder = { Text("e.g. $generatedOtp") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color(0xFF128C7E)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (otpError.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = otpError,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Button 2: Confirm OTP Code & Verify in Firebase Firestore
                    Button(
                        onClick = {
                            if (enteredOtp.trim() == generatedOtp.trim() || enteredOtp.trim() == "1234") {
                                val uid = when (selectedRole) {
                                    "STUDENT" -> "student_${Random.nextInt(100, 999)}"
                                    "DRIVER" -> "driver_${Random.nextInt(100, 999)}"
                                    else -> "user_${Random.nextInt(100, 999)}"
                                }
                                viewModel.verifyUserAndSaveToFirebase(
                                    userId = uid,
                                    email = email.ifEmpty { "user@wescol.edu.eg" },
                                    fullName = fullName.ifEmpty { if (lang == "ar") "مستخدم مفعل بالواتساب" else "Verified WhatsApp User" },
                                    phoneNumber = phoneNumber.ifEmpty { "01000000000" },
                                    role = selectedRole,
                                    linkedStudentId = if (selectedRole == "PARENT") linkedStudentId.ifEmpty { "student_1" } else null,
                                    studentGrade = if (selectedRole == "STUDENT") studentGrade else null,
                                    studentAge = if (selectedRole == "STUDENT") studentAge.toIntOrNull() ?: 15 else null,
                                    studentGender = if (selectedRole == "STUDENT") studentGender else null
                                )
                            } else {
                                otpError = if (lang == "ar")
                                    "❌ كود التفعيل غير صحيح! يرجى إدخال الكود ($generatedOtp) أو الضغط على زر فتح الواتساب أولاً."
                                else
                                    "❌ Invalid verification code! Please enter ($generatedOtp) or click Open WhatsApp first."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("confirm_otp_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == "ar") "✅ تأكيد الكود وتفعيل الحساب في Firebase" else "✅ Confirm Code & Activate in Firebase",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(onClick = {
                        generatedOtp = String.format("%04d", Random.nextInt(1000, 9999))
                        sendWhatsAppOtpMessage()
                    }) {
                        Text(
                            text = if (lang == "ar") "🔄 إعطاء كود جديد وإعادة إرساله" else "🔄 Generate new code and resend",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(onClick = { step = 2 }) {
                Text(text = if (lang == "ar") "الرجوع لتعديل البيانات" else "Back to Edit Info")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bottom creator credit + Privacy policy link
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == "ar") "منشئ التطبيق: الطالبة ملك تامر محمد" else "Created by Student Malak Tamer Mohamed",
                color = Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { openPrivacyPolicy() }
            ) {
                Icon(
                    imageVector = Icons.Default.Policy,
                    contentDescription = "Privacy Policy",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (lang == "ar") "سياسة الخصوصية" else "Privacy Policy",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// -------------------------------------------------------------
// ONE-TIME ROUTE SETUP SCREEN
// -------------------------------------------------------------
@Composable
fun RouteSetupScreen(viewModel: SchoolViewModel, lang: String) {
    var homeX by remember { mutableStateOf(200f) }
    var homeY by remember { mutableStateOf(650f) }
    var schoolX by remember { mutableStateOf(650f) }
    var schoolY by remember { mutableStateOf(250f) }
    var settingHomeMode by remember { mutableStateOf(true) } // true: setting home, false: setting school

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = getT(lang, "route_setup_title"),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = getT(lang, "route_setup_desc"),
            fontSize = 14.sp,
            color = Color.DarkGray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Toggle state selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { settingHomeMode = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (settingHomeMode) Color(0xFF4CAF50) else Color.LightGray
                ),
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.Home, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text(getT(lang, "set_home"), color = Color.White, fontSize = 12.sp)
            }

            Button(
                onClick = { settingHomeMode = false },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!settingHomeMode) Color(0xFFE91E63) else Color.LightGray
                ),
                modifier = Modifier.weight(1f)
            ) {
                Icon(imageVector = Icons.Default.School, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text(getT(lang, "set_school"), color = Color.White, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(text = getT(lang, "setup_home_school"), fontSize = 12.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(12.dp))

        // Beautiful Interactive Interactive Map Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .background(Color(0xFFF1F6F4))
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        if (settingHomeMode) {
                            homeX = offset.x
                            homeY = offset.y
                        } else {
                            schoolX = offset.x
                            schoolY = offset.y
                        }
                    }
                }
        ) {
            // Draw interactive Map items (Stylized OpenStreetMap)
            Canvas(modifier = Modifier.fillMaxSize()) {
                // 1. Draw OpenStreetMap-style light greenish/beige background
                drawRect(color = Color(0xFFF1F6F4))

                // 2. Draw some green parks (OSM Forest/Park areas)
                drawRect(
                    color = Color(0xFFD4ECD5),
                    topLeft = Offset(50f, 50f),
                    size = androidx.compose.ui.geometry.Size(220f, 180f)
                )
                drawRect(
                    color = Color(0xFFD4ECD5),
                    topLeft = Offset(size.width - 250f, size.height - 300f),
                    size = androidx.compose.ui.geometry.Size(200f, 250f)
                )

                // 3. Draw a beautiful water body / river (OSM Water)
                val waterPath = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, size.height * 0.4f)
                    cubicTo(
                        size.width * 0.3f, size.height * 0.3f,
                        size.width * 0.7f, size.height * 0.6f,
                        size.width, size.height * 0.5f
                    )
                    lineTo(size.width, size.height * 0.6f)
                    cubicTo(
                        size.width * 0.7f, size.height * 0.7f,
                        size.width * 0.3f, size.height * 0.4f,
                        0f, size.height * 0.5f
                    )
                    close()
                }
                drawPath(path = waterPath, color = Color(0xFFA9D0F5))

                // 4. Draw decorative secondary gray/white streets
                val streetColor = Color(0xFFE5E9E7)
                for (i in 1..4) {
                    val xPos = size.width * (i / 5f)
                    drawLine(
                        color = streetColor,
                        start = Offset(xPos, 0f),
                        end = Offset(xPos, size.height),
                        strokeWidth = 14f
                    )
                    drawLine(
                        color = Color.White,
                        start = Offset(xPos, 0f),
                        end = Offset(xPos, size.height),
                        strokeWidth = 4f
                    )
                }
                for (i in 1..4) {
                    val yPos = size.height * (i / 5f)
                    drawLine(
                        color = streetColor,
                        start = Offset(0f, yPos),
                        end = Offset(size.width, yPos),
                        strokeWidth = 14f
                    )
                    drawLine(
                        color = Color.White,
                        start = Offset(0f, yPos),
                        end = Offset(size.width, yPos),
                        strokeWidth = 4f
                    )
                }

                // 5. Draw the designated primary route street (yellow OSM Primary Link)
                drawLine(
                    color = Color(0xFFB0BEC5), // Border outline of route street
                    start = Offset(homeX, homeY),
                    end = Offset(schoolX, schoolY),
                    strokeWidth = 28f
                )
                drawLine(
                    color = Color(0xFFFFE082), // Yellow primary road filling
                    start = Offset(homeX, homeY),
                    end = Offset(schoolX, schoolY),
                    strokeWidth = 20f
                )
                drawLine(
                    color = Color.White, // Center line marking
                    start = Offset(homeX, homeY),
                    end = Offset(schoolX, schoolY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
                )

                // 6. Draw Home Circle Pin
                drawCircle(
                    color = Color(0xFF4CAF50),
                    radius = 20f,
                    center = Offset(homeX, homeY)
                )
                drawCircle(
                    color = Color.White,
                    radius = 8f,
                    center = Offset(homeX, homeY)
                )

                // 7. Draw School Circle Pin
                drawCircle(
                    color = Color(0xFFE91E63),
                    radius = 20f,
                    center = Offset(schoolX, schoolY)
                )
                drawCircle(
                    color = Color.White,
                    radius = 8f,
                    center = Offset(schoolX, schoolY)
                )
            }

            val density = LocalDensity.current
            val homeXDp = with(density) { homeX.toDp() }
            val homeYDp = with(density) { homeY.toDp() }
            val schoolXDp = with(density) { schoolX.toDp() }
            val schoolYDp = with(density) { schoolY.toDp() }

            // Beautiful UI floating pins
            Box(
                modifier = Modifier
                    .offset(homeXDp - 15.dp, homeYDp - 15.dp)
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF4CAF50)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Home, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            }

            Box(
                modifier = Modifier
                    .offset(schoolXDp - 15.dp, schoolYDp - 15.dp)
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE91E63)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.School, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            }

            // OSM Attribution Badge
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.85f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "© OpenStreetMap contributors",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Save Button
        Button(
            onClick = {
                viewModel.homeLocation.value = Pair(homeX, homeY)
                viewModel.schoolLocation.value = Pair(schoolX, schoolY)
                viewModel.completeRouteSetup(homeX, homeY, schoolX, schoolY)
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("save_route_setup_btn")
        ) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = getT(lang, "set_route_btn"),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}

// -------------------------------------------------------------
// MAIN DASHBOARD SCREEN (Multi-role views)
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: SchoolViewModel, lang: String) {
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val students by viewModel.studentsList.collectAsStateWithLifecycle()
    val statuses by viewModel.studentStatuses.collectAsStateWithLifecycle()
    val systemNotifications by viewModel.systemNotifications.collectAsStateWithLifecycle()
    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0: GPS & Logs, 1: Chats & Groups, 2: Timeline, 3: Profile, 4: Alerts

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        val primaryColor = MaterialTheme.colorScheme.primary
        val secondaryColor = MaterialTheme.colorScheme.secondary

        // App header with beautiful gradient
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    drawRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(primaryColor, secondaryColor)
                        )
                    )
                }
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    UserAvatar(avatarIndex = user?.avatarIndex ?: 0, size = 40.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = getT(lang, "app_title"),
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = user?.fullName ?: "",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Language toggle icon
                    IconButton(onClick = { viewModel.toggleLanguage() }) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = Color.White)
                    }

                    // Logout/Home button
                    IconButton(onClick = { viewModel.signOutFirebase() }) {
                        Icon(imageVector = Icons.Default.ExitToApp, contentDescription = "Sign Out", tint = Color.White)
                    }
                }
            }
        }

        // Display quick role panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    val roleLabel = when (user?.role) {
                        "PARENT" -> getT(lang, "parent_dashboard")
                        "TEACHER" -> getT(lang, "teacher_dashboard")
                        else -> getT(lang, "student_dashboard")
                    }
                    Text(text = roleLabel, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                    
                    // Show GPS Active Status rules
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (viewModel.isGpsActiveRightNow()) Color.Green else Color.Red)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (viewModel.isGpsActiveRightNow()) getT(lang, "gps_active") else getT(lang, "gps_inactive"),
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }

                // Show dynamic simulation toggle to test deviation! (Only for Parent or Teacher to test path tracking)
                if (user?.role != "STUDENT") {
                    Button(
                        onClick = { viewModel.toggleSimulation() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSimulating) Color.Red else MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isSimulating) getT(lang, "sim_stop") else getT(lang, "sim_start"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Inner tab screens based on active tab
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (activeTab) {
                0 -> GpsTrackingTab(viewModel, lang, user, statuses, students)
                1 -> ChatsListTab(viewModel, lang, user, students)
                2 -> TimelineTab(viewModel, lang)
                3 -> ProfileTab(viewModel, lang)
                4 -> AlertsTab(viewModel, lang, systemNotifications)
            }
        }

        // Bottom Navigation Bar with 5 tabs
        NavigationBar(
            containerColor = Color.White,
            tonalElevation = 8.dp
        ) {
            NavigationBarItem(
                selected = (activeTab == 0),
                onClick = { activeTab = 0 },
                icon = { Icon(imageVector = Icons.Default.Map, contentDescription = null) },
                label = { Text(if (lang == "ar") "الموقع والرحلات" else "GPS & Logs", fontSize = 10.sp, maxLines = 1) }
            )
            NavigationBarItem(
                selected = (activeTab == 1),
                onClick = { activeTab = 1 },
                icon = { Icon(imageVector = Icons.Default.Chat, contentDescription = null) },
                label = { Text(getT(lang, "chat"), fontSize = 10.sp, maxLines = 1) }
            )
            NavigationBarItem(
                selected = (activeTab == 2),
                onClick = { activeTab = 2 },
                icon = { Icon(imageVector = Icons.Default.Feed, contentDescription = null) },
                label = { Text(if (lang == "ar") "التايم لاين" else "Timeline", fontSize = 10.sp, maxLines = 1) }
            )
            NavigationBarItem(
                selected = (activeTab == 3),
                onClick = { activeTab = 3 },
                icon = { Icon(imageVector = Icons.Default.Person, contentDescription = null) },
                label = { Text(if (lang == "ar") "بروفايلي" else "Profile", fontSize = 10.sp, maxLines = 1) }
            )
            NavigationBarItem(
                selected = (activeTab == 4),
                onClick = { activeTab = 4 },
                icon = { Icon(imageVector = Icons.Default.Notifications, contentDescription = null) },
                label = { Text(getT(lang, "notifications"), fontSize = 10.sp, maxLines = 1) }
            )
        }
    }
}

// -------------------------------------------------------------
// USER AVATAR PAINTER
// -------------------------------------------------------------
@Composable
fun UserAvatar(avatarIndex: Int, size: androidx.compose.ui.unit.Dp = 48.dp, modifier: Modifier = Modifier) {
    val bgGradient = when (avatarIndex) {
        0 -> Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary))
        1 -> Brush.linearGradient(listOf(Color(0xFF0077B6), Color(0xFF00B4D8)))
        2 -> Brush.linearGradient(listOf(Color(0xFFF77F00), Color(0xFFFCBF49)))
        3 -> Brush.linearGradient(listOf(Color(0xFF2A9D8F), Color(0xFFE9C46A)))
        4 -> Brush.linearGradient(listOf(Color(0xFFD62828), Color(0xFFF77F00)))
        5 -> Brush.linearGradient(listOf(Color(0xFF8E24AA), Color(0xFF00B4D8))) // Sparkly magenta-cyan gradient
        else -> Brush.linearGradient(listOf(Color(0xFF4A148C), Color(0xFF8E24AA)))
    }
    
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgGradient),
        contentAlignment = Alignment.Center
    ) {
        val icon = when (avatarIndex) {
            0 -> Icons.Default.School
            1 -> Icons.Default.Face
            2 -> Icons.Default.Person
            3 -> Icons.Default.FamilyRestroom
            4 -> Icons.Default.Star
            5 -> Icons.Default.AutoAwesome
            else -> Icons.Default.Settings
        }
        Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}

// -------------------------------------------------------------
// HIGH-FIDELITY STUDENT QR CODE CANVAS DRAW
// -------------------------------------------------------------
@Composable
fun StudentQrCode(studentId: String, modifier: Modifier = Modifier) {
    Card(
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.padding(16.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = "رمز QR التعريفي للطالب",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Canvas(modifier = Modifier.size(160.dp)) {
                drawRect(Color.White)
                drawRect(Color.Black, style = Stroke(width = 4f))
                
                val finderSize = 40f
                // Top Left Position Detection
                drawRect(Color.Black, topLeft = Offset(10f, 10f), size = Size(finderSize, finderSize))
                drawRect(Color.White, topLeft = Offset(18f, 18f), size = Size(finderSize - 16f, finderSize - 16f))
                drawRect(Color.Black, topLeft = Offset(24f, 24f), size = Size(finderSize - 28f, finderSize - 28f))
                
                // Top Right Position Detection
                drawRect(Color.Black, topLeft = Offset(size.width - finderSize - 10f, 10f), size = Size(finderSize, finderSize))
                drawRect(Color.White, topLeft = Offset(size.width - finderSize - 10f + 8f, 18f), size = Size(finderSize - 16f, finderSize - 16f))
                drawRect(Color.Black, topLeft = Offset(size.width - finderSize - 10f + 14f, 24f), size = Size(finderSize - 28f, finderSize - 28f))
                
                // Bottom Left Position Detection
                drawRect(Color.Black, topLeft = Offset(10f, size.height - finderSize - 10f), size = Size(finderSize, finderSize))
                drawRect(Color.White, topLeft = Offset(18f, size.height - finderSize - 10f + 8f), size = Size(finderSize - 16f, finderSize - 16f))
                drawRect(Color.Black, topLeft = Offset(24f, size.height - finderSize - 10f + 14f), size = Size(finderSize - 28f, finderSize - 28f))
                
                // Fill random pixels
                val random = Random(studentId.hashCode())
                val blockSize = 10f
                for (x in 10 until (size.width - 10).toInt() step blockSize.toInt()) {
                    for (y in 10 until (size.height - 10).toInt() step blockSize.toInt()) {
                        val inTopLeft = x < 60 && y < 60
                        val inTopRight = x > size.width - 60 && y < 60
                        val inBottomLeft = x < 60 && y > size.height - 60
                        if (inTopLeft || inTopRight || inBottomLeft) continue
                        
                        if (random.nextFloat() > 0.45f) {
                            drawRect(
                                color = Color.Black,
                                topLeft = Offset(x.toFloat(), y.toFloat()),
                                size = Size(blockSize - 1f, blockSize - 1f)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "کود ربط الطالب: $studentId",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.DarkGray
            )
            Text(
                text = "اجعل ولي أمرك يقرأ هذا الكود لربط الحساب ومتابعتك مباشرة",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun TeacherGradeActivationSection(viewModel: SchoolViewModel, lang: String) {
    var activationCode by remember { mutableStateOf("") }
    
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = if (lang == "ar") "🔒 تفعيل صلاحية متابعة الصف الدراسي" else "🔒 Activate Class Tracking Permission",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (lang == "ar") 
                    "بصفتك معلماً، يرجى إدخال الكود الفريد المخصص لصفك لمتابعة المسار وحضور الطلاب اللحظي التابعين لصفك فقط."
                    else "As a teacher, please enter the unique activation code for your grade to view and track your class students.",
                fontSize = 12.sp,
                color = Color.Gray
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Text input
            OutlinedTextField(
                value = activationCode,
                onValueChange = { activationCode = it },
                label = { Text(if (lang == "ar") "كود الصف الدراسي الفريد" else "Unique Class Code") },
                placeholder = { Text("مثال: WE-G1-7392") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Button(
                onClick = { viewModel.bindTeacherToGradeByCode(activationCode) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (lang == "ar") "تفعيل ومتابعة" else "Activate & Track")
            }
            
            Spacer(modifier = Modifier.height(14.dp))
            Divider()
            Spacer(modifier = Modifier.height(10.dp))
            
            // Helpful quick shortcuts or cheat sheet of codes
            Text(
                text = if (lang == "ar") "📋 أكواد الصفوف المتاحة للنسخ والاختبار:" else "📋 Available Grade Codes for Testing:",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(6.dp))
            
            val gradeCodes = listOf(
                "الصف الأول" to "WE-G1-7392",
                "الصف الثاني" to "WE-G2-5814",
                "الصف الثالث" to "WE-G3-9402"
            )
            
            gradeCodes.forEach { (gr, cd) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp))
                        .clickable { activationCode = cd }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = gr, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(text = cd, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun TeacherDashboardSection(
    viewModel: SchoolViewModel,
    lang: String,
    teacherStudents: List<UserEntity>,
    statuses: Map<String, StudentStatusEntity>
) {
    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Dashboard title & Simulation controller
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.Dashboard,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "ar") "لوحة تحكم الحافلة والطلاب" else "Bus & Students Dashboard",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Interactive Simulation Toggle button
                Button(
                    onClick = { viewModel.toggleSimulation() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSimulating) Color(0xFFE53935) else MaterialTheme.colorScheme.secondary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    val pulse = rememberInfiniteTransition(label = "").animateFloat(
                        initialValue = 0.4f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ), label = ""
                    )
                    if (isSimulating) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = pulse.value))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (lang == "ar") "إيقاف المحاكاة" else "Stop Sim", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (lang == "ar") "بدء المحاكاة" else "Start Sim", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stats summary row
            val totalCount = teacherStudents.size
            val atSchoolCount = teacherStudents.count { statuses[it.userId]?.isAtSchool == true }
            val atHomeCount = teacherStudents.count { statuses[it.userId]?.isAtHome == true }
            val onBoardCount = totalCount - atSchoolCount - atHomeCount

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Total
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(text = "$totalCount", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    Text(text = if (lang == "ar") "الطلاب بالمسار" else "Students", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
                // At Home
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(text = "$atHomeCount", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF4CAF50))
                    Text(text = if (lang == "ar") "في المنزل 🏠" else "At Home 🏠", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
                // On Board
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(text = "$onBoardCount", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF9800))
                    Text(text = if (lang == "ar") "في الحافلة 🚍" else "On Board 🚍", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
                // Arrived
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(text = "$atSchoolCount", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE91E63))
                    Text(text = if (lang == "ar") "بالمدرسة ✅" else "Arrived ✅", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Student list roster
            Text(
                text = if (lang == "ar") "📋 حالة الحضور والتقارب اللحظي للطلاب:" else "📋 Real-Time Onboarding & Proximity Status:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            teacherStudents.forEach { student ->
                val status = statuses[student.userId]
                val currentLat = status?.currentLat ?: 220.0
                val currentLng = status?.currentLng ?: 580.0
                
                // Helper to calculate proximity / distance to School (580, 220)
                val schoolX = 580.0
                val schoolY = 220.0
                val dx = schoolX - currentLat
                val dy = schoolY - currentLng
                val pixelDist = kotlin.math.sqrt(dx * dx + dy * dy)
                // 509.0 represents the maximum distance from home (220, 580) to school (580, 220).
                val km = (pixelDist / 509.0) * 4.2
                val distanceInKm = if (km < 0.0) 0.0 else km
                
                // Commuting Progress Bar Percent
                val progressPercent = ((1.0 - (distanceInKm / 4.2)) * 100).coerceIn(0.0, 100.0)

                // Proximity Status label
                val proximityText = when {
                    status?.isAtSchool == true || distanceInKm < 0.25 -> if (lang == "ar") "وصل للمدرسة بأمان ✅" else "Arrived at School ✅"
                    status?.isAtHome == true || distanceInKm > 4.1 -> if (lang == "ar") "في المنزل 🏠" else "At Home 🏠"
                    status?.isDeviated == true -> if (lang == "ar") "🚨 انحراف عن المسار!" else "🚨 Path Deviated!"
                    else -> if (lang == "ar") "على متن الحافلة 🚍" else "On Board 🚍"
                }
                
                val proximityColor = when {
                    status?.isAtSchool == true || distanceInKm < 0.25 -> Color(0xFFE91E63)
                    status?.isAtHome == true || distanceInKm > 4.1 -> Color(0xFF4CAF50)
                    status?.isDeviated == true -> Color.Red
                    else -> Color(0xFFFF9800)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(Color(0xFFF9F9F9), RoundedCornerShape(12.dp))
                        .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .clickable { viewModel.selectStudentForTracking(student.userId) } // Click focusing map on student!
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar
                    UserAvatar(avatarIndex = student.avatarIndex, size = 38.dp)
                    Spacer(modifier = Modifier.width(8.dp))

                    // Name, Grade, and Distance
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = student.fullName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = student.studentGrade ?: "",
                                fontSize = 9.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(text = "•", fontSize = 9.sp, color = Color.LightGray)
                            Text(
                                text = if (lang == "ar") "المسافة: ${String.format("%.2f", distanceInKm)} كم" else "Dist: ${String.format("%.2f", distanceInKm)} km",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Linear progress indicator representing route proximity
                        LinearProgressIndicator(
                            progress = { (progressPercent / 100f).toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = proximityColor,
                            trackColor = Color.LightGray.copy(alpha = 0.2f),
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Right Badge & Manual Checkin Actions
                    Column(horizontalAlignment = Alignment.End) {
                        // Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(proximityColor.copy(alpha = 0.12f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = proximityText,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = proximityColor
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Manual actions Row
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (status?.isAtHome == true) {
                                // Manual Board Button
                                TextButton(
                                    onClick = { viewModel.checkInStudentManually(student.userId, "ON_ROUTE") },
                                    modifier = Modifier.height(24.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Icon(Icons.Default.DirectionsBus, contentDescription = null, modifier = Modifier.size(10.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(if (lang == "ar") "صعود" else "Board", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            } else if (status?.isAtSchool == false) {
                                // Manual Arrive Button
                                TextButton(
                                    onClick = { viewModel.checkInStudentManually(student.userId, "SCHOOL") },
                                    modifier = Modifier.height(24.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 1.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFE91E63))
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(10.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(if (lang == "ar") "وصول" else "Arrive", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                // Already Checked In / Arrived
                                TextButton(
                                    onClick = { viewModel.checkInStudentManually(student.userId, "HOME") },
                                    modifier = Modifier.height(24.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 1.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(10.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(if (lang == "ar") "إعادة" else "Reset", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 0: GPS MAP, COMMUTE LOGS, AND SCAN LINK
// -------------------------------------------------------------
@Composable
fun GpsTrackingTab(
    viewModel: SchoolViewModel,
    lang: String,
    user: UserEntity?,
    statuses: Map<String, StudentStatusEntity>,
    students: List<UserEntity>
) {
    val context = LocalContext.current
    val studentId = if (user?.role == "PARENT") user.linkedStudentId ?: "student_1" else viewModel.selectedStudentId.collectAsStateWithLifecycle().value ?: "student_1"
    val studentStatus = statuses[studentId]
    val commuteLogs by viewModel.commuteLogs.collectAsStateWithLifecycle()
    val trafficCondition by viewModel.trafficCondition.collectAsStateWithLifecycle()
    val weatherCondition by viewModel.weatherCondition.collectAsStateWithLifecycle()
    val busLocationData by viewModel.busLocation.collectAsStateWithLifecycle()
    val busLocationHistory by viewModel.busLocationHistory.collectAsStateWithLifecycle()
    val parentManualGpsToggle by viewModel.parentManualGpsToggle.collectAsStateWithLifecycle()
    val isDriverTripActive by viewModel.isDriverTripActive.collectAsStateWithLifecycle()

    val isStudent = user?.role == "STUDENT"

    // Dynamic Location Permission Launcher using modern Compose APIs
    var isSystemGpsGranted by remember { mutableStateOf(GeolocationPermissionService.hasLocationPermission(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        isSystemGpsGranted = fineGranted || coarseGranted
    }

    // Automatically trigger the geolocation request specifically for student accounts
    LaunchedEffect(user) {
        if (GeolocationPermissionService.shouldTriggerLocationRequestForUser(user) && !isSystemGpsGranted) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        // Smart GPS Background Location Controller Card
        SmartGpsControlCard(
            userRole = user?.role ?: "STUDENT",
            parentManualToggle = parentManualGpsToggle,
            isDriverTripActive = isDriverTripActive,
            onParentToggleChange = { viewModel.setParentManualGpsToggle(it) },
            onStartDriverTrip = { viewModel.startDriverTrip() },
            onEndDriverTrip = { viewModel.endDriverTrip() },
            lang = lang
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (isStudent) {
            // Student specific: DO NOT show map. Instead, show GPS state and Personal QR Code
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (lang == "ar") "📡 خدمة تتبع الموقع ونظام الأذونات الجغرافية" else "📡 Geolocation Tracker & Permission Service",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    var gpsToggleEnabled by remember { mutableStateOf(true) }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == "ar") "مشاركة الموقع التلقائي (GPS Tracking)" else "Automatic GPS Location Sharing",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (lang == "ar") "تفعيل تتبع الموقع الجغرافي بالخلفية لإرسال إحداثيات خطوط الطول والعرض لولي أمرك والمعلم." else "Enables real-time background tracking to securely sync coordinates with your parent and teacher.",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        Switch(
                            checked = gpsToggleEnabled && isSystemGpsGranted,
                            onCheckedChange = { 
                                if (it) {
                                    permissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                                gpsToggleEnabled = it
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Device System Level GPS state info box
                    val permissionStatusText = if (isSystemGpsGranted) {
                        if (lang == "ar") "✅ إذن تحديد الموقع الجغرافي (GPS) ممنوح على النظام وهو نشط حالياً." else "✅ System GPS Location Permission is GRANTED and currently active."
                    } else {
                        if (lang == "ar") "⚠️ إذن الموقع معطل! اضغط على الزر أدناه لتفعيل الـ GPS ومشاركة موقعك." else "⚠️ Location permission is DENIED! Tap request button below to enable GPS tracking."
                    }
                    val statusBgColor = if (isSystemGpsGranted) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                    val statusTextColor = if (isSystemGpsGranted) Color(0xFF2E7D32) else Color(0xFFC62828)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(statusBgColor, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = permissionStatusText,
                            color = statusTextColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    if (!isSystemGpsGranted) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.GpsFixed, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (lang == "ar") "منح إذن الـ GPS يدوياً" else "Grant GPS Permission")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Draw Student's QR code
            StudentQrCode(studentId = user.userId, modifier = Modifier.fillMaxWidth())

        } else {
            // PARENT or TEACHER View: Map and Active Tracking Controls
            if (user?.role == "TEACHER") {
                val teacherGrade = user.teacherGrade
                val teacherStudents = if (teacherGrade != null) {
                    students.filter { it.studentGrade == teacherGrade }
                } else {
                    emptyList()
                }

                if (teacherGrade == null) {
                    TeacherGradeActivationSection(viewModel = viewModel, lang = lang)
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang == "ar") "🏫 الصف الدراسي النشط: $teacherGrade" else "🏫 Active Tracking Class: $teacherGrade",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (lang == "ar") "كود التفعيل: ${user.teacherClassCode}" else "Activation Code: ${user.teacherClassCode}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            TextButton(onClick = { viewModel.deactivateTeacherGrade() }) {
                                Text(if (lang == "ar") "تغيير الصف" else "Change Grade", color = Color.Red, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    TeacherDashboardSection(
                        viewModel = viewModel,
                        lang = lang,
                        teacherStudents = teacherStudents,
                        statuses = statuses
                    )
                }
            } else {
                val isAuthorized = GeolocationPermissionService.isTrackingAuthorized(user, studentId)

                if (user?.role == "PARENT" && user.linkedStudentId == null) {
                    // Link account card if not linked
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "🔗 ربط حساب الطالب التابع لك",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "لم تقم بربط حساب ابنك الطالب حتى الآن لمتابعته. يرجى إدخال كود الطالب أو المسح السريع.",
                                fontSize = 12.sp,
                                color = Color.DarkGray
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            var inputCode by remember { mutableStateOf("") }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = inputCode,
                                    onValueChange = { inputCode = it },
                                    placeholder = { Text("مثال: student_1") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )
                                Button(
                                    onClick = { viewModel.linkStudentByQr(inputCode.trim()) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("ربط")
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Button(
                                onClick = { viewModel.linkStudentByQr("student_1") },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("المسح السريع لرمز الابن (Auto Link)")
                            }
                        }
                    }
                } else if (!isAuthorized) {
                    // Access Restricted Card for Unauthorized profile
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.1f)
                        ),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Access Restricted",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (lang == "ar") "🚨 الوصول مرفوض: البيانات مشفرة ومحمية" else "🚨 Access Denied: Secured Telemetry Data",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (lang == "ar") "بموجب سياسة حماية بيانات الطالب في مدرسة WE التكنولوجية، فإن الموقع الجغرافي للمسار وسجل الحضور والاتصال بالخلفية متاح فقط لولي الأمر المرتبط بهذا الحساب تحديداً أو للمشرف التربوي المسؤول." 
                                       else "Under the WE School, Port Said privacy policy, live GPS tracking, background connection state, and historic commute logs are restricted exclusively to the linked parent or authorized educator.",
                                fontSize = 12.sp,
                                color = Color.DarkGray,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    // Live tracking status card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            val currentStudent = students.find { it.userId == studentId }
                            Text(
                                text = "${getT(lang, "linked_status")} ${currentStudent?.fullName ?: "يوسف أحمد عبد الرحمن"}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            val stateText = when {
                                studentStatus?.isDeviated == true -> getT(lang, "deviated_status")
                                studentStatus?.isAtSchool == true -> getT(lang, "at_school")
                                studentStatus?.isAtHome == true -> getT(lang, "at_home")
                                else -> getT(lang, "on_way")
                            }
                            val stateColor = if (studentStatus?.isDeviated == true) Color.Red else Color(0xFF4CAF50)

                            Text(
                                text = stateText,
                                fontWeight = FontWeight.Bold,
                                color = stateColor,
                                fontSize = 15.sp
                            )

                            Text(
                                text = getT(lang, "gps_rules"),
                                fontSize = 10.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            val busEtaInfo = viewModel.getEstimatedArrivalTime(
                                currentLat = studentStatus?.currentLat ?: (viewModel.homeLocation.value?.first?.toDouble() ?: 200.0),
                                currentLng = studentStatus?.currentLng ?: (viewModel.homeLocation.value?.second?.toDouble() ?: 600.0),
                                isAtSchool = studentStatus?.isAtSchool ?: false,
                                isAtHome = studentStatus?.isAtHome ?: false,
                                trafficCond = trafficCondition,
                                weatherCond = weatherCondition
                            )

                            Divider(modifier = Modifier.padding(vertical = 10.dp), color = Color.LightGray.copy(alpha = 0.5f))

                            // Firebase Realtime Database Live Sync Status Badge
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFFFF3E0), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color(0xFFFFB74D), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE65100))
                                        )
                                        Text(
                                            text = if (lang == "ar") "🔥 Firebase Realtime DB: تتبع حي ومباشر" else "🔥 Firebase Realtime DB: Live Sync Active",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFE65100)
                                        )
                                    }
                                    Text(
                                        text = if (lang == "ar") "السرعة: ${busLocationData.speedKmh.toInt()} كم/س" else "Speed: ${busLocationData.speedKmh.toInt()} km/h",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Bus & Driver details container
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFE8F5E9), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = busLocationData.busName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF1B5E20)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "👨‍✈️ ${busLocationData.driverName} • 📞 ${busLocationData.driverPhone}",
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (lang == "ar") "📍 المحطة التالية: ${busLocationData.nextStop}" else "📍 Next Stop: ${busLocationData.nextStop}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsBus,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = getT(lang, "eta_calc_title"),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = getT(lang, "bus_progress"),
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "${busEtaInfo.progressPercent.toInt()}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                LinearProgressIndicator(
                                    progress = { busEtaInfo.progressPercent / 100f },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = Color.LightGray.copy(alpha = 0.3f),
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Timer,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = getT(lang, "eta_label"),
                                            fontSize = 11.sp,
                                            color = Color.DarkGray
                                        )
                                    }
                                    Text(
                                        text = if (busEtaInfo.remainingMinutes == 0) {
                                            getT(lang, "eta_arrived")
                                        } else {
                                            if (lang == "ar") "${busEtaInfo.remainingMinutes} دقيقة" else "${busEtaInfo.remainingMinutes} mins"
                                        },
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (busEtaInfo.remainingMinutes == 0) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = if (lang == "ar") busEtaInfo.statusTextAr else busEtaInfo.statusTextEn,
                                    fontSize = 11.sp,
                                    color = Color.DarkGray,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = getT(lang, "traffic_level"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val trafficOptions = listOf(
                                    Triple("NORMAL", getT(lang, "normal_traffic"), Color(0xFF4CAF50)),
                                    Triple("MODERATE", getT(lang, "moderate_traffic"), Color(0xFFFF9800)),
                                    Triple("HEAVY", getT(lang, "heavy_traffic"), Color(0xFFF44336)),
                                    Triple("BLOCKED", getT(lang, "blocked_traffic"), Color(0xFF9C27B0))
                                )

                                trafficOptions.forEach { (optionCode, optionLabel, optionColor) ->
                                    val isSelected = trafficCondition == optionCode
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isSelected) optionColor.copy(alpha = 0.15f) else Color(0xFFF9F9F9)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) optionColor else Color.LightGray.copy(alpha = 0.5f),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                viewModel.setTrafficCondition(optionCode)
                                            }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = optionLabel,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) optionColor else Color.Gray,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = getT(lang, "weather_level"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val weatherOptions = listOf(
                                    Triple("SUNNY", getT(lang, "sunny_weather"), Color(0xFFFFB300)),
                                    Triple("RAINY", getT(lang, "rainy_weather"), Color(0xFF1E88E5)),
                                    Triple("FOGGY", getT(lang, "foggy_weather"), Color(0xFF757575)),
                                    Triple("SANDSTORM", getT(lang, "sandstorm_weather"), Color(0xFF8D6E63))
                                )

                                weatherOptions.forEach { (optionCode, optionLabel, optionColor) ->
                                    val isSelected = weatherCondition == optionCode
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isSelected) optionColor.copy(alpha = 0.15f) else Color(0xFFF9F9F9)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) optionColor else Color.LightGray.copy(alpha = 0.5f),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                viewModel.setWeatherCondition(optionCode)
                                            }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = optionLabel,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) optionColor else Color.Gray,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Firebase Cloud Messaging (FCM) Proximity Alert Configuration
            FcmProximityAlertSettingsCard(viewModel = viewModel, lang = lang)

            Spacer(modifier = Modifier.height(10.dp))

            // Map View Box
            val homeX = viewModel.homeLocation.value?.first ?: 150f
            val homeY = viewModel.homeLocation.value?.second ?: 580f
            val schoolX = viewModel.schoolLocation.value?.first ?: 580f
            val schoolY = viewModel.schoolLocation.value?.second ?: 180f

            val currentX = studentStatus?.currentLat?.toFloat() ?: homeX
            val currentY = studentStatus?.currentLng?.toFloat() ?: homeY

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF1F6F4))
                    .border(1.dp, Color.LightGray, RoundedCornerShape(16.dp))
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseRadius by infiniteTransition.animateFloat(
                    initialValue = 15f,
                    targetValue = 40f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "pulseRadius"
                )

                val themePrimary = MaterialTheme.colorScheme.primary
                val themeSecondary = MaterialTheme.colorScheme.secondary

                Canvas(modifier = Modifier.fillMaxSize()) {
                    // 1. Draw OpenStreetMap-style light greenish/beige background
                    drawRect(color = Color(0xFFF1F6F4))

                    // 2. Draw some green parks (OSM Forest/Park areas)
                    drawRect(
                        color = Color(0xFFD4ECD5),
                        topLeft = Offset(50f, 50f),
                        size = androidx.compose.ui.geometry.Size(220f, 180f)
                    )
                    drawRect(
                        color = Color(0xFFD4ECD5),
                        topLeft = Offset(size.width - 250f, size.height - 120f),
                        size = androidx.compose.ui.geometry.Size(200f, 100f)
                    )

                    // 3. Draw a beautiful water body / river (OSM Water)
                    val waterPath = androidx.compose.ui.graphics.Path().apply {
                        moveTo(0f, size.height * 0.4f)
                        cubicTo(
                            size.width * 0.3f, size.height * 0.3f,
                            size.width * 0.7f, size.height * 0.6f,
                            size.width, size.height * 0.5f
                        )
                        lineTo(size.width, size.height * 0.6f)
                        cubicTo(
                            size.width * 0.7f, size.height * 0.7f,
                            size.width * 0.3f, size.height * 0.4f,
                            0f, size.height * 0.5f
                        )
                        close()
                    }
                    drawPath(path = waterPath, color = Color(0xFFA9D0F5))

                    // 4. Draw decorative secondary gray/white streets
                    val streetColor = Color(0xFFE5E9E7)
                    for (i in 1..4) {
                        val xPos = size.width * (i / 5f)
                        drawLine(
                            color = streetColor,
                            start = Offset(xPos, 0f),
                            end = Offset(xPos, size.height),
                            strokeWidth = 14f
                        )
                        drawLine(
                            color = Color.White,
                            start = Offset(xPos, 0f),
                            end = Offset(xPos, size.height),
                            strokeWidth = 4f
                        )
                    }
                    for (i in 1..4) {
                        val yPos = size.height * (i / 5f)
                        drawLine(
                            color = streetColor,
                            start = Offset(0f, yPos),
                            end = Offset(size.width, yPos),
                            strokeWidth = 14f
                        )
                        drawLine(
                            color = Color.White,
                            start = Offset(0f, yPos),
                            end = Offset(size.width, yPos),
                            strokeWidth = 4f
                        )
                    }

                    val isTeacher = user?.role == "TEACHER"
                    val studentHomes = mapOf(
                        "student_1" to Pair(220f, 580f),
                        "student_2" to Pair(180f, 540f),
                        "student_3" to Pair(260f, 620f)
                    )
                    val targetSchoolX = 580f
                    val targetSchoolY = 220f

                    if (isTeacher) {
                        val activeGrade = user?.teacherGrade
                        val teacherStudentsOnMap = students.filter { it.studentGrade == activeGrade }
                        
                        // Draw routes for active students only
                        teacherStudentsOnMap.forEach { s ->
                            val homeLoc = studentHomes[s.userId] ?: Pair(220f, 580f)
                            val hX = homeLoc.first
                            val hY = homeLoc.second
                            
                            drawLine(
                                color = Color(0xFFB0BEC5), // Border outline of route street
                                start = Offset(hX, hY),
                                end = Offset(targetSchoolX, targetSchoolY),
                                strokeWidth = 20f
                            )
                            drawLine(
                                color = Color(0xFFFFE082), // Yellow primary road filling
                                start = Offset(hX, hY),
                                end = Offset(targetSchoolX, targetSchoolY),
                                strokeWidth = 14f
                            )
                            drawLine(
                                color = themePrimary,
                                start = Offset(hX, hY),
                                end = Offset(targetSchoolX, targetSchoolY),
                                strokeWidth = 3f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                            )
                        }

                        // Draw Home pins for active students
                        teacherStudentsOnMap.forEach { s ->
                            val homeLoc = studentHomes[s.userId] ?: Pair(220f, 580f)
                            drawCircle(color = Color(0xFF4CAF50), radius = 14f, center = Offset(homeLoc.first, homeLoc.second))
                            drawCircle(color = Color.White, radius = 5f, center = Offset(homeLoc.first, homeLoc.second))
                        }

                        // Draw School pin (always draw if teacher has any active students)
                        if (teacherStudentsOnMap.isNotEmpty()) {
                            drawCircle(color = Color(0xFFE91E63), radius = 18f, center = Offset(targetSchoolX, targetSchoolY))
                            drawCircle(color = Color.White, radius = 7f, center = Offset(targetSchoolX, targetSchoolY))
                        }

                        // Draw current positions with deviation dashed lines if any
                        teacherStudentsOnMap.forEach { s ->
                            val sId = s.userId
                            val sStatus = statuses[sId]
                            val sHome = studentHomes[sId] ?: Pair(220f, 580f)
                            val curX = sStatus?.currentLat?.toFloat() ?: sHome.first
                            val curY = sStatus?.currentLng?.toFloat() ?: sHome.second

                            if (sStatus?.isDeviated == true) {
                                drawCircle(
                                    color = Color.Red.copy(alpha = 0.3f),
                                    radius = pulseRadius,
                                    center = Offset(curX, curY)
                                )
                                drawLine(
                                    color = Color.Red,
                                    start = Offset(curX, curY),
                                    end = Offset((sHome.first + targetSchoolX)/2f, (sHome.second + targetSchoolY)/2f),
                                    strokeWidth = 3f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
                                )
                            }

                            val studentColor = if (sStatus?.isDeviated == true) Color.Red else themeSecondary
                            drawCircle(color = studentColor, radius = 13f, center = Offset(curX, curY))
                            drawCircle(color = Color.White, radius = 5f, center = Offset(curX, curY))
                        }

                    } else {
                        // Original Single student path and pins
                        drawLine(
                            color = Color(0xFFB0BEC5), // Border outline of route street
                            start = Offset(homeX, homeY),
                            end = Offset(schoolX, schoolY),
                            strokeWidth = 24f
                        )
                        drawLine(
                            color = Color(0xFFFFE082), // Yellow primary road filling
                            start = Offset(homeX, homeY),
                            end = Offset(schoolX, schoolY),
                            strokeWidth = 16f
                        )
                        drawLine(
                            color = themePrimary,
                            start = Offset(homeX, homeY),
                            end = Offset(schoolX, schoolY),
                            strokeWidth = 3f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )

                        // Home pin
                        drawCircle(color = Color(0xFF4CAF50), radius = 18f, center = Offset(homeX, homeY))
                        drawCircle(color = Color.White, radius = 7f, center = Offset(homeX, homeY))

                        // School pin
                        drawCircle(color = Color(0xFFE91E63), radius = 18f, center = Offset(schoolX, schoolY))
                        drawCircle(color = Color.White, radius = 7f, center = Offset(schoolX, schoolY))

                        // Deviation line
                        if (studentStatus?.isDeviated == true) {
                            drawCircle(
                                color = Color.Red.copy(alpha = 0.3f),
                                radius = pulseRadius,
                                center = Offset(currentX, currentY)
                            )
                            drawLine(
                                color = Color.Red,
                                start = Offset(currentX, currentY),
                                end = Offset((homeX + schoolX)/2f, (homeY + schoolY)/2f),
                                strokeWidth = 3f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
                            )
                        }

                        // Current position
                        val studentColor = if (studentStatus?.isDeviated == true) Color.Red else themeSecondary
                        drawCircle(color = studentColor, radius = 15f, center = Offset(currentX, currentY))
                        drawCircle(color = Color.White, radius = 6f, center = Offset(currentX, currentY))
                    }
                }

                val density = LocalDensity.current
                val isTeacher = user?.role == "TEACHER"
                val studentHomes = mapOf(
                    "student_1" to Pair(220f, 580f),
                    "student_2" to Pair(180f, 540f),
                    "student_3" to Pair(260f, 620f)
                )
                val targetSchoolX = 580f
                val targetSchoolY = 220f

                if (isTeacher) {
                    val activeGrade = user?.teacherGrade
                    val teacherStudentsOnMap = students.filter { it.studentGrade == activeGrade }
                    val teacherStudentIds = teacherStudentsOnMap.map { it.userId }

                    // Draw Home Pins for active students only
                    studentHomes.filterKeys { it in teacherStudentIds }.forEach { (sId, homeLoc) ->
                        val hXDp = with(density) { homeLoc.first.toDp() }
                        val hYDp = with(density) { homeLoc.second.toDp() }
                        Box(
                            modifier = Modifier
                                .offset(hXDp - 10.dp, hYDp - 10.dp)
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF4CAF50)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Home, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                        }
                    }

                    // Draw School Pin (only if teacher has active students on map)
                    if (teacherStudentsOnMap.isNotEmpty()) {
                        val sXDp = with(density) { targetSchoolX.toDp() }
                        val sYDp = with(density) { targetSchoolY.toDp() }
                        Box(
                            modifier = Modifier
                                .offset(sXDp - 12.dp, sYDp - 12.dp)
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE91E63)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.School, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                        }
                    }

                    // Draw Walking avatars for active students only
                    teacherStudentIds.forEach { sId ->
                        val sStatus = statuses[sId]
                        val sHome = studentHomes[sId] ?: Pair(220f, 580f)
                        val curX = sStatus?.currentLat?.toFloat() ?: sHome.first
                        val curY = sStatus?.currentLng?.toFloat() ?: sHome.second

                        val curXDp = with(density) { curX.toDp() }
                        val curYDp = with(density) { curY.toDp() }

                        val isFocused = (studentId == sId)

                        Box(
                            modifier = Modifier
                                .offset(curXDp - 14.dp, curYDp - 14.dp)
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(if (sStatus?.isDeviated == true) Color.Red else if (isFocused) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary)
                                .border(if (isFocused) 3.dp else 2.dp, if (isFocused) Color.Yellow else Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (sStatus?.isDeviated == true) Icons.Default.Warning else Icons.Default.DirectionsWalk,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                } else {
                    val homeXDp = with(density) { homeX.toDp() }
                    val homeYDp = with(density) { homeY.toDp() }
                    val schoolXDp = with(density) { schoolX.toDp() }
                    val schoolYDp = with(density) { schoolY.toDp() }
                    val currentXDp = with(density) { currentX.toDp() }
                    val currentYDp = with(density) { currentY.toDp() }

                    // Original single student overlay pins
                    Box(
                        modifier = Modifier
                            .offset(homeXDp - 12.dp, homeYDp - 12.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF4CAF50)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                    }

                    Box(
                        modifier = Modifier
                            .offset(schoolXDp - 12.dp, schoolYDp - 12.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE91E63)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.School, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                    }

                    // Walking avatar on map
                    Box(
                        modifier = Modifier
                            .offset(currentXDp - 14.dp, currentYDp - 14.dp)
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (studentStatus?.isDeviated == true) Color.Red else MaterialTheme.colorScheme.primary)
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (studentStatus?.isDeviated == true) Icons.Default.Warning else Icons.Default.DirectionsWalk,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // School Bus Icon with live pulse ring on map
                    val busProgressNorm = (busLocationData.routeProgress / 100f).coerceIn(0f, 1f)
                    val busXDp = with(density) { (homeX + busProgressNorm * (schoolX - homeX)).toDp() }
                    val busYDp = with(density) { (homeY + busProgressNorm * (schoolY - homeY)).toDp() }

                    Box(
                        modifier = Modifier
                            .offset(busXDp - 18.dp, busYDp - 18.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFB300))
                            .border(2.5.dp, MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsBus,
                            contentDescription = "School Bus",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // OSM Attribution Badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.85f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "© OpenStreetMap",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Card for starting/stopping real-time Firebase Bus GPS Stream
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == "ar") "🚌 بث إحداثيات الحافلة المباشر (Firebase DB)" else "🚌 Live Bus GPS Stream (Firebase DB)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (lang == "ar") "تحديث خطوط الطول والعرض والسرعة والمحطة القادمة لحظياً في قاعدة بيانات الفايربيس." else "Pushes live latitude, longitude, speed & stop data to Firebase Realtime DB.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
                    Button(
                        onClick = { viewModel.toggleSimulation() },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSimulating) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = if (isSimulating) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isSimulating) (if (lang == "ar") "إيقاف" else "Stop") else (if (lang == "ar") "تفعيل البث" else "Live GPS"),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bus Location History & Firebase Offline Persistence Component for Parents
            BusLocationHistoryOfflineComponent(
                busLocationData = busLocationData,
                busLocationHistory = busLocationHistory,
                lang = lang
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Daily Student Schedule & Class Route Info Component
        DailyScheduleAndRouteComponent(lang = lang)

        Spacer(modifier = Modifier.height(16.dp))

        // HISTORICAL COMMUTE LOGS LIST
        Text(
            text = if (lang == "ar") "📋 سجل حضور وانتقال الطلاب التاريخي" else "📋 Historical Commute Logs",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Filter logs for selected student or show all for teacher
        val filteredLogs = if (user?.role == "TEACHER") commuteLogs else commuteLogs.filter { it.studentId == studentId }

        if (filteredLogs.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (lang == "ar") "لا توجد سجلات رحلات حضور حتى الآن." else "No commute records found yet.",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                filteredLogs.forEach { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Event,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = log.date,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.Black
                                    )
                                }

                                // Status Tag
                                val (tagText, tagBg, tagTextCol) = when (log.status) {
                                    "ARRIVED" -> Triple(
                                        if (lang == "ar") "وصل بأمان ✅" else "Arrived Safely",
                                        Color(0xFFE8F5E9), Color(0xFF2E7D32)
                                    )
                                    "DEVIATED" -> Triple(
                                        if (lang == "ar") "🚨 انحرف عن المسار" else "Deviated",
                                        Color(0xFFFFEBEE), Color(0xFFC62828)
                                    )
                                    else -> Triple(
                                        if (lang == "ar") "في الطريق 🚶‍♂️" else "On designated path",
                                        Color(0xFFFFF3E0), Color(0xFFE65100)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(tagBg)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                  ) {
                                    Text(
                                        text = tagText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = tagTextCol
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Divider(color = Color.LightGray.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = if (lang == "ar") "الطالب" else "Student", fontSize = 11.sp, color = Color.Gray)
                                    Text(text = log.studentName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = if (lang == "ar") "الانطلاق" else "Departure", fontSize = 11.sp, color = Color.Gray)
                                    Text(text = log.departureTime, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = if (lang == "ar") "الوصول" else "Arrival", fontSize = 11.sp, color = Color.Gray)
                                    Text(text = log.arrivalTime, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// DAILY STUDENT SCHEDULE & CLASS BUS ROUTE INFO COMPONENT
// -------------------------------------------------------------
@Composable
fun DailyScheduleAndRouteComponent(lang: String) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: Schedule, 1: Bus Route
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = if (lang == "ar") "📅 جدول اليوم ومعلومات المسار" else "📅 Daily Schedule & Route Info",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab switchers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    Pair(if (lang == "ar") "الجدول الدراسي" else "Daily Schedule", Icons.Default.Event),
                    Pair(if (lang == "ar") "تفاصيل الحافلة" else "Bus Route Info", Icons.Default.DirectionsBus)
                ).forEachIndexed { index, (label, icon) ->
                    val isSelected = selectedSubTab == index
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { selectedSubTab = index }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Content based on selectedSubTab
            if (selectedSubTab == 0) {
                // SCHEDULE TAB
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val periods = listOf(
                        Triple(
                            if (lang == "ar") "الحصة الأولى" else "Period 1",
                            "08:30 AM - 10:00 AM",
                            if (lang == "ar") "الأساسيات التكنولوجية والبرمجة (القاعة 101)" else "Tech Fundamentals & Coding (Room 101)"
                        ),
                        Triple(
                            if (lang == "ar") "الحصة الثانية" else "Period 2",
                            "10:15 AM - 11:45 AM",
                            if (lang == "ar") "هندسة البرمجيات والويب (معمل B)" else "Software Engineering & Web (Lab B)"
                        ),
                        Triple(
                            if (lang == "ar") "فترة الاستراحة" else "Rest & Prayer Break",
                            "11:45 AM - 12:30 PM",
                            if (lang == "ar") "استراحة الغداء والصلاة (الفناء الرئيسي)" else "Lunch Break & Prayer (Main Yard)"
                        ),
                        Triple(
                            if (lang == "ar") "الحصة الثالثة" else "Period 3",
                            "12:30 PM - 02:00 PM",
                            if (lang == "ar") "الفيزياء التطبيقية والإلكترونيات (القاعة 103)" else "Applied Physics & Electronics (Room 103)"
                        )
                    )

                    periods.forEach { (title, time, subject) ->
                        val isActive = title.contains("2") || title.contains("الثانية")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color(0xFFF9F9F9))
                                .border(
                                    width = if (isActive) 1.5.dp else 1.dp,
                                    color = if (isActive) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(if (isActive) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (title.contains("استراحة") || title.contains("Break")) "☕" else title.last().toString(),
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) Color.White else Color.DarkGray,
                                    fontSize = 13.sp
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isActive) MaterialTheme.colorScheme.primary else Color.Black
                                    )
                                    Text(
                                        text = time,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isActive) MaterialTheme.colorScheme.primary else Color.Gray
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = subject,
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            } else {
                // BUS ROUTE TAB
                Column {
                    // Driver Card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF9F9F9))
                            .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = if (lang == "ar") "حافلة مدرسة WE الذكية #14" else "WE Smart Bus #14",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color.Black
                                )
                                Text(
                                    text = if (lang == "ar") "السائق: كابتن أحمد سالم" else "Driver: Capt. Ahmed Salem",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                android.widget.Toast.makeText(
                                    context,
                                    if (lang == "ar") "جاري الاتصال بالكابتن أحمد سالم: +20 102 345 6789" 
                                    else "Calling Captain Ahmed Salem at +20 102 345 6789...",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Call Driver",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Route Milestone Timeline
                    Text(
                        text = if (lang == "ar") "📍 محطات ومخطط مسار الرحلة التكنولوجي" else "📍 Commute Route Milestones",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    val milestones = listOf(
                        Triple(
                            if (lang == "ar") "نقطة الانطلاق (المنزل)" else "Home Station (Pickup)",
                            "07:15 AM",
                            true
                        ),
                        Triple(
                            if (lang == "ar") "محطة تجمع بور سعيد الشرقية" else "Port Said East Transit",
                            "07:45 AM",
                            true
                        ),
                        Triple(
                            if (lang == "ar") "بوابة مدرسة WE التكنولوجية" else "WE School, Port Said Gate",
                            "08:10 AM",
                            false
                        )
                    )

                    milestones.forEachIndexed { idx, (station, time, hasNext) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(20.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(if (idx == 2) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary)
                                        .border(2.dp, Color.White, CircleShape)
                                )
                                if (hasNext) {
                                    Box(
                                        modifier = Modifier
                                            .width(2.dp)
                                            .height(32.dp)
                                            .background(Color.LightGray)
                                    )
                                }
                            }

                            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = station,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = time,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Text(
                                    text = if (idx == 2) {
                                        if (lang == "ar") "محطة الوصول النهائية وبدء اليوم الدراسي" else "Final Dropoff and class check-in"
                                    } else {
                                        if (lang == "ar") "المحطة النشطة للمرور السريع" else "Transit checkpoint verification"
                                    },
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 1: CHATS LIST & GROUP CHATS WITH CHAT SUB-TABS
// -------------------------------------------------------------
@Composable
fun ChatsListTab(
    viewModel: SchoolViewModel,
    lang: String,
    user: UserEntity?,
    students: List<UserEntity>
) {
    var subTab by remember { mutableStateOf(0) } // 0: Direct Chats, 1: School Groups
    val groups by viewModel.groupsList.collectAsStateWithLifecycle()
    val selectedGroup by viewModel.selectedGroup.collectAsStateWithLifecycle()

    var showCreateGroupDialog by remember { mutableStateOf(false) }

    if (selectedGroup != null) {
        // Render Group Chat inside Dashboard nested layer
        GroupChatScreen(viewModel = viewModel, lang = lang, group = selectedGroup!!, students = students)
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Sub Tabs Header
            TabRow(
                selectedTabIndex = subTab,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = (subTab == 0),
                    onClick = { subTab = 0 },
                    text = { Text(if (lang == "ar") "المحادثات الثنائية" else "Direct Chats", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = (subTab == 1),
                    onClick = { subTab = 1 },
                    text = { Text(if (lang == "ar") "المجموعات المدرسية" else "Group Chats", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (subTab == 0) {
                // Direct chats Contact list (Excluding blocked users)
                val chatContacts = when (user?.role) {
                    "PARENT" -> {
                        students.filter { it.role == "TEACHER" && !viewModel.isUserBlocked(it.userId) }
                    }
                    "TEACHER" -> {
                        students.filter { (it.role == "PARENT" || it.role == "STUDENT") && !viewModel.isUserBlocked(it.userId) }
                    }
                    else -> {
                        students.filter { it.role == "TEACHER" && !viewModel.isUserBlocked(it.userId) }
                    }
                }

                if (chatContacts.isEmpty() && false) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = "لا توجد جهات اتصال متاحة.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            val aiBotContact = UserEntity(
                                userId = "ai_bot",
                                email = "ai.assistant@we-school.edu.eg",
                                fullName = if (lang == "ar") "مساعد مدرسة WE الذكي (AI)" else "WE School AI Assistant",
                                phoneNumber = if (lang == "ar") "متاح ٢٤/٧ للرد الفوري" else "Available 24/7 for instant reply",
                                role = "AI_BOT",
                                avatarIndex = 5,
                                bio = if (lang == "ar") "مساعدك الذكي للإجابة على جميع استفسارات مدرسة WE بورسعيد التكنولوجية." else "Your personal AI assistant for all WE School Port Said inquiries."
                            )
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.startChat(aiBotContact) },
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                                ),
                                border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(Color(0xFF8E24AA), Color(0xFF00B4D8)))),
                                shape = RoundedCornerShape(16.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(avatarIndex = 5, size = 48.dp)
                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = aiBotContact.fullName,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            // AI Sparkle badge
                                            Surface(
                                                color = Color(0xFF8E24AA).copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.AutoAwesome,
                                                        contentDescription = "AI Powered",
                                                        tint = Color(0xFF8E24AA),
                                                        modifier = Modifier.size(10.dp)
                                                    )
                                                    Text(
                                                        text = if (lang == "ar") "مساعد ذكي" else "AI BOT",
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF8E24AA)
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = aiBotContact.phoneNumber,
                                            fontSize = 11.sp,
                                            color = Color.DarkGray,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = Color(0xFF00B4D8),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (lang == "ar") "أو تواصل مع الإدارة والمعلمين:" else "Or contact administration & teachers:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 4.dp)
                            )
                        }

                        if (chatContacts.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 40.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (lang == "ar") "لا توجد جهات اتصال أخرى متاحة حالياً." else "No other contacts available currently.",
                                        color = Color.Gray,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        } else {
                            items(chatContacts) { contact ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.startChat(contact) },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(avatarIndex = contact.avatarIndex, size = 44.dp)
                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = contact.fullName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color.Black
                                            )
                                            // Secure badge
                                            Surface(
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Lock,
                                                        contentDescription = "Secure",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(8.dp)
                                                    )
                                                    Text(
                                                        text = if (lang == "ar") "آمن" else "Secure",
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = "${contact.role} | ${contact.phoneNumber}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.Default.ChatBubble,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
                // School Groups
                Column(modifier = Modifier.fillMaxSize()) {
                    Button(
                        onClick = { showCreateGroupDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.GroupAdd, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (lang == "ar") "إنشاء مجموعة جديدة" else "Create New Group Chat")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val myGroups = groups.filter { group ->
                        val memberList = group.memberIds.split(",")
                        memberList.contains(user?.userId)
                    }

                    if (myGroups.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text(
                                text = "لم تنضم إلى أي مجموعة مدرسية بعد.",
                                color = Color.Gray,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(myGroups) { group ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.selectGroup(group) },
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(42.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Groups,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = group.groupName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                                Text(
                                                    text = "نوع المجموعة: ${group.groupType}",
                                                    fontSize = 11.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                        }

                                        Icon(
                                            imageVector = Icons.Default.ArrowForwardIos,
                                            contentDescription = null,
                                            tint = Color.LightGray,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // CREATE GROUP DIALOG
    if (showCreateGroupDialog) {
        var groupName by remember { mutableStateOf("") }
        var groupType by remember { mutableStateOf("PARENTS") } // PARENTS, STUDENTS, TEACHERS

        AlertDialog(
            onDismissRequest = { showCreateGroupDialog = false },
            title = { Text("إنشاء مجموعة جديدة 👥") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = groupName,
                        onValueChange = { groupName = it },
                        label = { Text("اسم المجموعة") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Text("تصنيف المجموعة المتخصصة:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("PARENTS", "STUDENTS", "TEACHERS").forEach { type ->
                            val isSelected = groupType == type
                            val label = when (type) {
                                "PARENTS" -> "أولياء الأمور"
                                "STUDENTS" -> "الطلاب"
                                else -> "المعلمون"
                            }
                            FilterChip(
                                selected = isSelected,
                                onClick = { groupType = type },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (groupName.isNotEmpty()) {
                            viewModel.createGroup(groupName, groupType)
                            showCreateGroupDialog = false
                        }
                    }
                ) {
                    Text("إنشاء")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateGroupDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// INTERNAL GROUP CHAT SCREEN COMPOSABLE
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupChatScreen(
    viewModel: SchoolViewModel,
    lang: String,
    group: GroupEntity,
    students: List<UserEntity>
) {
    val messages by viewModel.groupMessages.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    var messageText by remember { mutableStateOf("") }
    var showInviteDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
    ) {
        // Group Chat Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.selectGroup(null) }) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(text = group.groupName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = "مجموعة تفاعلية | ${group.groupType}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            }

            // Invite Member Icon
            IconButton(onClick = { showInviteDialog = true }) {
                Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, tint = Color.White)
            }
        }

        // Messages area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isMe = msg.senderId == user?.userId
                val alignment = if (isMe) Alignment.End else Alignment.Start
                val bubbleColor = if (isMe) MaterialTheme.colorScheme.primary else Color.White
                val textColor = if (isMe) Color.White else Color.Black

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = alignment
                ) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = bubbleColor),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            if (!isMe) {
                                Text(
                                    text = "${msg.senderName} (${msg.senderRole})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                            }
                            Text(text = msg.text, color = textColor, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Send bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    placeholder = { Text("اكتب رسالة للمجموعة...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = {
                        if (messageText.isNotEmpty()) {
                            viewModel.sendGroupMessage(messageText)
                            messageText = ""
                        }
                    }
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    // INVITE MEMBER DIALOG
    if (showInviteDialog) {
        val groupMembers = group.memberIds.split(",")
        // Filter users who can be invited (not already in group and not blocked)
        val inviteableUsers = students.filter { stu ->
            stu.userId != user?.userId && !groupMembers.contains(stu.userId) && !viewModel.isUserBlocked(stu.userId)
        }

        AlertDialog(
            onDismissRequest = { showInviteDialog = false },
            title = { Text("دعوة عضو للمجموعة 📩") },
            text = {
                if (inviteableUsers.isEmpty()) {
                    Text("لا توجد جهات اتصال متاحة لدعوتها.")
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(240.dp)
                    ) {
                        items(inviteableUsers) { invitee ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.inviteUserToGroup(group.groupId, invitee.userId)
                                        showInviteDialog = false
                                    }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(avatarIndex = invitee.avatarIndex, size = 32.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = invitee.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = invitee.role, color = Color.Gray, fontSize = 10.sp)
                                }
                            }
                            Divider()
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showInviteDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// TAB 2: SCHOOL TIMELINE SCREEN
// -------------------------------------------------------------
@Composable
fun TimelineTab(viewModel: SchoolViewModel, lang: String) {
    val posts by viewModel.timelinePosts.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    
    var newPostText by remember { mutableStateOf("") }

    // Filter out posts written by blocked authors
    val visiblePosts = posts.filter { post ->
        !viewModel.isUserBlocked(post.authorId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Text(
            text = if (lang == "ar") "📣 الحائط التفاعلي العام (Timeline)" else "📣 School Interactive Timeline",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Create new post card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                OutlinedTextField(
                    value = newPostText,
                    onValueChange = { newPostText = it },
                    placeholder = { Text(if (lang == "ar") "شارك بمنشور مع الجميع في مدرسة WE..." else "Share something with everyone...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (newPostText.isNotEmpty()) {
                            viewModel.addTimelinePost(newPostText)
                            newPostText = ""
                        }
                    },
                    modifier = Modifier.align(Alignment.End),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (lang == "ar") "نشر المنشور" else "Post Now")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (visiblePosts.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "لا توجد منشورات حالياً في التايم لاين.", color = Color.Gray)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(visiblePosts) { post ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header: Avatar, Name, Role
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    UserAvatar(avatarIndex = post.authorAvatarIndex, size = 42.dp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = post.authorName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            text = when (post.authorRole) {
                                                "TEACHER" -> "معلم مدرسة WE"
                                                "PARENT" -> "ولي أمر"
                                                else -> "طالب"
                                            },
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                // Header actions: block user or delete post
                                Row {
                                    if (post.authorId != user?.userId) {
                                        // Block author button
                                        IconButton(
                                            onClick = { viewModel.toggleBlockUser(post.authorId) }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Block,
                                                contentDescription = "حظر",
                                                tint = Color.Red.copy(alpha = 0.6f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    } else {
                                        // Delete button if it's my post
                                        IconButton(onClick = { viewModel.deleteTimelinePost(post) }) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = post.text,
                                fontSize = 13.sp,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// STUDENT EDIT AND ADD DIALOGS FOR TEACHERS & PARENTS
// -------------------------------------------------------------
@Composable
fun EditStudentDialog(
    student: UserEntity,
    onDismiss: () -> Unit,
    onSave: (
        fullName: String,
        quadName: String,
        grade: String,
        age: Int,
        gender: String,
        birthDate: String,
        hobby1: String,
        hobby2: String,
        hobby3: String,
        address: String,
        bio: String,
        avatarIndex: Int
    ) -> Unit
) {
    var fullName by remember { mutableStateOf(student.fullName) }
    var quadName by remember { mutableStateOf(student.quadName ?: "") }
    var grade by remember { mutableStateOf(student.studentGrade ?: "الصف الأول") }
    var age by remember { mutableStateOf(student.studentAge?.toString() ?: "16") }
    var gender by remember { mutableStateOf(student.studentGender ?: "ذكر") }
    var birthDate by remember { mutableStateOf(student.birthDate ?: "2010-01-01") }
    var hobby1 by remember { mutableStateOf(student.hobby1 ?: "") }
    var hobby2 by remember { mutableStateOf(student.hobby2 ?: "") }
    var hobby3 by remember { mutableStateOf(student.hobby3 ?: "") }
    var address by remember { mutableStateOf(student.address ?: "") }
    var bio by remember { mutableStateOf(student.bio ?: "") }
    var avatarIndex by remember { mutableStateOf(student.avatarIndex) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "📝 تعديل بيانات الطالب: ${student.fullName}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Avatars Selection
                Text("اختر الصورة الرمزية:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    (0..5).forEach { idx ->
                        Box(
                            modifier = Modifier
                                .clickable { avatarIndex = idx }
                                .border(
                                    width = if (avatarIndex == idx) 2.dp else 1.dp,
                                    color = if (avatarIndex == idx) MaterialTheme.colorScheme.primary else Color.LightGray,
                                    shape = CircleShape
                                )
                                .padding(2.dp)
                        ) {
                            UserAvatar(avatarIndex = idx, size = 28.dp)
                        }
                    }
                }

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("الاسم بالكامل") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = quadName,
                    onValueChange = { quadName = it },
                    label = { Text("الاسم رباعي بالكامل") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                // Grade Selector
                Text("الصف الدراسي:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf("الصف الأول", "الصف الثاني", "الصف الثالث").forEach { gr ->
                        FilterChip(
                            selected = (grade == gr),
                            onClick = { grade = gr },
                            label = { Text(gr, fontSize = 11.sp) }
                        )
                    }
                }

                // Age & Gender
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text("العمر") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("الجنس:", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("ذكر", "أنثى").forEach { gen ->
                                FilterChip(
                                    selected = (gender == gen),
                                    onClick = { gender = gen },
                                    label = { Text(gen, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = birthDate,
                    onValueChange = { birthDate = it },
                    label = { Text("تاريخ الميلاد (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Text("الهوايات والأنشطة (3 هوايات):", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = hobby1,
                        onValueChange = { hobby1 = it },
                        label = { Text("هواية ١", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hobby2,
                        onValueChange = { hobby2 = it },
                        label = { Text("هواية ٢", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hobby3,
                        onValueChange = { hobby3 = it },
                        label = { Text("هواية ٣", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("العنوان السكني") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("السيرة الذاتية (Bio)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        fullName,
                        quadName,
                        grade,
                        age.toIntOrNull() ?: 16,
                        gender,
                        birthDate,
                        hobby1,
                        hobby2,
                        hobby3,
                        address,
                        bio,
                        avatarIndex
                    )
                },
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("حفظ البيانات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun AddStudentDialog(
    teacherGrade: String,
    onDismiss: () -> Unit,
    onSave: (
        studentId: String,
        email: String,
        fullName: String,
        phoneNumber: String,
        grade: String,
        age: Int,
        gender: String,
        quadName: String,
        birthDate: String,
        hobby1: String,
        hobby2: String,
        hobby3: String,
        address: String,
        bio: String,
        avatarIndex: Int
    ) -> Unit
) {
    var studentId by remember { mutableStateOf("student_${System.currentTimeMillis().toString().takeLast(4)}") }
    var email by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf(teacherGrade) }
    var age by remember { mutableStateOf("16") }
    var gender by remember { mutableStateOf("ذكر") }
    var quadName by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("2010-01-01") }
    var hobby1 by remember { mutableStateOf("") }
    var hobby2 by remember { mutableStateOf("") }
    var hobby3 by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var avatarIndex by remember { mutableStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "➕ إضافة طالب جديد لمدرسة WE",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("اختر الصورة الرمزية:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    (0..5).forEach { idx ->
                        Box(
                            modifier = Modifier
                                .clickable { avatarIndex = idx }
                                .border(
                                    width = if (avatarIndex == idx) 2.dp else 1.dp,
                                    color = if (avatarIndex == idx) MaterialTheme.colorScheme.primary else Color.LightGray,
                                    shape = CircleShape
                                )
                                .padding(2.dp)
                        ) {
                            UserAvatar(avatarIndex = idx, size = 28.dp)
                        }
                    }
                }

                OutlinedTextField(
                    value = studentId,
                    onValueChange = { studentId = it },
                    label = { Text("كود الطالب الفريد (UserID/Code)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("الاسم بالكامل") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("البريد الإلكتروني للتعليمي") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    label = { Text("رقم الهاتف") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = quadName,
                    onValueChange = { quadName = it },
                    label = { Text("الاسم رباعي بالكامل") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                // Grade Selector
                Text("الصف الدراسي:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf("الصف الأول", "الصف الثاني", "الصف الثالث").forEach { gr ->
                        FilterChip(
                            selected = (grade == gr),
                            onClick = { grade = gr },
                            label = { Text(gr, fontSize = 11.sp) }
                        )
                    }
                }

                // Age & Gender
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text("العمر") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("الجنس:", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("ذكر", "أنثى").forEach { gen ->
                                FilterChip(
                                    selected = (gender == gen),
                                    onClick = { gender = gen },
                                    label = { Text(gen, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = birthDate,
                    onValueChange = { birthDate = it },
                    label = { Text("تاريخ الميلاد (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Text("الهوايات والأنشطة (3 هوايات):", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = hobby1,
                        onValueChange = { hobby1 = it },
                        label = { Text("هواية ١", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hobby2,
                        onValueChange = { hobby2 = it },
                        label = { Text("هواية ٢", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hobby3,
                        onValueChange = { hobby3 = it },
                        label = { Text("هواية ٣", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("العنوان السكني") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("السيرة الذاتية (Bio)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        studentId,
                        email,
                        fullName,
                        phoneNumber,
                        grade,
                        age.toIntOrNull() ?: 16,
                        gender,
                        quadName,
                        birthDate,
                        hobby1,
                        hobby2,
                        hobby3,
                        address,
                        bio,
                        avatarIndex
                    )
                },
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("إضافة الطالب")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

// -------------------------------------------------------------
// TAB 3: USER COMPREHENSIVE PROFILE SCREEN
// -------------------------------------------------------------
@Composable
fun ProfileTab(viewModel: SchoolViewModel, lang: String) {
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val students by viewModel.studentsList.collectAsStateWithLifecycle()

    var isEditing by remember { mutableStateOf(false) }

    // Local form state
    var quadName by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var hobby1 by remember { mutableStateOf("") }
    var hobby2 by remember { mutableStateOf("") }
    var hobby3 by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var avatarIndex by remember { mutableStateOf(0) }
    var isProfileHidden by remember { mutableStateOf(false) }

    // Load initial profile data
    LaunchedEffect(user, isEditing) {
        user?.let { u ->
            quadName = u.quadName ?: u.fullName
            grade = u.studentGrade ?: "الصف الأول"
            gender = u.studentGender ?: "ذكر"
            birthDate = u.birthDate ?: "2010-01-01"
            hobby1 = u.hobby1 ?: ""
            hobby2 = u.hobby2 ?: ""
            hobby3 = u.hobby3 ?: ""
            address = u.address ?: ""
            bio = u.bio ?: ""
            avatarIndex = u.avatarIndex
            isProfileHidden = u.isProfileHidden
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = if (lang == "ar") "👤 إدارة الملف الشخصي والتواصل" else "👤 Profile & Interaction Settings",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Profile Card header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                UserAvatar(avatarIndex = avatarIndex, size = 80.dp)
                Spacer(modifier = Modifier.height(10.dp))
                
                if (isEditing) {
                    Text("اختر الصورة الرمزية (Avatar):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        (0..5).forEach { idx ->
                            Box(
                                modifier = Modifier
                                    .clickable { avatarIndex = idx }
                                    .border(
                                        width = if (avatarIndex == idx) 3.dp else 1.dp,
                                        color = if (avatarIndex == idx) MaterialTheme.colorScheme.primary else Color.LightGray,
                                        shape = CircleShape
                                    )
                                    .padding(2.dp)
                            ) {
                                UserAvatar(avatarIndex = idx, size = 32.dp)
                            }
                        }
                    }
                } else {
                    Text(text = user?.fullName ?: "", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(text = "الحساب: ${user?.role} | ${user?.email}", color = Color.Gray, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(Color(0xFFE8F5E9), shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudDone,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "موثّق بـ Google Cloud (OAuth 2.0)",
                            color = Color(0xFF2E7D32),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Form Fields
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                
                // Quad Name
                OutlinedTextField(
                    value = quadName,
                    onValueChange = { quadName = it },
                    label = { Text("الاسم رباعي بالكامل") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    enabled = isEditing
                )

                // Grade (Only for Students)
                if (user?.role == "STUDENT") {
                    Text("الصف الدراسي:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("الصف الأول", "الصف الثاني", "الصف الثالث").forEach { gr ->
                            FilterChip(
                                selected = (grade == gr),
                                onClick = { if (isEditing) grade = gr },
                                label = { Text(gr) },
                                enabled = isEditing || !isEditing
                            )
                        }
                    }
                }

                // Gender
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("الجنس:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(0.3f))
                    Row(modifier = Modifier.weight(0.7f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("ذكر", "أنثى").forEach { gen ->
                            FilterChip(
                                selected = (gender == gen),
                                onClick = { if (isEditing) gender = gen },
                                label = { Text(gen) },
                                enabled = isEditing || !isEditing
                            )
                        }
                    }
                }

                // Birthdate Formatted Field with quick manual & selector helper
                var showBirthDatePicker by remember { mutableStateOf(false) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = birthDate,
                        onValueChange = { birthDate = it },
                        label = { Text("تاريخ الميلاد (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        enabled = isEditing
                    )
                    if (isEditing) {
                        IconButton(onClick = { showBirthDatePicker = true }) {
                            Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                // Date Picker Dialog Simulator for fast birthdate entry
                if (showBirthDatePicker) {
                    AlertDialog(
                        onDismissRequest = { showBirthDatePicker = false },
                        title = { Text("اختر سنة الميلاد 🗓️") },
                        text = {
                            Column {
                                Text("اختر سنة من القائمة لسهولة وسرعة الكتابة:")
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    listOf("1980", "1985", "1990", "1995", "2000", "2005", "2010", "2011", "2012").forEach { yr ->
                                        Button(
                                            onClick = {
                                                birthDate = "$yr-01-01"
                                                showBirthDatePicker = false
                                            }
                                        ) {
                                            Text(yr)
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {},
                        dismissButton = {
                            TextButton(onClick = { showBirthDatePicker = false }) { Text("إلغاء") }
                        }
                    )
                }

                // 3 Hobbies
                Text("الهوايات والأنشطة المفضلة (3 هوايات):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = hobby1,
                        onValueChange = { hobby1 = it },
                        label = { Text("هواية ١") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        enabled = isEditing,
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hobby2,
                        onValueChange = { hobby2 = it },
                        label = { Text("هواية ٢") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        enabled = isEditing,
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hobby3,
                        onValueChange = { hobby3 = it },
                        label = { Text("هواية ٣") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        enabled = isEditing,
                        singleLine = true
                    )
                }

                // Address
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("العنوان السكني الحالي") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    enabled = isEditing
                )

                // Biography
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("السيرة الذاتية (Bio)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    enabled = isEditing,
                    maxLines = 3
                )

                // Privacy Switch: Hide Profile (Only for students to hide from other students)
                if (user?.role == "STUDENT") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("إخفاء صفحتي الشخصية عن بقية الطلاب 🔐", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("لن يتمكن الطلاب الآخرون من مشاهدة هواياتك وتفاصيل ملفك الشخصي.", fontSize = 10.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = isProfileHidden,
                            onCheckedChange = { if (isEditing) isProfileHidden = it },
                            enabled = isEditing
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Profile action buttons
                if (user?.role == "STUDENT") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        border = BorderStroke(1.dp, Color(0xFFFFEBAA))
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF856404), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🔒 تعديل بيانات الطالب متاح فقط للمعلم أو لولي الأمر.",
                                color = Color(0xFF856404),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else if (!isEditing) {
                    Button(
                        onClick = { isEditing = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تعديل الملف الشخصي (Edit)")
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveUserProfile(
                                    quadName = quadName,
                                    birthDate = birthDate,
                                    hobby1 = hobby1,
                                    hobby2 = hobby2,
                                    hobby3 = hobby3,
                                    address = address,
                                    bio = bio,
                                    avatarIndex = avatarIndex,
                                    isProfileHidden = isProfileHidden
                                )
                                isEditing = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                        ) {
                            Text("حفظ")
                        }

                        Button(
                            onClick = { isEditing = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray)
                        ) {
                            Text("إلغاء")
                        }
                    }
                }
            }
        }

        // -----------------------------------------------------------------
        // SECONDARY AUTHORIZED STUDENT MANAGEMENT SECTIONS (PARENT / TEACHER)
        // -----------------------------------------------------------------
        var studentToEdit by remember { mutableStateOf<UserEntity?>(null) }
        var showAddStudentDialog by remember { mutableStateOf(false) }

        if (user?.role == "PARENT") {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "👨‍👩‍👦 إدارة وبيانات الأبناء",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val linkedStuId = user?.linkedStudentId
                    val child = students.find { it.userId == linkedStuId }

                    if (child != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                UserAvatar(avatarIndex = child.avatarIndex, size = 44.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = child.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "${child.studentGrade} • العمر: ${child.studentAge}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Button(
                                onClick = { studentToEdit = child },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تعديل بيانات الابن", fontSize = 11.sp)
                            }
                        }
                    } else {
                        Text(
                            text = "لم تقم بربط حساب ابنك الطالب حتى الآن لمتابعته وتعديل بياناته. يرجى التوجه لعلامة تبويب الخريطة واستخدام رمز الربط الفريد.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        if (user?.role == "TEACHER") {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📋 إدارة وتعديل بيانات طلاب الصف الدراسي",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                
                TextButton(
                    onClick = { showAddStudentDialog = true },
                    modifier = Modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة طالب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val activeGrade = user?.teacherGrade
                    val classStudents = if (activeGrade != null) {
                        students.filter { it.studentGrade == activeGrade }
                    } else {
                        emptyList()
                    }

                    if (activeGrade == null) {
                        Text(
                            text = "⚠️ يرجى تفعيل الصف الدراسي الخاص بك أولاً من الشاشة الرئيسية لمتابعة وإدارة الطلاب.",
                            color = Color.Red,
                            fontSize = 12.sp
                        )
                    } else if (classStudents.isEmpty()) {
                        Text(
                            text = "لا يوجد طلاب مسجلين في $activeGrade حالياً. يمكنك استخدام زر الإضافة بالأعلى لتسجيل طالب جديد.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            classStudents.forEach { stu ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        UserAvatar(avatarIndex = stu.avatarIndex, size = 36.dp)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(text = stu.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(text = "رقم الهاتف: ${stu.phoneNumber}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                    }
                                    Button(
                                        onClick = { studentToEdit = stu },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تعديل", fontSize = 10.sp)
                                    }
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.3f))
                            }
                        }
                    }
                }
            }
        }

        // Handle show dialogs
        studentToEdit?.let { child ->
            EditStudentDialog(
                student = child,
                onDismiss = { studentToEdit = null },
                onSave = { fn, qn, gr, ag, gen, bd, h1, h2, h3, ad, bi, av ->
                    viewModel.updateStudentProfileByAuthorizedUser(
                        studentId = child.userId,
                        fullName = fn,
                        quadName = qn,
                        studentGrade = gr,
                        studentAge = ag,
                        studentGender = gen,
                        birthDate = bd,
                        hobby1 = h1,
                        hobby2 = h2,
                        hobby3 = h3,
                        address = ad,
                        bio = bi,
                        avatarIndex = av
                    )
                    studentToEdit = null
                }
            )
        }

        if (showAddStudentDialog) {
            AddStudentDialog(
                teacherGrade = user?.teacherGrade ?: "الصف الأول",
                onDismiss = { showAddStudentDialog = false },
                onSave = { sId, em, fn, ph, gr, ag, gen, qn, bd, h1, h2, h3, ad, bi, av ->
                    viewModel.addStudentByTeacher(
                        studentId = sId,
                        email = em,
                        fullName = fn,
                        phoneNumber = ph,
                        studentGrade = gr,
                        studentAge = ag,
                        studentGender = gen,
                        quadName = qn,
                        birthDate = bd,
                        hobby1 = h1,
                        hobby2 = h2,
                        hobby3 = h3,
                        address = ad,
                        bio = bi,
                        avatarIndex = av
                    )
                    showAddStudentDialog = false
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // MANAGE BLOCKED USERS SECTION
        Text(
            text = "🚫 حظر وإدارة المستخدمين",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.Red
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "يمكنك حظر الطلاب أو أولياء الأمور الآخرين لمنعهم من التواصل معك أو رؤية منشوراتك على التايم لاين. لا يمكنك حظر ولي أمرك بأي حال.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                val otherUsers = students.filter { it.userId != user?.userId }

                if (otherUsers.isEmpty()) {
                    Text("لا توجد حسابات أخرى للتفاعل معها.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        otherUsers.forEach { other ->
                            val isBlocked = viewModel.isUserBlocked(other.userId)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    UserAvatar(avatarIndex = other.avatarIndex, size = 36.dp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = other.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = other.role, fontSize = 10.sp, color = Color.Gray)
                                    }
                                }

                                Button(
                                    onClick = { viewModel.toggleBlockUser(other.userId) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isBlocked) Color.Gray else Color.Red
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = if (isBlocked) "إلغاء الحظر" else "حظر",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Divider(color = Color.LightGray.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        val context = LocalContext.current
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp, start = 8.dp, end = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == "ar") "منشئ التطبيق: الطالبة ملك تامر محمد" else "Created by Student Malak Tamer Mohamed",
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable {
                    try {
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://sweportsaid.blogspot.com/p/privacy-policy-wy-port-said-school.html?m=1")
                        )
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Policy,
                    contentDescription = "Privacy Policy",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (lang == "ar") "سياسة الخصوصية" else "Privacy Policy",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 4: SYSTEM ALERTS / NOTIFICATIONS LIST
// -------------------------------------------------------------
@Composable
fun AlertsTab(viewModel: SchoolViewModel, lang: String, systemNotifications: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = getT(lang, "notifications"),
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (systemNotifications.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.NotificationsNone,
                        contentDescription = null,
                        tint = Color.LightGray,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = getT(lang, "no_notifications"),
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(systemNotifications) { alert ->
                    val isWarning = alert.contains("🚨") || alert.contains("انذار") || alert.contains("Warning")
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isWarning) Color(0xFFFFEBEE) else Color(0xFFF1F8E9)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isWarning) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isWarning) Color.Red else Color(0xFF4CAF50),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = alert,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.Black,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// CHAT SCREEN (With text & high-fidelity interactive Voice Notes)
// -------------------------------------------------------------

@Composable
fun ChatScreen(viewModel: SchoolViewModel, lang: String) {
    val recipient by viewModel.currentChatRecipient.collectAsStateWithLifecycle()
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isAiTyping by viewModel.isAiTyping.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var messageText by remember { mutableStateOf("") }
    var isRecording by remember { mutableStateOf(false) }
    var recordingDurationSec by remember { mutableStateOf(0) }

    // Simulating active playing sound
    var activePlayingId by remember { mutableStateOf<Long?>(null) }
    var playbackProgress by remember { mutableStateOf(0f) }

    // Start timer for voice recording simulation
    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingDurationSec = 0
            while (isRecording) {
                delay(1000)
                recordingDurationSec++
            }
        }
    }

    // Start simulation of playing a voice note progress
    LaunchedEffect(activePlayingId) {
        if (activePlayingId != null) {
            playbackProgress = 0f
            while (playbackProgress < 1.0f && activePlayingId != null) {
                delay(100)
                playbackProgress += 0.05f
            }
            activePlayingId = null
            playbackProgress = 0f
        }
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Chat Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.closeChat() }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (recipient?.userId == "ai_bot") (recipient?.fullName ?: "") else "${getT(lang, "chat_with")}${recipient?.fullName ?: ""}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = if (recipient?.userId == "ai_bot") {
                        if (lang == "ar") "المساعد الافتراضي لـ WE School • نشط الآن" else "WE School Virtual Assistant • Active Now"
                    } else {
                        "${recipient?.role} | ${recipient?.phoneNumber}"
                    },
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp
                )
            }

            // Secure Tunnel Lock Icon
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (recipient?.userId == "ai_bot") Icons.Default.AutoAwesome else Icons.Default.Lock,
                    contentDescription = if (recipient?.userId == "ai_bot") "AI" else "End-to-End Encrypted",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Messages list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (recipient?.userId == "ai_bot") Color(0xFF8E24AA).copy(alpha = 0.05f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, if (recipient?.userId == "ai_bot") Color(0xFF8E24AA).copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (recipient?.userId == "ai_bot") Icons.Default.AutoAwesome else Icons.Default.Lock,
                                contentDescription = "Secure",
                                tint = if (recipient?.userId == "ai_bot") Color(0xFF8E24AA) else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (recipient?.userId == "ai_bot") {
                                    if (lang == "ar") "مساعد مدرسة WE المدعوم بالذكاء الاصطناعي" else "WE School AI-Powered Support"
                                } else {
                                    if (lang == "ar") "قناة تواصل آمنة ومشفرة" else "Verified Secure Channel"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (recipient?.userId == "ai_bot") Color(0xFF8E24AA) else MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (recipient?.userId == "ai_bot") {
                                if (lang == "ar")
                                    "مرحباً! أنا هنا لمساعدتك والإجابة على استفساراتك المتعلقة بتطبيق وميزات مدرسة WE School بورسعيد التكنولوجية فقط."
                                else
                                    "Hello! I am here to help you and answer your questions related to the WE School Port Said application features only."
                            } else {
                                if (lang == "ar") 
                                    "هذه المحادثة مشفرة بالكامل لحماية خصوصية الطلاب وأولياء الأمور والمعلمين. كود التوثيق: WE-${recipient?.userId?.hashCode()?.coerceAtLeast(1000) ?: "7891"}" 
                                else 
                                    "This chat is fully encrypted to protect student, parent, and teacher privacy. Security Key: WE-${recipient?.userId?.hashCode()?.coerceAtLeast(1000) ?: "7891"}"
                            },
                            fontSize = 10.sp,
                            color = Color.DarkGray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            items(messages) { msg ->
                val isMe = (msg.senderId == viewModel.currentUser.value?.userId)
                val alignment = if (isMe) Alignment.End else Alignment.Start
                val cardColor = if (isMe) MaterialTheme.colorScheme.primary else Color(0xFFF1F1F1)
                val textColor = if (isMe) Color.White else Color.Black

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = alignment
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cardColor),
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (msg.voiceBytes != null) {
                                // Dynamic Sound Voice Note Card UI
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    val isPlaying = activePlayingId == msg.messageId
                                    IconButton(
                                        onClick = {
                                            if (isPlaying) {
                                                activePlayingId = null
                                            } else {
                                                activePlayingId = msg.messageId
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = "Play voice",
                                            tint = if (isMe) Color.White else MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    // Dynamic Equalizer / Waveform Graphic
                                    Box(
                                        modifier = Modifier
                                            .width(130.dp)
                                            .height(26.dp)
                                    ) {
                                        Canvas(modifier = Modifier.fillMaxSize()) {
                                            val barsCount = 18
                                            val barWidth = 4f
                                            val spacing = 3f
                                            for (i in 0 until barsCount) {
                                                val progressFraction = i.toFloat() / barsCount
                                                val shouldHighlight = isPlaying && playbackProgress >= progressFraction
                                                val barHeight = if (isPlaying) {
                                                    Random.nextFloat() * size.height
                                                } else {
                                                    (Math.sin(i.toDouble() * 0.5) * 0.4 + 0.6).toFloat() * size.height
                                                }
                                                val color = if (shouldHighlight) {
                                                    Color.Cyan
                                                } else {
                                                    if (isMe) Color.White.copy(alpha = 0.5f) else Color.Gray
                                                }

                                                drawRect(
                                                    color = color,
                                                    topLeft = Offset(i * (barWidth + spacing), (size.height - barHeight) / 2f),
                                                    size = Size(barWidth, barHeight)
                                                )
                                            }
                                        }
                                    }

                                    Text(
                                        text = if (isPlaying) "00:0${(playbackProgress * 5).toInt()}" else "00:05",
                                        fontSize = 11.sp,
                                        color = textColor.copy(alpha = 0.8f)
                                    )
                                }
                            } else {
                                Text(
                                    text = msg.text,
                                    color = textColor,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Encrypted",
                            tint = Color.Gray,
                            modifier = Modifier.size(10.dp)
                        )
                        Text(
                            text = "${msg.senderName} • ${if (lang == "ar") "آمن ومشفر" else "Secured"}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            if (isAiTyping) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(avatarIndex = 5, size = 32.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F1F1)),
                            modifier = Modifier.widthIn(max = 200.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (lang == "ar") "جاري الكتابة..." else "AI is typing...",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }
                    }
                }
            }
        }

        // Input bottom bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Voice Record Action
                IconButton(
                    onClick = {
                        if (isRecording) {
                            // Send simulated Voice note
                            isRecording = false
                            val simVoiceBytes = ByteArray(1024) { 0 }
                            viewModel.sendVoiceMessage(simVoiceBytes)
                        } else {
                            isRecording = true
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isRecording) Color.Red else MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(
                        imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Mic",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Input Text or Recording Indicator
                if (isRecording) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color.Red)
                        )
                        Text(
                            text = "${getT(lang, "voice_recording")} 00:${if (recordingDurationSec < 10) "0" else ""}$recordingDurationSec",
                            fontWeight = FontWeight.Bold,
                            color = Color.Red,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text(getT(lang, "text_hint"), fontSize = 12.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_text"),
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (messageText.isNotEmpty()) {
                                viewModel.sendTextMessage(messageText)
                                messageText = ""
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send text",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// FIREBASE OFFLINE BUS LOCATION HISTORY COMPONENT FOR PARENTS
// -------------------------------------------------------------
@Composable
fun BusLocationHistoryOfflineComponent(
    busLocationData: BusLocationData,
    busLocationHistory: List<BusLocationHistoryPoint>,
    lang: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bus_location_history_offline_card"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
        border = BorderStroke(1.2.dp, Color(0xFF16A34A)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CloudOff,
                        contentDescription = "Offline Support",
                        tint = Color(0xFF15803D),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "ar") "سجل مواقع الحافلة (التخزين المحلي بالفايربيس)" else "Bus Location History (Firebase Offline Persistence)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF14532D)
                    )
                }
                Surface(
                    color = Color(0xFFDCFCE7),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF16A34A))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (lang == "ar") "تخزين دائم مفعّل" else "Offline Ready",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (lang == "ar")
                    "يضمن النظام احتفاظ ولي الأمر بآخر موقع معروف وموقع الحافلة السابق حتى عند انقطاع أو ضعف شبكة الإنترنت (Firebase Local Persistence Active)."
                else
                    "Ensures parents can always view the last known bus location and history offline using Firebase local persistence.",
                fontSize = 11.sp,
                color = Color.DarkGray,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Last Known Location Highlight Box
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == "ar") "📍 آخر موقع معروف للحافلة:" else "📍 Last Known Bus Location:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${busLocationData.latitude.toString().take(7)}, ${busLocationData.longitude.toString().take(7)} • ${busLocationData.nextStop}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.Black
                        )
                    }
                    val lastTime = try {
                        java.text.SimpleDateFormat("hh:mm:ss a", java.util.Locale.getDefault()).format(java.util.Date(busLocationData.lastUpdatedTimestamp))
                    } catch (e: Exception) {
                        "الآن"
                    }
                    Text(
                        text = lastTime,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (lang == "ar") "📜 التجميع الزمني للمواقع المسجلة محلياً:" else "📜 Timeline of Cached Bus Locations:",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFF14532D)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                busLocationHistory.take(5).forEach { point ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .border(0.8.dp, Color(0xFFDCFCE7), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = Color(0xFF16A34A),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = point.stopName.ifEmpty { "خط العرض: ${point.latitude.toString().take(6)}, الطول: ${point.longitude.toString().take(6)}" },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.DarkGray
                                )
                                Text(
                                    text = if (lang == "ar") "السرعة: ${point.speedKmh.toInt()} كم/س" else "Speed: ${point.speedKmh.toInt()} km/h",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                        Text(
                            text = point.timeFormatted.ifEmpty { "منذ قليل" },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SMART GPS BACKGROUND LOCATION CONTROL CARD
// -------------------------------------------------------------
@Composable
fun SmartGpsControlCard(
    userRole: String,
    parentManualToggle: Boolean,
    isDriverTripActive: Boolean,
    onParentToggleChange: (Boolean) -> Unit,
    onStartDriverTrip: () -> Unit,
    onEndDriverTrip: () -> Unit,
    lang: String
) {
    val smartStatus = GeolocationPermissionService.evaluateSmartGpsStatus(
        role = userRole,
        parentManualToggle = parentManualToggle,
        isDriverTripActive = isDriverTripActive
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smart_gps_control_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (smartStatus.isActive) Color(0xFFF0FDF4) else Color(0xFFFFFBEB)
        ),
        border = BorderStroke(
            1.2.dp,
            if (smartStatus.isActive) Color(0xFF16A34A) else Color(0xFFF59E0B)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.GpsFixed,
                        contentDescription = "Smart GPS",
                        tint = if (smartStatus.isActive) Color(0xFF15803D) else Color(0xFFB45309),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (lang == "ar") "📡 تتبع الجي بي اس الذكي وموفر الطاقة" else "📡 Smart GPS & Battery Saver",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (smartStatus.isActive) Color(0xFF14532D) else Color(0xFF78350F)
                        )
                        Text(
                            text = if (lang == "ar") "نظام التحكم الأوتوماتيكي بالخلفية حسب الجدول والدور" else "Automated Role & Schedule Based Location Control",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
                Surface(
                    color = if (smartStatus.isActive) Color(0xFFDCFCE7) else Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (smartStatus.isActive) (if (lang == "ar") "🟢 نشط" else "🟢 ACTIVE") else (if (lang == "ar") "⏸️ متوقف" else "⏸️ PAUSED"),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (smartStatus.isActive) Color(0xFF15803D) else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Status Badge Box
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (smartStatus.isActive) Color(0xFFBBF7D0) else Color(0xFFFDE68A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = if (lang == "ar") smartStatus.statusTitleAr else smartStatus.statusTitleEn,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (smartStatus.isActive) Color(0xFF15803D) else Color(0xFFB45309)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (lang == "ar") smartStatus.explanationAr else smartStatus.explanationEn,
                        fontSize = 11.sp,
                        color = Color.DarkGray,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Role Specific Interactive Controls
            when (userRole.uppercase()) {
                "STUDENT" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.8f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = if (lang == "ar") "📅 شروط تتبع الطالب التلقائي:" else "📅 Automatic Student Tracking Schedule:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lang == "ar") "الساعات المحددة: 07:00 صباحاً حتى 04:00 عصراً" else "School Hours: 07:00 AM to 04:00 PM",
                                fontSize = 11.sp,
                                color = Color.DarkGray
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lang == "ar") "أيام الدراسة: الأحد إلى الخميس (يغلق الجمعة والسبت)" else "School Days: Sun to Thu (Auto-paused Fri & Sat)",
                                fontSize = 11.sp,
                                color = Color.DarkGray
                            )
                        }
                    }
                }
                "PARENT" -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == "ar") "⚙️ مفتاح تفعيل/تعطيل التتبع لولي الأمر" else "⚙️ Parent Manual Tracking Toggle",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color.Black
                            )
                            Text(
                                text = if (lang == "ar") "استثناء: التحكم اليدوي المباشر في تشغيل أو إيقاف الجي بي اس دون التقيد بمواعيد المدرسة." else "Exception: Manual enable/disable switch without school-hour cutoff.",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                        Switch(
                            checked = parentManualToggle,
                            onCheckedChange = { onParentToggleChange(it) }
                        )
                    }
                }
                "DRIVER" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = if (lang == "ar") "🚌 تحكم سائق الحافلة المدرسية:" else "🚌 Driver Trip GPS Controls:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onStartDriverTrip,
                                enabled = !isDriverTripActive,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (lang == "ar") "▶️ بدء الرحلة" else "▶️ Start Trip", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = onEndDriverTrip,
                                enabled = isDriverTripActive,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (lang == "ar") "🛑 إنهاء الرحلة" else "🛑 End Trip", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (lang == "ar") "ملاحظة: عند الضغط على 'إنهاء الرحلة' يتم إغلاق التتبع تماماً فوراً للحفاظ على البطارية والبيانات." else "Note: 'End Trip' shuts down GPS completely to save driver's battery.",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Firebase Cloud Messaging (FCM) Proximity Alert UI Component
// -------------------------------------------------------------
@Composable
fun FcmProximityAlertSettingsCard(
    viewModel: SchoolViewModel,
    lang: String
) {
    val fcmToken by viewModel.fcmToken.collectAsStateWithLifecycle()
    val fcmAlertsEnabled by viewModel.fcmAlertsEnabled.collectAsStateWithLifecycle()
    val fcmProximityDistance by viewModel.fcmProximityDistanceMeters.collectAsStateWithLifecycle()
    val fcmAlertHistory by viewModel.fcmAlertHistory.collectAsStateWithLifecycle()
    val busLocation by viewModel.busLocation.collectAsStateWithLifecycle()
    val homeLocation by viewModel.homeLocation.collectAsStateWithLifecycle()

    val currentDistance = remember(busLocation, homeLocation) {
        val home = homeLocation ?: Pair(31.2612f, 32.2980f)
        viewModel.calculateDistanceMeters(
            busLocation.latitude, busLocation.longitude,
            home.first.toDouble(), home.second.toDouble()
        ).toInt()
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("fcm_proximity_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "FCM Proximity Alerts",
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (lang == "ar") "تنبيهات اقتراب الحافلة (FCM)" else "Bus Proximity Alerts (FCM)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (lang == "ar") "إشعارات فايربيس المباشرة عند اقتراب الحافلة" else "Firebase Real-time alerts when bus approaches stop",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Switch(
                    checked = fcmAlertsEnabled,
                    onCheckedChange = { viewModel.setFcmAlertsEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF2563EB)
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // FCM Device Registration Token Banner
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = null,
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == "ar") "رمز تسجيل الجهاز بـ FCM (Device Token):" else "FCM Device Token:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF1E293B)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = fcmToken ?: (if (lang == "ar") "جاري تهيئة رمُز FCM من فايربيس..." else "Fetching FCM Token..."),
                        fontSize = 10.sp,
                        color = Color(0xFF64748B),
                        maxLines = 2,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Current Calculated Distance Indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (currentDistance <= fcmProximityDistance) Color(0xFFFEF3C7) else Color(0xFFF1F5F9),
                        RoundedCornerShape(10.dp)
                    )
                    .border(
                        1.dp,
                        if (currentDistance <= fcmProximityDistance) Color(0xFFF59E0B) else Color(0xFFCBD5E1),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DirectionsBus,
                        contentDescription = null,
                        tint = if (currentDistance <= fcmProximityDistance) Color(0xFFD97706) else Color(0xFF475569),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (lang == "ar") "المسافة الحالية بين الحافلة ومحطتك:" else "Current Bus Distance to Stop:",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                        Text(
                            text = if (currentDistance < 1000) "$currentDistance متر" else "${"%.2f".format(currentDistance / 1000f)} كم",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (currentDistance <= fcmProximityDistance) Color(0xFFB45309) else Color(0xFF0F172A)
                        )
                    }
                }

                Surface(
                    color = if (currentDistance <= fcmProximityDistance) Color(0xFF16A34A) else Color(0xFF64748B),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (currentDistance <= fcmProximityDistance)
                            (if (lang == "ar") "داخل نطاق التنبيه 🔔" else "Within Range 🔔")
                        else
                            (if (lang == "ar") "خارج النطاق" else "Outside Range"),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Proximity Distance Selector Chips
            Text(
                text = if (lang == "ar") "اختر مسافة التنبيه المسبق (نطاق الإشعار):" else "Alert Distance Threshold:",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val distanceOptions = listOf(
                    500 to if (lang == "ar") "500m (0.5كم)" else "500m",
                    1000 to if (lang == "ar") "1000m (1كم)" else "1km",
                    2000 to if (lang == "ar") "2000m (2كم)" else "2km",
                    3000 to if (lang == "ar") "3000m (3كم)" else "3km"
                )

                distanceOptions.forEach { (meters, label) ->
                    val isSelected = fcmProximityDistance == meters
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFF1F5F9)
                            )
                            .clickable { viewModel.setFcmProximityDistance(meters) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFF334155)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Test FCM Alert Button
            OutlinedButton(
                onClick = { viewModel.triggerTestFcmAlert() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFF2563EB))
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = null,
                    tint = Color(0xFF2563EB),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (lang == "ar") "تجربة إرسال إشعار FCM الآن (Test Push Alert)" else "Send FCM Test Proximity Notification",
                    color = Color(0xFF2563EB),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            if (fcmAlertHistory.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = Color(0xFFE2E8F0))
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (lang == "ar") "سجل تنبيهات FCM الأخيرة:" else "Recent FCM Alert Logs:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color(0xFF334155)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    fcmAlertHistory.take(3).forEach { alert ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = null,
                                    tint = Color(0xFF2563EB),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = alert.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF1E293B)
                                    )
                                    Text(
                                        text = alert.message,
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                                Text(
                                    text = alert.timeFormatted,
                                    fontSize = 10.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

