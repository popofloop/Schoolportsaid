package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CheerfulBluePrimary = Color(0xFF004B87) // Dark Blue (#004B87)
val CheerfulBlueSecondary = Color(0xFF0077C0) // Medium Dark Blue
val CheerfulBlueTertiary = Color(0xFF4B9CD3) // Soft Steel Blue
val CheerfulBlueLight = Color(0xFFE6F0FA) // Light tint of dark blue
val CheerfulBlueBackground = Color(0xFFF0F5FA) // Clear soft tinted background

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
