package com.example.ui.viewmodel

import android.app.Application
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.StudentStatusEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.CommuteLogEntity
import com.example.data.local.entity.TimelinePostEntity
import com.example.data.local.entity.GroupEntity
import com.example.data.local.entity.GroupMessageEntity
import com.example.data.repository.SchoolRepository
import com.example.service.GeolocationPermissionService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.messaging.FirebaseMessaging
import com.example.service.SchoolBusFcmService
import android.util.Log

data class FcmAlertLog(
    val id: String = "",
    val busId: String = "bus_14",
    val title: String = "",
    val message: String = "",
    val distanceMeters: Float = 0f,
    val timestamp: Long = System.currentTimeMillis(),
    val timeFormatted: String = ""
)

data class BusLocationData(
    val busId: String = "bus_14",
    val busName: String = "حافلة مدرسة WE الذكية #14",
    val driverName: String = "الكابتن / أحمد محمود",
    val driverPhone: String = "01098765432",
    val latitude: Double = 31.2653,
    val longitude: Double = 32.3019,
    val speedKmh: Float = 38f,
    val routeProgress: Float = 45f,
    val status: String = "ON_THE_WAY",
    val nextStop: String = "شارع 23 يوليو - بورسعيد",
    val studentsOnBoard: Int = 18,
    val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
    val isFirebaseLive: Boolean = true
)

data class BusEtaInfo(
    val remainingMinutes: Int,
    val progressPercent: Float,
    val remainingDistanceKm: Float,
    val averageSpeedKmh: Float,
    val statusTextEn: String,
    val statusTextAr: String
)

data class BusLocationHistoryPoint(
    val id: String = "",
    val latitude: Double = 31.2653,
    val longitude: Double = 32.3019,
    val speedKmh: Float = 0f,
    val stopName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val timeFormatted: String = ""
)

class SchoolViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = SchoolRepository(
        database.userDao(),
        database.messageDao(),
        database.studentStatusDao(),
        database.commuteLogDao(),
        database.timelinePostDao(),
        database.groupDao()
    )

    // Current Screens: "WELCOME", "AUTH", "REGISTER", "ROUTE_SETUP", "DASHBOARD", "CHAT", "PROFILE_EDIT"
    private val _currentScreen = MutableStateFlow("WELCOME")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _currentLanguage = MutableStateFlow("ar") // "ar" or "en"
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val _firebaseUser = MutableStateFlow<FirebaseUser?>(null)
    val firebaseUser: StateFlow<FirebaseUser?> = _firebaseUser.asStateFlow()

    private val _studentsList = MutableStateFlow<List<UserEntity>>(emptyList())
    val studentsList: StateFlow<List<UserEntity>> = _studentsList.asStateFlow()

    private val _studentStatuses = MutableStateFlow<Map<String, StudentStatusEntity>>(emptyMap())
    val studentStatuses: StateFlow<Map<String, StudentStatusEntity>> = _studentStatuses.asStateFlow()

    private val _currentChatRecipient = MutableStateFlow<UserEntity?>(null)
    val currentChatRecipient: StateFlow<UserEntity?> = _currentChatRecipient.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val chatMessages: StateFlow<List<MessageEntity>> = _chatMessages.asStateFlow()

    private val _isAiTyping = MutableStateFlow(false)
    val isAiTyping: StateFlow<Boolean> = _isAiTyping.asStateFlow()

    private val _systemNotifications = MutableStateFlow<List<String>>(emptyList())
    val systemNotifications: StateFlow<List<String>> = _systemNotifications.asStateFlow()

    // Tracking route setup
    val homeLocation = MutableStateFlow<Pair<Float, Float>?>(null)
    val schoolLocation = MutableStateFlow<Pair<Float, Float>?>(null)

    // Simulation tracking state
    private var simulationJob: Job? = null
    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    // Tracking details
    private val _selectedStudentId = MutableStateFlow<String?>(null)
    val selectedStudentId: StateFlow<String?> = _selectedStudentId.asStateFlow()

    // Smart GPS Background Location State Management
    private val _parentManualGpsToggle = MutableStateFlow(true)
    val parentManualGpsToggle: StateFlow<Boolean> = _parentManualGpsToggle.asStateFlow()

    private val _isDriverTripActive = MutableStateFlow(false)
    val isDriverTripActive: StateFlow<Boolean> = _isDriverTripActive.asStateFlow()

    fun setParentManualGpsToggle(enabled: Boolean) {
        _parentManualGpsToggle.value = enabled
    }

    fun startDriverTrip() {
        _isDriverTripActive.value = true
    }

    fun endDriverTrip() {
        _isDriverTripActive.value = false
    }

    fun getSmartGpsStatus(userRole: String): com.example.service.SmartGpsStatus {
        return GeolocationPermissionService.evaluateSmartGpsStatus(
            role = userRole,
            parentManualToggle = _parentManualGpsToggle.value,
            isDriverTripActive = _isDriverTripActive.value
        )
    }

    // Traffic Condition State for School Bus ETA Calculations
    private val _trafficCondition = MutableStateFlow("NORMAL")
    val trafficCondition: StateFlow<String> = _trafficCondition.asStateFlow()

    fun setTrafficCondition(condition: String) {
        _trafficCondition.value = condition
    }

    // Weather Condition State for School Bus ETA Calculations
    private val _weatherCondition = MutableStateFlow("SUNNY")
    val weatherCondition: StateFlow<String> = _weatherCondition.asStateFlow()

    // FCM Real-time Proximity Alerts state
    private val _fcmToken = MutableStateFlow<String?>(null)
    val fcmToken: StateFlow<String?> = _fcmToken.asStateFlow()

    private val _fcmAlertsEnabled = MutableStateFlow(true)
    val fcmAlertsEnabled: StateFlow<Boolean> = _fcmAlertsEnabled.asStateFlow()

    private val _fcmProximityDistanceMeters = MutableStateFlow(1000) // Default 1000 meters
    val fcmProximityDistanceMeters: StateFlow<Int> = _fcmProximityDistanceMeters.asStateFlow()

    private val _fcmAlertHistory = MutableStateFlow<List<FcmAlertLog>>(emptyList())
    val fcmAlertHistory: StateFlow<List<FcmAlertLog>> = _fcmAlertHistory.asStateFlow()

    private var lastFcmAlertTimestamp = 0L

    // Real-time Firebase Bus GPS Location & Offline Persistence state
    private val _busLocation = MutableStateFlow(BusLocationData())
    val busLocation: StateFlow<BusLocationData> = _busLocation.asStateFlow()

    private val _busLocationHistory = MutableStateFlow<List<BusLocationHistoryPoint>>(emptyList())
    val busLocationHistory: StateFlow<List<BusLocationHistoryPoint>> = _busLocationHistory.asStateFlow()

    private var firebaseBusDatabaseRef: DatabaseReference? = null
    private var isFirebasePersistenceEnabled = false

    private fun enableFirebaseOfflinePersistence() {
        if (isFirebasePersistenceEnabled) return
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
            Log.d("FirebaseBusTracking", "Firebase Realtime DB persistence enabled successfully")
        } catch (e: Exception) {
            Log.w("FirebaseBusTracking", "Firebase DB persistence note: ${e.message}")
        }

        try {
            val settings = com.google.firebase.firestore.FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build()
            FirebaseFirestore.getInstance().firestoreSettings = settings
            Log.d("FirebaseBusTracking", "Firebase Firestore persistence enabled successfully")
        } catch (e: Exception) {
            Log.w("FirebaseBusTracking", "Firestore persistence note: ${e.message}")
        }
        isFirebasePersistenceEnabled = true
    }

    fun initFirebaseRealtimeBusTracking() {
        try {
            enableFirebaseOfflinePersistence()
            val database = FirebaseDatabase.getInstance()
            firebaseBusDatabaseRef = database.getReference("school_buses").child("bus_14")
            
            // Enable keepSynced so Firebase disk persistence retains live bus updates offline
            firebaseBusDatabaseRef?.keepSynced(true)

            val historyRef = database.getReference("school_buses").child("bus_14").child("location_history")
            historyRef.keepSynced(true)

            // Seed default history if empty for instant offline view
            if (_busLocationHistory.value.isEmpty()) {
                val now = System.currentTimeMillis()
                val sdf = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
                _busLocationHistory.value = listOf(
                    BusLocationHistoryPoint("p3", 31.2653, 32.3019, 38f, "شارع 23 يوليو - بورسعيد", now - 60000, sdf.format(Date(now - 60000))),
                    BusLocationHistoryPoint("p2", 31.2612, 32.2980, 42f, "حي الشرق - شارع الجمهورية", now - 300000, sdf.format(Date(now - 300000))),
                    BusLocationHistoryPoint("p1", 31.2580, 32.2920, 35f, "ميدان المسلة - بورسعيد", now - 600000, sdf.format(Date(now - 600000)))
                )
            }

            firebaseBusDatabaseRef?.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val busId = snapshot.child("busId").getValue(String::class.java) ?: "bus_14"
                        val busName = snapshot.child("busName").getValue(String::class.java) ?: "حافلة مدرسة WE الذكية #14"
                        val driverName = snapshot.child("driverName").getValue(String::class.java) ?: "الكابتن / أحمد محمود"
                        val driverPhone = snapshot.child("driverPhone").getValue(String::class.java) ?: "01098765432"
                        val lat = snapshot.child("latitude").getValue(Double::class.java) ?: 31.2653
                        val lng = snapshot.child("longitude").getValue(Double::class.java) ?: 32.3019
                        val speed = snapshot.child("speedKmh").getValue(Double::class.java)?.toFloat() ?: 38f
                        val progress = snapshot.child("routeProgress").getValue(Double::class.java)?.toFloat() ?: 45f
                        val status = snapshot.child("status").getValue(String::class.java) ?: "ON_THE_WAY"
                        val nextStop = snapshot.child("nextStop").getValue(String::class.java) ?: "شارع 23 يوليو - بورسعيد"
                        val studentsCount = snapshot.child("studentsOnBoard").getValue(Int::class.java) ?: 18
                        val timestamp = snapshot.child("lastUpdatedTimestamp").getValue(Long::class.java) ?: System.currentTimeMillis()

                        _busLocation.value = BusLocationData(
                            busId = busId,
                            busName = busName,
                            driverName = driverName,
                            driverPhone = driverPhone,
                            latitude = lat,
                            longitude = lng,
                            speedKmh = speed,
                            routeProgress = progress,
                            status = status,
                            nextStop = nextStop,
                            studentsOnBoard = studentsCount,
                            lastUpdatedTimestamp = timestamp,
                            isFirebaseLive = true
                        )

                        // Check FCM Proximity Alert
                        checkAndSendFcmProximityAlert(lat, lng)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("FirebaseBusTracking", "Firebase listener cancelled: ${error.message}")
                }
            })

            historyRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val points = mutableListOf<BusLocationHistoryPoint>()
                    for (child in snapshot.children) {
                        val lat = child.child("latitude").getValue(Double::class.java) ?: continue
                        val lng = child.child("longitude").getValue(Double::class.java) ?: continue
                        val speed = child.child("speedKmh").getValue(Double::class.java)?.toFloat() ?: 0f
                        val stop = child.child("stopName").getValue(String::class.java) ?: ""
                        val ts = child.child("timestamp").getValue(Long::class.java) ?: System.currentTimeMillis()
                        val formatted = child.child("timeFormatted").getValue(String::class.java) ?: ""

                        points.add(
                            BusLocationHistoryPoint(
                                id = child.key ?: ts.toString(),
                                latitude = lat,
                                longitude = lng,
                                speedKmh = speed,
                                stopName = stop,
                                timestamp = ts,
                                timeFormatted = formatted
                            )
                        )
                    }
                    if (points.isNotEmpty()) {
                        _busLocationHistory.value = points.sortedByDescending { it.timestamp }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("FirebaseBusTracking", "History listener error: ${error.message}")
                }
            })
        } catch (e: Exception) {
            Log.e("FirebaseBusTracking", "Firebase DB init error: ${e.message}")
        }
    }

    fun updateBusLocationInFirebase(
        lat: Double,
        lng: Double,
        speed: Float,
        progress: Float,
        nextStopName: String? = null
    ) {
        val newTimestamp = System.currentTimeMillis()
        val formattedTime = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(newTimestamp))
        val current = _busLocation.value
        val updated = current.copy(
            latitude = lat,
            longitude = lng,
            speedKmh = speed,
            routeProgress = progress,
            status = if (progress >= 100f) "ARRIVED" else "ON_THE_WAY",
            nextStop = nextStopName ?: current.nextStop,
            lastUpdatedTimestamp = newTimestamp,
            isFirebaseLive = true
        )
        _busLocation.value = updated

        val firebaseData = mapOf(
            "busId" to updated.busId,
            "busName" to updated.busName,
            "driverName" to updated.driverName,
            "driverPhone" to updated.driverPhone,
            "latitude" to updated.latitude,
            "longitude" to updated.longitude,
            "speedKmh" to updated.speedKmh,
            "routeProgress" to updated.routeProgress,
            "status" to updated.status,
            "nextStop" to updated.nextStop,
            "studentsOnBoard" to updated.studentsOnBoard,
            "lastUpdatedTimestamp" to updated.lastUpdatedTimestamp
        )

        val historyEntry = mapOf(
            "latitude" to updated.latitude,
            "longitude" to updated.longitude,
            "speedKmh" to updated.speedKmh,
            "stopName" to updated.nextStop,
            "timestamp" to updated.lastUpdatedTimestamp,
            "timeFormatted" to formattedTime
        )

        try {
            if (firebaseBusDatabaseRef == null) {
                initFirebaseRealtimeBusTracking()
            }
            firebaseBusDatabaseRef?.setValue(firebaseData)

            val database = FirebaseDatabase.getInstance()
            val historyRef = database.getReference("school_buses").child("bus_14").child("location_history").child(newTimestamp.toString())
            historyRef.setValue(historyEntry)

            FirebaseFirestore.getInstance()
                .collection("bus_location_history")
                .document("${updated.busId}_$newTimestamp")
                .set(historyEntry)

            val currentList = _busLocationHistory.value.toMutableList()
            currentList.add(
                0,
                BusLocationHistoryPoint(
                    id = newTimestamp.toString(),
                    latitude = updated.latitude,
                    longitude = updated.longitude,
                    speedKmh = updated.speedKmh,
                    stopName = updated.nextStop,
                    timestamp = newTimestamp,
                    timeFormatted = formattedTime
                )
            )
            _busLocationHistory.value = currentList.take(20)

            // Check FCM Proximity Alert
            checkAndSendFcmProximityAlert(updated.latitude, updated.longitude)
        } catch (e: Exception) {
            Log.e("FirebaseBusTracking", "Failed to update Firebase Realtime DB: ${e.message}")
        }
    }

    fun setWeatherCondition(condition: String) {
        _weatherCondition.value = condition
    }

    // --- Firebase Cloud Messaging (FCM) Proximity Alert Engine ---

    fun initFcmMessaging() {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    _fcmToken.value = token
                    Log.d("FCM_SETUP", "FCM Token acquired successfully: $token")
                    SchoolBusFcmService.saveTokenToFirebase(token)
                } else {
                    val fallbackToken = "fcm_token_${System.currentTimeMillis()}"
                    _fcmToken.value = fallbackToken
                    Log.w("FCM_SETUP", "FCM token task failed, generated fallback token: $fallbackToken")
                }
            }
        } catch (e: Exception) {
            val fallbackToken = "fcm_sim_token_${System.currentTimeMillis()}"
            _fcmToken.value = fallbackToken
            Log.e("FCM_SETUP", "FCM messaging init note: ${e.message}")
        }
    }

    fun setFcmProximityDistance(meters: Int) {
        _fcmProximityDistanceMeters.value = meters
    }

    fun setFcmAlertsEnabled(enabled: Boolean) {
        _fcmAlertsEnabled.value = enabled
    }

    fun calculateDistanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val r = 6371000.0 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return (r * c).toFloat()
    }

    fun checkAndSendFcmProximityAlert(busLat: Double, busLng: Double) {
        if (!_fcmAlertsEnabled.value) return

        val home = homeLocation.value ?: Pair(31.2612f, 32.2980f) // Port Said stop location
        val distance = calculateDistanceMeters(
            busLat, busLng,
            home.first.toDouble(), home.second.toDouble()
        )

        val thresholdMeters = _fcmProximityDistanceMeters.value.toFloat()

        if (distance <= thresholdMeters) {
            val now = System.currentTimeMillis()
            if (now - lastFcmAlertTimestamp > 30_000) { // 30 sec cooldown
                lastFcmAlertTimestamp = now
                val distanceInt = distance.toInt()
                val lang = currentLanguage.value

                val title = if (lang == "ar") "🚌 تنبيه اقتراب الحافلة المدرسية (FCM)" else "🚌 School Bus Proximity Alert (FCM)"
                val message = if (lang == "ar") "الحافلة المدرسية #14 أصبحت على بعد $distanceInt متر فقط من محطتك المنزلية! يرجى الاستعداد للوصول." else "School Bus #14 is now within $distanceInt meters of your stop! Please get ready."

                SchoolBusFcmService.showNotification(
                    getApplication(),
                    title = title,
                    body = message,
                    busId = _busLocation.value.busId,
                    distanceMeters = distance
                )

                val timeStr = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(now))
                val alertLog = FcmAlertLog(
                    id = "alert_$now",
                    busId = _busLocation.value.busId,
                    title = title,
                    message = message,
                    distanceMeters = distance,
                    timestamp = now,
                    timeFormatted = timeStr
                )

                _fcmAlertHistory.value = listOf(alertLog) + _fcmAlertHistory.value.take(15)

                try {
                    val alertMap = mapOf(
                        "busId" to alertLog.busId,
                        "title" to alertLog.title,
                        "message" to alertLog.message,
                        "distanceMeters" to alertLog.distanceMeters,
                        "timestamp" to alertLog.timestamp,
                        "timeFormatted" to alertLog.timeFormatted,
                        "recipientUser" to (_currentUser.value?.fullName ?: "Parent")
                    )
                    FirebaseDatabase.getInstance()
                        .getReference("fcm_alerts_logs")
                        .child(now.toString())
                        .setValue(alertMap)

                    FirebaseFirestore.getInstance()
                        .collection("fcm_alerts_logs")
                        .document("alert_$now")
                        .set(alertMap)
                } catch (e: Exception) {
                    Log.e("FCM_ALERT", "Error syncing alert log: ${e.message}")
                }
            }
        }
    }

    fun triggerTestFcmAlert() {
        val now = System.currentTimeMillis()
        val timeStr = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(now))
        val distance = 350f
        val title = if (currentLanguage.value == "ar") "🔔 إشعار تجريبي من FCM" else "🔔 FCM Test Proximity Notification"
        val message = if (currentLanguage.value == "ar") "تجربة إشعار اقتراب الحافلة المدرسية #14 - مسافة المحطة: 350 متر" else "Test notification for School Bus #14 - Distance to stop: 350m"

        SchoolBusFcmService.showNotification(
            getApplication(),
            title = title,
            body = message,
            busId = _busLocation.value.busId,
            distanceMeters = distance
        )

        val alertLog = FcmAlertLog(
            id = "test_$now",
            busId = _busLocation.value.busId,
            title = title,
            message = message,
            distanceMeters = distance,
            timestamp = now,
            timeFormatted = timeStr
        )
        _fcmAlertHistory.value = listOf(alertLog) + _fcmAlertHistory.value.take(15)
    }

    /**
     * Calculates the estimated arrival time, remaining distance, speed, and progress percent
     * for a school bus based on current coordinates, traffic factor, and weather conditions.
     */
    fun getEstimatedArrivalTime(
        currentLat: Double,
        currentLng: Double,
        isAtSchool: Boolean,
        isAtHome: Boolean,
        trafficCond: String,
        weatherCond: String = "SUNNY"
    ): BusEtaInfo {
        if (isAtSchool) {
            return BusEtaInfo(
                remainingMinutes = 0,
                progressPercent = 100f,
                remainingDistanceKm = 0f,
                averageSpeedKmh = 0f,
                statusTextEn = "Arrived at School",
                statusTextAr = "وصل إلى المدرسة"
            )
        }

        val h = homeLocation.value ?: Pair(200f, 600f)
        val s = schoolLocation.value ?: Pair(600f, 200f)

        // Calculate total distance (from home to school) in pixels
        val totalDx = s.first - h.first
        val totalDy = s.second - h.second
        val totalPixelDist = kotlin.math.hypot(totalDx, totalDy)
        if (totalPixelDist == 0f) {
            return BusEtaInfo(0, 0f, 0f, 0f, "Route Not Set", "لم يتم تحديد المسار")
        }

        // Calculate remaining distance to school in pixels
        val remainingDx = s.first - currentLat.toFloat()
        val remainingDy = s.second - currentLng.toFloat()
        val remainingPixelDist = kotlin.math.hypot(remainingDx, remainingDy)

        // Calculate progress percentage
        val completedPixelDist = totalPixelDist - remainingPixelDist
        val rawProgress = (completedPixelDist / totalPixelDist).coerceIn(0f, 1f)
        val progressPercent = rawProgress * 100f

        // Convert pixels to real-world kilometers (e.g. 100 pixels = 1.5 km)
        val conversionFactor = 1.5f / 100f
        val remainingDistanceKm = (remainingPixelDist * conversionFactor).coerceIn(0f, 15f)

        // Weather multiplier to adapt average speeds
        val weatherMultiplier = when (weatherCond.uppercase()) {
            "SUNNY" -> 1.0f
            "RAINY" -> 0.75f
            "FOGGY" -> 0.5f
            "SANDSTORM" -> 0.4f
            else -> 1.0f
        }

        // Base speed (km/h) based on chosen traffic condition
        val baseSpeedKmh = when (trafficCond.uppercase()) {
            "NORMAL" -> 45f
            "MODERATE" -> 28f
            "HEAVY" -> 12f
            "BLOCKED" -> 3f
            else -> 45f
        }

        val averageSpeedKmh = (baseSpeedKmh * weatherMultiplier).coerceIn(2.0f, 60.0f)

        // Calculate duration in hours and convert to minutes
        val timeHours = remainingDistanceKm / averageSpeedKmh
        var remainingMinutes = (timeHours * 60f).toInt()

        // Give a minimum duration of 1 minute if on-the-way
        if (remainingMinutes < 1 && !isAtSchool && !isAtHome) {
            remainingMinutes = 1
        } else if (isAtHome) {
            // If the simulation is reset and we are exactly at home, estimate total route time
            val totalHours = (totalPixelDist * conversionFactor) / averageSpeedKmh
            remainingMinutes = (totalHours * 60f).toInt()
        }

        val trafficLabelEn = when (trafficCond.uppercase()) {
            "NORMAL" -> "Light Traffic"
            "MODERATE" -> "Moderate Traffic"
            "HEAVY" -> "Heavy Traffic"
            "BLOCKED" -> "Congested / Blocked"
            else -> "Normal"
        }
        val trafficLabelAr = when (trafficCond.uppercase()) {
            "NORMAL" -> "حركة مرور خفيفة"
            "MODERATE" -> "ازدحام مروري متوسط"
            "HEAVY" -> "ازدحام مروري كثيف"
            "BLOCKED" -> "حركة مرور متوقفة / مغلق"
            else -> "عادية"
        }

        val weatherLabelEn = when (weatherCond.uppercase()) {
            "SUNNY" -> "Sunny ☀️"
            "RAINY" -> "Rainy 🌧️"
            "FOGGY" -> "Dense Fog 🌫️"
            "SANDSTORM" -> "Sandstorm 🌪️"
            else -> "Sunny"
        }
        val weatherLabelAr = when (weatherCond.uppercase()) {
            "SUNNY" -> "مشمس ☀️"
            "RAINY" -> "مُمطر 🌧️"
            "FOGGY" -> "ضباب كثيف 🌫️"
            "SANDSTORM" -> "عاصفة رملية 🌪️"
            else -> "مشمس"
        }

        val distStr = String.format(Locale.US, "%.1f", remainingDistanceKm)
        val speedStr = String.format(Locale.US, "%.0f", averageSpeedKmh)
        
        return BusEtaInfo(
            remainingMinutes = remainingMinutes,
            progressPercent = progressPercent,
            remainingDistanceKm = remainingDistanceKm,
            averageSpeedKmh = averageSpeedKmh,
            statusTextEn = "[$weatherLabelEn] $trafficLabelEn (Avg: $speedStr km/h) • Dist: $distStr km",
            statusTextAr = "[$weatherLabelAr] $trafficLabelAr (السرعة: $speedStr كم/س) • المسافة: $distStr كم"
        )
    }

    // --- NEW STATE FLOWS ---
    private val _commuteLogs = MutableStateFlow<List<CommuteLogEntity>>(emptyList())
    val commuteLogs: StateFlow<List<CommuteLogEntity>> = _commuteLogs.asStateFlow()

    private val _timelinePosts = MutableStateFlow<List<TimelinePostEntity>>(emptyList())
    val timelinePosts: StateFlow<List<TimelinePostEntity>> = _timelinePosts.asStateFlow()

    private val _groupsList = MutableStateFlow<List<GroupEntity>>(emptyList())
    val groupsList: StateFlow<List<GroupEntity>> = _groupsList.asStateFlow()

    private val _selectedGroup = MutableStateFlow<GroupEntity?>(null)
    val selectedGroup: StateFlow<GroupEntity?> = _selectedGroup.asStateFlow()

    private val _groupMessages = MutableStateFlow<List<GroupMessageEntity>>(emptyList())
    val groupMessages: StateFlow<List<GroupMessageEntity>> = _groupMessages.asStateFlow()

    init {
        try {
            _firebaseUser.value = firebaseAuth.currentUser
            firebaseAuth.addAuthStateListener { auth ->
                _firebaseUser.value = auth.currentUser
                Log.d("FirebaseAuth", "Auth state changed: user=${auth.currentUser?.email}")
            }
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Auth listener init error: ${e.message}")
        }

        // Load initial data & generate defaults if empty
        viewModelScope.launch {
            try {
                seedInitialData()
                loadStudents()
                observeStudentStatuses()
                observeCommuteLogs()
                observeTimelinePosts()
                observeGroups()
                initFirebaseRealtimeBusTracking()
                initFcmMessaging()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setScreen(screen: String) {
        _currentScreen.value = screen
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == "ar") "en" else "ar"
    }

    fun selectStudentForTracking(studentId: String) {
        _selectedStudentId.value = studentId
    }

    fun checkInStudentManually(studentId: String, statusType: String) {
        viewModelScope.launch {
            val status = repository.getStudentStatus(studentId) ?: StudentStatusEntity(
                studentId = studentId,
                currentLat = 220.0,
                currentLng = 580.0
            )
            val updatedStatus = when (statusType) {
                "SCHOOL" -> status.copy(isAtSchool = true, isAtHome = false, isDeviated = false, currentLat = 580.0, currentLng = 220.0)
                "HOME" -> status.copy(isAtSchool = false, isAtHome = true, isDeviated = false, currentLat = 220.0, currentLng = 580.0)
                "ON_ROUTE" -> status.copy(isAtSchool = false, isAtHome = false, isDeviated = false, currentLat = 400.0, currentLng = 400.0)
                else -> status
            }
            repository.insertStudentStatus(updatedStatus)
            
            // Add notification and log commute
            val student = repository.getUser(studentId)
            val name = student?.fullName ?: studentId
            if (statusType == "SCHOOL") {
                addNotification(
                    ar = "✅ [تسجيل يدوي] تم تأكيد وصول الطالب $name للمدرسة من قبل المعلم.",
                    en = "✅ [Manual Check-In] Teacher confirmed arrival of Student $name at school."
                )
                recordCommuteLog(studentId, name, "07:30 AM", "07:55 AM", "ARRIVED")
            } else if (statusType == "ON_ROUTE") {
                addNotification(
                    ar = "🚍 [تسجيل يدوي] صعد الطالب $name إلى الحافلة الآن مع المعلم.",
                    en = "🚍 [Manual Onboarding] Student $name boarded the bus with the teacher."
                )
                recordCommuteLog(studentId, name, "07:30 AM", "Not Arrived Yet", "ON_WAY")
            } else if (statusType == "HOME") {
                addNotification(
                    ar = "🏠 [تسجيل يدوي] تم إرجاع الطالب $name للمنزل من قبل المعلم.",
                    en = "🏠 [Manual Reset] Teacher returned Student $name to Home."
                )
            }
        }
    }

    // Load Chat Messages Flow
    fun startChat(recipient: UserEntity) {
        _currentChatRecipient.value = recipient
        _currentScreen.value = "CHAT"
        
        viewModelScope.launch {
            val currentId = _currentUser.value?.userId ?: return@launch
            repository.getChatMessagesFlow(currentId, recipient.userId).collect { messages ->
                _chatMessages.value = messages
            }
        }

        if (recipient.userId == "ai_bot") {
            viewModelScope.launch {
                val currentId = _currentUser.value?.userId ?: return@launch
                val currentMsgs = repository.getChatMessagesFlow(currentId, "ai_bot").first()
                if (currentMsgs.isEmpty()) {
                    val welcomeMsg = MessageEntity(
                        senderId = "ai_bot",
                        senderName = if (_currentLanguage.value == "ar") "مساعد مدرسة WE الذكي (AI)" else "WE School AI Assistant",
                        senderRole = "AI_BOT",
                        receiverId = currentId,
                        text = if (_currentLanguage.value == "ar") {
                            "مرحباً بك! أنا مساعد الذكاء الاصطناعي الذكي لمدرسة WE School بورسعيد. 🤖✨\n\nأنا هنا للإجابة على جميع استفساراتك حول ميزات هذا التطبيق، مثل:\n• تتبع حافلة المدرسة والرحلات (GPS)\n• المحادثات الآمنة والمشفرة (Chats)\n• جدول الحصص ومسار الحافلة الذكية #14\n• التايم لاين والمستجدات المدرسية\n\nكيف يمكنني مساعدتك اليوم بخصوص التطبيق؟"
                        } else {
                            "Welcome! I am the Smart AI Assistant for WE School Port Said. 🤖✨\n\nI am here to answer all your inquiries regarding this app's features, such as:\n• GPS tracking and commute logs\n• Secure, fully-encrypted chats\n• Class schedules and Smart Bus #14 route\n• Timeline and school updates\n\nHow can I help you with the app today?"
                        }
                    )
                    repository.insertMessage(welcomeMsg)
                }
            }
        }
    }

    fun closeChat() {
        _currentChatRecipient.value = null
        _currentScreen.value = "DASHBOARD"
    }

    // Send text message
    fun sendTextMessage(text: String) {
        val current = _currentUser.value ?: return
        val recipient = _currentChatRecipient.value ?: return
        viewModelScope.launch {
            val msg = MessageEntity(
                senderId = current.userId,
                senderName = current.fullName,
                senderRole = current.role,
                receiverId = recipient.userId,
                text = text
            )
            repository.insertMessage(msg)

            // AI Bot Handler
            if (recipient.userId == "ai_bot") {
                _isAiTyping.value = true
                try {
                    val currentId = current.userId
                    val recentMsgs = _chatMessages.value.takeLast(15)
                    val history = recentMsgs.map { m ->
                        val role = if (m.senderId == currentId) "user" else "model"
                        Pair(role, m.text)
                    }

                    val systemInstruction = if (_currentLanguage.value == "ar") {
                        "أنت المساعد الذكي لمدرسة WE School (WE School, Port Said) في بورسعيد. مهمتك الوحيدة والمحددة هي الإجابة على استفسارات المستخدمين حول هذا التطبيق وميزاته فقط. لا تجب على أي أسئلة عامة أو أسئلة غير متعلقة بالتطبيق. إذا سألك المستخدم عن أي موضوع آخر، اعتذر منه بلطف واذكر له أنك مبرمج ومخصص لمساعدة أولياء الأمور والمعلمين والطلاب في استخدام ميزات تطبيق WE School فقط. ميزات التطبيق التي يمكنك شرحها تشمل: 1. تتبع حافلة المدرسة والرحلات (GPS & Commute Logs): يتضمن موقع الطالب الجغرافي، وحالة الاتصال بالخلفية، ومسار الحافلة الذكية، والتحقق التلقائي عند بوابات المدرسة. 2. المحادثات الآمنة والجروبات (Chats & Groups): تواصل آمن ومشفر بالكامل ثنائي أو جماعي بين أولياء الأمور والمعلمين لضمان خصوصية الطلاب. 3. جدول اليوم والحصص وتفاصيل مسار الحافلة الذكية #14 والتواصل مع السائق. 4. التايم لاين والمستجدات (Timeline): لمشاركة ومشاهدة آخر الأنشطة والفعاليات المدرسية. 5. بروفايل المستخدم (Profile): الملف التعريفي والبيانات الشخصية والاهتمامات لكل طالب أو معلم أو ولي أمر. 6. التنبيهات والإشعارات الهامة (Notifications & Alerts). أجب دائماً بلغة مهذبة وسهلة الفهم باللغة العربية."
                    } else {
                        "You are the Smart AI Assistant for WE School (WE School, Port Said). Your sole and specific mission is to answer user inquiries about this application and its features only. Do not answer any general or unrelated questions. If the user asks about any other topic, politely decline and mention that you are programmed specifically to help parents, teachers, and students use the WE School app features. The app features you can explain include: 1. GPS Tracking & Commute Logs: Shows live student GPS locations, school bus routing, background status, and gate automatic check-ins. 2. Secure Chats & Groups: Fully encrypted direct and group messaging between parents, teachers, and students to preserve privacy. 3. Daily Schedule & Route Info (Smart Bus #14). 4. Timeline & Updates: For sharing and viewing school activities. 5. User Profile: Personal details, academic info, and student hobbies/interests. 6. Notifications & Alerts. Always answer in a polite, helpful manner in English."
                    }

                    val responseText = com.example.service.GeminiApiClient.generateResponse(
                        prompt = text,
                        systemInstruction = systemInstruction,
                        history = history
                    )

                    val responseMsg = MessageEntity(
                        senderId = "ai_bot",
                        senderName = if (_currentLanguage.value == "ar") "مساعد مدرسة WE الذكي (AI)" else "WE School AI Assistant",
                        senderRole = "AI_BOT",
                        receiverId = currentId,
                        text = responseText
                    )
                    repository.insertMessage(responseMsg)
                } catch (e: Exception) {
                    val errorMsg = MessageEntity(
                        senderId = "ai_bot",
                        senderName = if (_currentLanguage.value == "ar") "مساعد مدرسة WE الذكي (AI)" else "WE School AI Assistant",
                        senderRole = "AI_BOT",
                        receiverId = current.userId,
                        text = if (_currentLanguage.value == "ar") "عذراً، حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي: ${e.localizedMessage}" else "Sorry, an error occurred while connecting to the AI service: ${e.localizedMessage}"
                    )
                    repository.insertMessage(errorMsg)
                } finally {
                    _isAiTyping.value = false
                }
            }
        }
    }

    // Send Voice Note
    fun sendVoiceMessage(voiceBytes: ByteArray) {
        val current = _currentUser.value ?: return
        val recipient = _currentChatRecipient.value ?: return
        viewModelScope.launch {
            val msg = MessageEntity(
                senderId = current.userId,
                senderName = current.fullName,
                senderRole = current.role,
                receiverId = recipient.userId,
                text = "[Voice Note / رسالة صوتية]",
                voiceBytes = voiceBytes
            )
            repository.insertMessage(msg)
            // Play a subtle confirm tone
            try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_ACK, 150)
            } catch (e: Exception) {
                // Ignore
            }

            // AI Bot Voice Response
            if (recipient.userId == "ai_bot") {
                _isAiTyping.value = true
                delay(1000)
                val responseMsg = MessageEntity(
                    senderId = "ai_bot",
                    senderName = if (_currentLanguage.value == "ar") "مساعد مدرسة WE الذكي (AI)" else "WE School AI Assistant",
                    senderRole = "AI_BOT",
                    receiverId = current.userId,
                    text = if (_currentLanguage.value == "ar") "لقد استلمت رسالتك الصوتية! ولكنني أفضل تصفح الأسئلة النصية حالياً، يرجى كتابة سؤالك لأتمكن من مساعدتك بدقة." else "I received your voice message! However, I currently work best with text. Please write your question so I can assist you accurately."
                )
                repository.insertMessage(responseMsg)
                _isAiTyping.value = false
            }
        }
    }

    // Check if GPS is enabled based on rules: Sunday to Thursday, 7:30 AM to 3:00 PM
    fun isGpsActiveRightNow(): Boolean {
        val calendar = Calendar.getInstance()
        val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        
        // Sunday (1) to Thursday (5) in Calendar is:
        // Sunday = 1, Monday = 2, Tuesday = 3, Wednesday = 4, Thursday = 5, Friday = 6, Saturday = 7
        val isSchoolDay = dayOfWeek in Calendar.SUNDAY..Calendar.THURSDAY
        
        val currentMinutes = hour * 60 + minute
        val startMinutes = 7 * 60 + 30 // 07:30
        val endMinutes = 15 * 60      // 15:00
        val isSchoolHours = currentMinutes in startMinutes..endMinutes

        return isSchoolDay && isSchoolHours
    }

    // Sign in with Firebase Email & Password
    fun signInWithFirebaseEmail(
        email: String,
        pass: String,
        role: String = "PARENT",
        onResult: (Boolean, String?) -> Unit
    ) {
        if (email.isBlank() || pass.isBlank()) {
            onResult(false, "يرجى كتابة البريد الإلكتروني وكلمة المرور")
            return
        }
        viewModelScope.launch {
            try {
                firebaseAuth.signInWithEmailAndPassword(email.trim(), pass.trim())
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val fbUser = firebaseAuth.currentUser
                            val uid = fbUser?.uid ?: "user_${System.currentTimeMillis()}"
                            viewModelScope.launch {
                                var user = repository.getUser(uid)
                                if (user == null) {
                                    val nameFromEmail = email.substringBefore("@").replace(".", " ").capitalize(Locale.getDefault())
                                    user = UserEntity(
                                        userId = uid,
                                        email = email,
                                        fullName = fbUser?.displayName ?: "مستخدم $nameFromEmail",
                                        phoneNumber = fbUser?.phoneNumber ?: "01000000000",
                                        role = role,
                                        isVerified = true,
                                        verificationStatus = "Verified via Firebase Auth"
                                    )
                                    repository.insertUser(user)
                                }
                                _currentUser.value = user
                                syncUserToFirebaseFirestore(user)
                                if (user.role == "PARENT" && !user.isRouteSet) {
                                    _currentScreen.value = "ROUTE_SETUP"
                                } else {
                                    _currentScreen.value = "DASHBOARD"
                                }
                                loadStudents()
                                onResult(true, null)
                            }
                        } else {
                            // If user not found, try sign up automatically
                            firebaseAuth.createUserWithEmailAndPassword(email.trim(), pass.trim())
                                .addOnCompleteListener { createTasks ->
                                    if (createTasks.isSuccessful) {
                                        val fbUser = firebaseAuth.currentUser
                                        val uid = fbUser?.uid ?: "user_${System.currentTimeMillis()}"
                                        viewModelScope.launch {
                                            val nameFromEmail = email.substringBefore("@").replace(".", " ").capitalize(Locale.getDefault())
                                            val newUser = UserEntity(
                                                userId = uid,
                                                email = email,
                                                fullName = "مستخدم $nameFromEmail",
                                                phoneNumber = "01000000000",
                                                role = role,
                                                isVerified = true,
                                                verificationStatus = "Verified via Firebase Auth"
                                            )
                                            repository.insertUser(newUser)
                                            _currentUser.value = newUser
                                            syncUserToFirebaseFirestore(newUser)
                                            if (role == "PARENT") {
                                                _currentScreen.value = "ROUTE_SETUP"
                                            } else {
                                                _currentScreen.value = "DASHBOARD"
                                            }
                                            loadStudents()
                                            onResult(true, null)
                                        }
                                    } else {
                                        val err = createTasks.exception?.localizedMessage ?: "فشل تسجيل الدخول عبر الفايربيس"
                                        onResult(false, err)
                                    }
                                }
                        }
                    }
            } catch (e: Exception) {
                onResult(false, e.message ?: "خطأ في الاتصال بالفايربيس")
            }
        }
    }

    // Profile Selection & Secure Authentication via Firebase Auth
    fun selectProfileAndAuthenticateFirebase(
        user: UserEntity,
        password: String = "123456",
        onResult: ((Boolean, String?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            repository.insertUser(user)
            _currentUser.value = user
            homeLocation.value = if (user.homeLat != null && user.homeLng != null) Pair(user.homeLat.toFloat(), user.homeLng.toFloat()) else null
            schoolLocation.value = if (user.schoolLat != null && user.schoolLng != null) Pair(user.schoolLat.toFloat(), user.schoolLng.toFloat()) else null

            // Authenticate session with Firebase Auth in background
            try {
                val emailToUse = if (user.email.contains("@")) user.email else "${user.userId}@wescol.edu.eg"
                firebaseAuth.signInWithEmailAndPassword(emailToUse, password)
                    .addOnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            firebaseAuth.createUserWithEmailAndPassword(emailToUse, password)
                                .addOnCompleteListener { createTasks ->
                                    if (!createTasks.isSuccessful) {
                                        firebaseAuth.signInAnonymously()
                                    }
                                }
                        }
                    }
            } catch (e: Exception) {
                Log.e("FirebaseProfileAuth", "Background Firebase auth sync: ${e.message}")
            }

            syncUserToFirebaseFirestore(user)

            if (user.role == "PARENT" && !user.isRouteSet) {
                _currentScreen.value = "ROUTE_SETUP"
            } else {
                _currentScreen.value = "DASHBOARD"
            }
            loadStudents()
            onResult?.invoke(true, null)
        }
    }

    // Helper to sync user profile to Firestore & Realtime DB
    private fun syncUserToFirebaseFirestore(user: UserEntity) {
        try {
            val userMap = mapOf(
                "userId" to user.userId,
                "email" to user.email,
                "fullName" to user.fullName,
                "phoneNumber" to user.phoneNumber,
                "role" to user.role,
                "studentGrade" to (user.studentGrade ?: ""),
                "linkedStudentId" to (user.linkedStudentId ?: ""),
                "isVerified" to user.isVerified,
                "verificationStatus" to user.verificationStatus,
                "lastLoginTimestamp" to System.currentTimeMillis()
            )
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.userId)
                .set(userMap)

            FirebaseDatabase.getInstance()
                .getReference("users")
                .child(user.userId)
                .setValue(userMap)
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Error syncing user: ${e.message}")
        }
    }

    // Sign out from Firebase Auth
    fun signOutFirebase() {
        try {
            firebaseAuth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseAuth", "Sign out error: ${e.message}")
        }
        _currentUser.value = null
        _currentScreen.value = "WELCOME"
    }

    // Sign in
    fun signInWithGoogle(userId: String): Boolean {
        viewModelScope.launch {
            val user = repository.getUser(userId)
            if (user != null) {
                _currentUser.value = user
                homeLocation.value = if (user.homeLat != null && user.homeLng != null) Pair(user.homeLat.toFloat(), user.homeLng.toFloat()) else null
                schoolLocation.value = if (user.schoolLat != null && user.schoolLng != null) Pair(user.schoolLat.toFloat(), user.schoolLng.toFloat()) else null
                
                // If Parent and route is not set, go to Route Setup
                if (user.role == "PARENT" && !user.isRouteSet) {
                    _currentScreen.value = "ROUTE_SETUP"
                } else {
                    _currentScreen.value = "DASHBOARD"
                }
            }
        }
        return true
    }

    // Register & Verify User via WhatsApp OTP & Firebase Firestore Sync
    fun verifyUserAndSaveToFirebase(
        userId: String,
        email: String,
        fullName: String,
        phoneNumber: String,
        role: String,
        linkedStudentId: String? = null,
        studentGrade: String? = null,
        studentAge: Int? = null,
        studentGender: String? = null
    ) {
        viewModelScope.launch {
            val newUser = UserEntity(
                userId = userId,
                email = email,
                fullName = fullName,
                phoneNumber = phoneNumber,
                role = role,
                linkedStudentId = linkedStudentId,
                studentGrade = studentGrade,
                studentAge = studentAge,
                studentGender = studentGender,
                isRouteSet = false,
                isVerified = true,
                verificationStatus = "Verified"
            )
            repository.insertUser(newUser)
            _currentUser.value = newUser

            // Automatic Firebase Firestore & Realtime Database sync
            try {
                val firestoreMap = mapOf(
                    "userId" to userId,
                    "email" to email,
                    "fullName" to fullName,
                    "phoneNumber" to phoneNumber,
                    "role" to role,
                    "status" to "Verified",
                    "verificationStatus" to "Verified",
                    "isVerified" to true,
                    "linkedStudentId" to (linkedStudentId ?: ""),
                    "studentGrade" to (studentGrade ?: ""),
                    "verifiedAtTimestamp" to System.currentTimeMillis(),
                    "verifiedVia" to "WhatsApp OTP Auto"
                )
                FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(userId)
                    .set(firestoreMap)

                FirebaseDatabase.getInstance()
                    .getReference("users")
                    .child(userId)
                    .setValue(firestoreMap)
            } catch (e: Exception) {
                Log.e("FirebaseVerify", "Firebase activation sync error: ${e.message}")
            }

            if (role == "PARENT") {
                _currentScreen.value = "ROUTE_SETUP"
            } else {
                _currentScreen.value = "DASHBOARD"
            }
            loadStudents()
        }
    }

    // Register User
    fun registerUser(
        userId: String,
        email: String,
        fullName: String,
        phoneNumber: String,
        role: String,
        linkedStudentId: String? = null,
        studentGrade: String? = null,
        studentAge: Int? = null,
        studentGender: String? = null
    ) {
        viewModelScope.launch {
            val newUser = UserEntity(
                userId = userId,
                email = email,
                fullName = fullName,
                phoneNumber = phoneNumber,
                role = role,
                linkedStudentId = linkedStudentId,
                studentGrade = studentGrade,
                studentAge = studentAge,
                studentGender = studentGender,
                isRouteSet = false
            )
            repository.insertUser(newUser)
            _currentUser.value = newUser

            if (role == "PARENT") {
                _currentScreen.value = "ROUTE_SETUP"
            } else {
                _currentScreen.value = "DASHBOARD"
            }
            loadStudents()
        }
    }

    // Route Setup completed
    fun completeRouteSetup(hLat: Float, hLng: Float, sLat: Float, sLng: Float) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val updatedUser = user.copy(
                homeLat = hLat.toDouble(),
                homeLng = hLng.toDouble(),
                schoolLat = sLat.toDouble(),
                schoolLng = sLng.toDouble(),
                isRouteSet = true
            )
            repository.insertUser(updatedUser)
            _currentUser.value = updatedUser
            
            // Link tracking coordinates for their student
            val studentId = user.linkedStudentId ?: "student_1"
            val initialStatus = StudentStatusEntity(
                studentId = studentId,
                currentLat = hLat.toDouble(),
                currentLng = hLng.toDouble(),
                isAtHome = true,
                isAtSchool = false,
                isDeviated = false
            )
            repository.insertStudentStatus(initialStatus)

            _currentScreen.value = "DASHBOARD"
        }
    }

    // Toggle simulation of the student moving
    fun toggleSimulation() {
        if (_isSimulating.value) {
            simulationJob?.cancel()
            _isSimulating.value = false
        } else {
            _isSimulating.value = true
            startTrackingSimulation()
        }
    }

    // Start automated movement simulation along the route with deviation
    private fun startTrackingSimulation() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            val studentConfigs = listOf(
                Triple("student_1", "يوسف أحمد عبد الرحمن", Pair(220f, 580f)),
                Triple("student_2", "ملك تامر محمد سعيد", Pair(180f, 540f)),
                Triple("student_3", "محمود إبراهيم الدسوقي", Pair(260f, 620f))
            )
            val schoolLoc = Pair(580f, 220f)

            // Log departure initially when starting simulation for all students
            studentConfigs.forEach { (id, name, _) ->
                recordCommuteLog(id, name, "07:30 AM", "Not Arrived Yet", "ON_WAY")
            }

            var currentStepIndex = 0
            val stepsCount = 11

            while (_isSimulating.value) {
                val t = currentStepIndex / 10f

                studentConfigs.forEach { (studentId, studentName, homeLoc) ->
                    // Linear interpolation from home to school
                    val x = homeLoc.first + t * (schoolLoc.first - homeLoc.first)
                    val y = homeLoc.second + t * (schoolLoc.second - homeLoc.second)

                    // Add a deviation specifically for student_1 at step 5 for demo, or none for others
                    val isDeviatingNow = (studentId == "student_1" && currentStepIndex == 5)
                    val finalX = if (isDeviatingNow) x + 120f else x
                    val finalY = if (isDeviatingNow) y + 120f else y

                    val isHome = currentStepIndex == 0
                    val isSchool = currentStepIndex == stepsCount - 1

                    val status = StudentStatusEntity(
                        studentId = studentId,
                        currentLat = finalX.toDouble(),
                        currentLng = finalY.toDouble(),
                        isAtHome = isHome,
                        isAtSchool = isSchool,
                        isDeviated = isDeviatingNow,
                        isGpsEnabled = isGpsActiveRightNow()
                    )
                    repository.insertStudentStatus(status)

                    // Trigger alerts/notifications & Log commute states
                    if (isDeviatingNow) {
                        addNotification(
                            ar = "🚨 انذار: انحرف الطالب $studentName عن مسار المدرسة المحدد وهو الآن باتجاه خاطئ!",
                            en = "🚨 Warning: Student $studentName has deviated from the designated school route!"
                        )
                        recordCommuteLog(studentId, studentName, "07:30 AM", "Not Arrived Yet", "DEVIATED")
                        // Trigger sound beep
                        try {
                            ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)
                        } catch (e: Exception) {}
                    } else if (isSchool) {
                        addNotification(
                            ar = "✅ تم الوصول: وصل الطالب $studentName إلى المدرسة بأمان.",
                            en = "✅ Arrived: Student $studentName reached school safely."
                        )
                        recordCommuteLog(studentId, studentName, "07:30 AM", "07:55 AM", "ARRIVED")
                    } else if (isHome && currentStepIndex > 0) {
                        addNotification(
                            ar = "🏠 تم الوصول: عاد الطالب $studentName إلى المنزل بأمان.",
                            en = "🏠 Arrived: Student $studentName returned home safely."
                        )
                    }
                }

                // Update Bus GPS position in Firebase Realtime Database
                val simLat = 31.2653 + (currentStepIndex * 0.002)
                val simLng = 32.3019 + (currentStepIndex * 0.003)
                val simProgress = (currentStepIndex / 10f) * 100f
                val simSpeed = if (currentStepIndex == 0 || currentStepIndex == 10) 0f else (32f + (currentStepIndex * 1.5f))
                val nextStopName = when (currentStepIndex) {
                    in 0..3 -> "حي الشرق - بورسعيد"
                    in 4..7 -> "شارع 23 يوليو - بورسعيد"
                    else -> "محيط مدرسة WE بورسعيد التكنولوجية"
                }
                updateBusLocationInFirebase(simLat, simLng, simSpeed, simProgress, nextStopName)

                delay(3000) // update every 3 seconds
                currentStepIndex = (currentStepIndex + 1) % stepsCount
            }
        }
    }

    private fun addNotification(ar: String, en: String) {
        val text = if (_currentLanguage.value == "ar") ar else en
        val updated = mutableListOf(text)
        updated.addAll(_systemNotifications.value)
        _systemNotifications.value = updated
    }

    // --- QR CODE & LINKING OPERATIONS ---
    fun linkStudentByQr(scannedStudentId: String) {
        val parent = _currentUser.value ?: return
        if (parent.role != "PARENT") return
        viewModelScope.launch {
            val studentUser = repository.getUser(scannedStudentId)
            if (studentUser != null && studentUser.role == "STUDENT") {
                val updatedParent = parent.copy(linkedStudentId = scannedStudentId)
                repository.insertUser(updatedParent)
                _currentUser.value = updatedParent
                
                // Set default locations if not set
                if (updatedParent.homeLat != null && updatedParent.homeLng != null) {
                    homeLocation.value = Pair(updatedParent.homeLat.toFloat(), updatedParent.homeLng.toFloat())
                }
                if (updatedParent.schoolLat != null && updatedParent.schoolLng != null) {
                    schoolLocation.value = Pair(updatedParent.schoolLat.toFloat(), updatedParent.schoolLng.toFloat())
                }

                addNotification(
                    ar = "✅ تم ربط الحساب بنجاح بابنك الطالب: ${studentUser.fullName}",
                    en = "✅ Successfully linked account to your student: ${studentUser.fullName}"
                )
            } else {
                addNotification(
                    ar = "❌ لم يتم العثور على طالب بهذا الرمز QR",
                    en = "❌ No student found with this scanned QR code"
                )
            }
        }
    }

    // --- PROFILE MANAGEMENT ---
    fun saveUserProfile(
        quadName: String,
        birthDate: String,
        hobby1: String,
        hobby2: String,
        hobby3: String,
        address: String,
        bio: String,
        avatarIndex: Int,
        isProfileHidden: Boolean
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val updatedUser = user.copy(
                quadName = quadName,
                birthDate = birthDate,
                hobby1 = hobby1,
                hobby2 = hobby2,
                hobby3 = hobby3,
                address = address,
                bio = bio,
                avatarIndex = avatarIndex,
                isProfileHidden = isProfileHidden
            )
            repository.insertUser(updatedUser)
            _currentUser.value = updatedUser
            
            addNotification(
                ar = "💾 تم حفظ بيانات الملف الشخصي بنجاح",
                en = "💾 Profile details updated successfully"
            )
            _currentScreen.value = "DASHBOARD"
            loadStudents()
        }
    }

    // Update another student's profile (authorized for Parents & Teachers)
    fun updateStudentProfileByAuthorizedUser(
        studentId: String,
        fullName: String,
        quadName: String,
        studentGrade: String,
        studentAge: Int,
        studentGender: String,
        birthDate: String,
        hobby1: String,
        hobby2: String,
        hobby3: String,
        address: String,
        bio: String,
        avatarIndex: Int
    ) {
        viewModelScope.launch {
            val existingStudent = repository.getUser(studentId)
            if (existingStudent != null) {
                val updated = existingStudent.copy(
                    fullName = fullName,
                    quadName = quadName,
                    studentGrade = studentGrade,
                    studentAge = studentAge,
                    studentGender = studentGender,
                    birthDate = birthDate,
                    hobby1 = hobby1,
                    hobby2 = hobby2,
                    hobby3 = hobby3,
                    address = address,
                    bio = bio,
                    avatarIndex = avatarIndex
                )
                repository.insertUser(updated)
                addNotification(
                    ar = "💾 تم تحديث بيانات الطالب (${fullName}) بنجاح",
                    en = "💾 Student details for (${fullName}) updated successfully"
                )
                loadStudents()
            }
        }
    }

    // Add a new student to a specific grade (authorized for Teachers)
    fun addStudentByTeacher(
        studentId: String,
        email: String,
        fullName: String,
        phoneNumber: String,
        studentGrade: String,
        studentAge: Int,
        studentGender: String,
        quadName: String,
        birthDate: String,
        hobby1: String,
        hobby2: String,
        hobby3: String,
        address: String,
        bio: String,
        avatarIndex: Int
    ) {
        viewModelScope.launch {
            val newUser = UserEntity(
                userId = studentId,
                email = email,
                fullName = fullName,
                phoneNumber = phoneNumber,
                role = "STUDENT",
                studentGrade = studentGrade,
                studentAge = studentAge,
                studentGender = studentGender,
                quadName = quadName,
                birthDate = birthDate,
                hobby1 = hobby1,
                hobby2 = hobby2,
                hobby3 = hobby3,
                address = address,
                bio = bio,
                avatarIndex = avatarIndex,
                isRouteSet = false
            )
            repository.insertUser(newUser)
            
            // Add a default student status
            val initialStatus = StudentStatusEntity(
                studentId = studentId,
                currentLat = 220.0,
                currentLng = 580.0,
                isAtHome = true,
                isAtSchool = false,
                isDeviated = false
            )
            repository.insertStudentStatus(initialStatus)
            
            addNotification(
                ar = "🆕 تم إضافة الطالب الجديد (${fullName}) بنجاح وتخصيص مسار افتراضي له",
                en = "🆕 New student (${fullName}) added successfully with default route"
            )
            loadStudents()
        }
    }

    // Bind teacher account to a grade via class code
    fun bindTeacherToGradeByCode(code: String) {
        val user = _currentUser.value ?: return
        if (user.role != "TEACHER") return
        
        val grade = when (code.uppercase().trim()) {
            "WE-G1-7392" -> "الصف الأول"
            "WE-G2-5814" -> "الصف الثاني"
            "WE-G3-9402" -> "الصف الثالث"
            else -> null
        }
        
        viewModelScope.launch {
            if (grade != null) {
                val updatedUser = user.copy(
                    teacherGrade = grade,
                    teacherClassCode = code.uppercase().trim()
                )
                repository.insertUser(updatedUser)
                _currentUser.value = updatedUser
                addNotification(
                    ar = "✅ تم تفعيل صلاحية متابعة طلاب: ${grade}",
                    en = "✅ Activated student tracking permission for: ${grade}"
                )
                loadStudents()
            } else {
                addNotification(
                    ar = "❌ رمز تفعيل الصف الدراسي غير صحيح",
                    en = "❌ Invalid class activation code"
                )
            }
        }
    }

    // Deactivate teacher tracking
    fun deactivateTeacherGrade() {
        val user = _currentUser.value ?: return
        if (user.role != "TEACHER") return
        viewModelScope.launch {
            val updatedUser = user.copy(
                teacherGrade = null,
                teacherClassCode = null
            )
            repository.insertUser(updatedUser)
            _currentUser.value = updatedUser
            addNotification(
                ar = "🔓 تم إلغاء تفعيل متابعة الصف",
                en = "🔓 Grade tracking deactivated"
            )
            loadStudents()
        }
    }

    // --- BLOCKING MANAGEMENT ---
    // A student cannot block or hide their own parent
    fun isParentOfCurrentUser(targetUserId: String): Boolean {
        val current = _currentUser.value ?: return false
        if (current.role != "STUDENT") return false
        // Find if target parent has current student as linked student
        var isParent = false
        _studentsList.value.forEach { u ->
            if (u.role == "PARENT" && u.linkedStudentId == current.userId && u.userId == targetUserId) {
                isParent = true
            }
        }
        // Also fallback check for hardcoded parent_1/student_1 pairing
        if (current.userId == "student_1" && targetUserId == "parent_1") return true
        return isParent
    }

    fun toggleBlockUser(targetUserId: String) {
        val current = _currentUser.value ?: return
        if (isParentOfCurrentUser(targetUserId)) {
            addNotification(
                ar = "⚠️ لا يمكنك حظر أو إخفاء ولي أمرك بعد ربط الحساب!",
                en = "⚠️ You cannot block or hide your parent once linked!"
            )
            return
        }

        viewModelScope.launch {
            val blockedList = current.blockedUserIds.split(",").filter { it.isNotEmpty() }.toMutableList()
            val isBlocked = blockedList.contains(targetUserId)
            if (isBlocked) {
                blockedList.remove(targetUserId)
                addNotification(
                    ar = "🔓 تم إلغاء حظر المستخدم بنجاح.",
                    en = "🔓 User unblocked successfully."
                )
            } else {
                blockedList.add(targetUserId)
                addNotification(
                    ar = "🚫 تم حظر المستخدم بنجاح.",
                    en = "🚫 User blocked successfully."
                )
            }
            val updatedUser = current.copy(blockedUserIds = blockedList.joinToString(","))
            repository.insertUser(updatedUser)
            _currentUser.value = updatedUser
            loadStudents()
        }
    }

    fun isUserBlocked(userId: String): Boolean {
        val current = _currentUser.value ?: return false
        val blockedList = current.blockedUserIds.split(",").filter { it.isNotEmpty() }
        return blockedList.contains(userId)
    }

    // --- TIMELINE OPERATIONS ---
    fun addTimelinePost(text: String) {
        val current = _currentUser.value ?: return
        viewModelScope.launch {
            val post = TimelinePostEntity(
                authorId = current.userId,
                authorName = current.fullName,
                authorRole = current.role,
                authorAvatarIndex = current.avatarIndex,
                text = text
            )
            repository.insertTimelinePost(post)
        }
    }

    fun deleteTimelinePost(post: TimelinePostEntity) {
        viewModelScope.launch {
            repository.deleteTimelinePost(post)
        }
    }

    // --- GROUP CHATS OPERATIONS ---
    fun createGroup(name: String, type: String) {
        val current = _currentUser.value ?: return
        val gid = "group_${Random.nextInt(1000, 9999)}"
        viewModelScope.launch {
            val newGroup = GroupEntity(
                groupId = gid,
                groupName = name,
                groupType = type,
                creatorId = current.userId,
                memberIds = current.userId // Creator starts as sole member
            )
            repository.insertGroup(newGroup)
            addNotification(
                ar = "👥 تم إنشاء المجموعة بنجاح: $name",
                en = "👥 Successfully created group: $name"
            )
        }
    }

    fun inviteUserToGroup(groupId: String, targetUserId: String) {
        viewModelScope.launch {
            val group = repository.getGroupById(groupId) ?: return@launch
            val members = group.memberIds.split(",").filter { it.isNotEmpty() }.toMutableList()
            if (!members.contains(targetUserId)) {
                members.add(targetUserId)
                val updatedGroup = group.copy(memberIds = members.joinToString(","))
                repository.insertGroup(updatedGroup)
                addNotification(
                    ar = "📩 تم إرسال دعوة بنجاح والانضمام للمجموعة.",
                    en = "📩 Successfully sent invitation and member joined."
                )
            }
        }
    }

    fun selectGroup(group: GroupEntity?) {
        _selectedGroup.value = group
        _groupMessages.value = emptyList()
        if (group != null) {
            viewModelScope.launch {
                repository.getGroupMessagesFlow(group.groupId).collect { msgs ->
                    _groupMessages.value = msgs
                }
            }
        }
    }

    fun sendGroupMessage(text: String) {
        val current = _currentUser.value ?: return
        val group = _selectedGroup.value ?: return
        viewModelScope.launch {
            val msg = GroupMessageEntity(
                groupId = group.groupId,
                senderId = current.userId,
                senderName = current.fullName,
                senderRole = current.role,
                senderAvatarIndex = current.avatarIndex,
                text = text
            )
            repository.insertGroupMessage(msg)
        }
    }

    // --- COMMUTE LOG HELPERS ---
    private fun recordCommuteLog(studentId: String, studentName: String, departure: String, arrival: String, status: String) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val log = CommuteLogEntity(
                studentId = studentId,
                studentName = studentName,
                date = dateStr,
                departureTime = departure,
                arrivalTime = arrival,
                status = status
            )
            repository.insertCommuteLog(log)
        }
    }

    // --- OBSERVE FLOWS ---
    private fun observeStudentStatuses() {
        viewModelScope.launch {
            repository.getAllStudentStatusesFlow().collect { list ->
                val mapping = list.associateBy { it.studentId }
                _studentStatuses.value = mapping
            }
        }
    }

    private fun observeCommuteLogs() {
        viewModelScope.launch {
            repository.getAllCommuteLogsFlow().collect { list ->
                _commuteLogs.value = list
            }
        }
    }

    private fun observeTimelinePosts() {
        viewModelScope.launch {
            repository.getAllTimelinePostsFlow().collect { list ->
                _timelinePosts.value = list
            }
        }
    }

    private fun observeGroups() {
        viewModelScope.launch {
            repository.getAllGroupsFlow().collect { list ->
                _groupsList.value = list
            }
        }
    }

    private fun loadStudents() {
        viewModelScope.launch {
            repository.getAllStudentsFlow().collect { list ->
                _studentsList.value = list
            }
        }
    }

    private suspend fun seedInitialData() {
        // Seeding database default values for testing
        val existingStudents = repository.getUser("student_1")
        if (existingStudents != null) return // Already seeded

        // Teachers
        val teacher = UserEntity(
            userId = "teacher_1",
            email = "ahmed@wescol.edu.eg",
            fullName = "أ. أحمد عبد الرحمن",
            phoneNumber = "01099887766",
            role = "TEACHER",
            quadName = "أحمد عبد الرحمن السيد محمود",
            birthDate = "1988-05-12",
            hobby1 = "برمجة الروبوتات",
            hobby2 = "القراءة التكنولوجية",
            hobby3 = "كرة القدم",
            address = "بورسعيد، حي العرب، شارع صلاح سالم",
            bio = "معلم لمادة تكنولوجيا المعلومات والاتصالات بمدرسة WE بورسعيد التكنولوجية.",
            avatarIndex = 1,
            teacherGrade = "الصف الأول",
            teacherClassCode = "WE-G1-7392"
        )
        repository.insertUser(teacher)

        // Students
        val student1 = UserEntity(
            userId = "student_1",
            email = "yusuf@wescol.edu.eg",
            fullName = "يوسف أحمد عبد الرحمن",
            phoneNumber = "01233445566",
            role = "STUDENT",
            studentGrade = "الصف الأول",
            studentAge = 16,
            studentGender = "ذكر",
            quadName = "يوسف أحمد عبد الرحمن السيد",
            birthDate = "2010-09-24",
            hobby1 = "البرمجة بلغة الكوتلن",
            hobby2 = "صناعة الروبوتات",
            hobby3 = "رسم الكرتون",
            address = "بورسعيد، الزهور، عمارة ٤٥",
            bio = "طالب شغوف بالتكنولوجيا في الصف الأول بمدرسة WE بورسعيد.",
            avatarIndex = 2
        )
        repository.insertUser(student1)

        val student2 = UserEntity(
            userId = "student_2",
            email = "malak@wescol.edu.eg",
            fullName = "ملك تامر محمد سعيد",
            phoneNumber = "01277665544",
            role = "STUDENT",
            studentGrade = "الصف الثاني",
            studentAge = 17,
            studentGender = "أنثى",
            quadName = "ملك تامر محمد سعيد سليمان",
            birthDate = "2009-03-14",
            hobby1 = "تطوير تطبيقات أندرويد",
            hobby2 = "الذكاء الاصطناعي",
            hobby3 = "تصميم واجهات المستخدم UI/UX",
            address = "بورسعيد، حي الشرق، برج السلام",
            bio = "طالبة مبدعة بالصف الثاني بمدرسة WE بورسعيد التكنولوجية ومطورة التطبيق التجريبي.",
            avatarIndex = 4
        )
        repository.insertUser(student2)

        val student3 = UserEntity(
            userId = "student_3",
            email = "mahmoud@wescol.edu.eg",
            fullName = "محمود إبراهيم الدسوقي",
            phoneNumber = "01288990011",
            role = "STUDENT",
            studentGrade = "الصف الثالث",
            studentAge = 16,
            studentGender = "ذكر",
            quadName = "محمود إبراهيم الدسوقي خليل",
            birthDate = "2010-12-05",
            hobby1 = "أمن المعلومات",
            hobby2 = "شبكات الحاسب",
            hobby3 = "كرة السلة",
            address = "بورسعيد، بورفؤاد، حي الفيلات",
            bio = "طالب شغوف بالشبكات والأمن السيبراني بالصف الثالث بمدرسة WE بورسعيد.",
            avatarIndex = 0
        )
        repository.insertUser(student3)

        // Parents
        val parent = UserEntity(
            userId = "parent_1",
            email = "parent.yusuf@gmail.com",
            fullName = "أبو يوسف (ولي أمر)",
            phoneNumber = "01122334455",
            role = "PARENT",
            linkedStudentId = "student_1",
            homeLat = 220.0,
            homeLng = 580.0,
            schoolLat = 580.0,
            schoolLng = 220.0,
            isRouteSet = true,
            quadName = "أحمد عبد الرحمن السيد علي",
            birthDate = "1982-11-15",
            hobby1 = "القراءة",
            hobby2 = "الشطرنج",
            hobby3 = "تنس الطاولة",
            address = "بورسعيد، حي المناخ، برج التيسير",
            bio = "ولي أمر الطالب يوسف أحمد، حريص على متابعة المسار التعليمي والتنقل الآمن.",
            avatarIndex = 3
        )
        repository.insertUser(parent)

        // Seed initial student statuses
        repository.insertStudentStatus(
            StudentStatusEntity(
                studentId = "student_1",
                currentLat = 220.0,
                currentLng = 580.0,
                isAtHome = true,
                isAtSchool = false,
                isDeviated = false
            )
        )
        repository.insertStudentStatus(
            StudentStatusEntity(
                studentId = "student_2",
                currentLat = 180.0,
                currentLng = 540.0,
                isAtHome = true,
                isAtSchool = false,
                isDeviated = false
            )
        )
        repository.insertStudentStatus(
            StudentStatusEntity(
                studentId = "student_3",
                currentLat = 260.0,
                currentLng = 620.0,
                isAtHome = true,
                isAtSchool = false,
                isDeviated = false
            )
        )

        // Preseed initial direct message
        val systemMsg = MessageEntity(
            senderId = "teacher_1",
            senderName = "أ. أحمد عبد الرحمن",
            senderRole = "TEACHER",
            receiverId = "parent_1",
            text = "مرحباً بك في نظام مدرسة WE بورسعيد التكنولوجية. يمكننا التواصل هنا ومتابعة حضور ابنك يوسف بانتظام."
        )
        repository.insertMessage(systemMsg)

        // Preseed Timeline Posts
        val post1 = TimelinePostEntity(
            authorId = "teacher_1",
            authorName = "أ. أحمد عبد الرحمن",
            authorRole = "TEACHER",
            authorAvatarIndex = 1,
            text = "📢 تنبيه هام: غداً تبدأ امتحانات الـ Midterm العملية لجميع شعب الصف الأول والثاني بمدرسة WE بورسعيد. نرجو التواجد بحد أقصى الساعة 8:00 صباحاً."
        )
        val post2 = TimelinePostEntity(
            authorId = "parent_1",
            authorName = "أبو يوسف (ولي أمر)",
            authorRole = "PARENT",
            authorAvatarIndex = 3,
            text = "كل التوفيق والنجاح لجميع الطلاب والطالبات، شكراً جزيلاً لإدارة المدرسة على المتابعة والحرص المستمر 🌹"
        )
        repository.insertTimelinePost(post1)
        repository.insertTimelinePost(post2)

        // Preseed Groups
        val group1 = GroupEntity(
            groupId = "group_1",
            groupName = "جروب أولياء الأمور (WE Parents Group)",
            groupType = "PARENTS",
            creatorId = "teacher_1",
            memberIds = "teacher_1,parent_1"
        )
        val group2 = GroupEntity(
            groupId = "group_2",
            groupName = "رابطة الطلاب الموهوبين بمدرسة WE",
            groupType = "STUDENTS",
            creatorId = "student_1",
            memberIds = "student_1"
        )
        repository.insertGroup(group1)
        repository.insertGroup(group2)

        // Preseed historic logs
        recordCommuteLog("student_1", "يوسف أحمد عبد الرحمن", "07:31 AM", "07:54 AM", "ARRIVED")
        recordCommuteLog("student_1", "يوسف أحمد عبد الرحمن", "07:33 AM", "07:56 AM", "ARRIVED")
    }

    override fun onCleared() {
        super.onCleared()
        simulationJob?.cancel()
    }
}
