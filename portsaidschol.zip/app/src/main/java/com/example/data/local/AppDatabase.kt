package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.MessageDao
import com.example.data.local.dao.StudentStatusDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.CommuteLogDao
import com.example.data.local.dao.TimelinePostDao
import com.example.data.local.dao.GroupDao
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.StudentStatusEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.CommuteLogEntity
import com.example.data.local.entity.TimelinePostEntity
import com.example.data.local.entity.GroupEntity
import com.example.data.local.entity.GroupMessageEntity

@Database(
    entities = [
        UserEntity::class,
        MessageEntity::class,
        StudentStatusEntity::class,
        CommuteLogEntity::class,
        TimelinePostEntity::class,
        GroupEntity::class,
        GroupMessageEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun messageDao(): MessageDao
    abstract fun studentStatusDao(): StudentStatusDao
    abstract fun commuteLogDao(): CommuteLogDao
    abstract fun timelinePostDao(): TimelinePostDao
    abstract fun groupDao(): GroupDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "wescol_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
