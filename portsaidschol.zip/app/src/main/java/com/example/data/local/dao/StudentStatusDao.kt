package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.StudentStatusEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentStatusDao {
    @Query("SELECT * FROM student_statuses WHERE studentId = :studentId LIMIT 1")
    fun getStudentStatusFlow(studentId: String): Flow<StudentStatusEntity?>

    @Query("SELECT * FROM student_statuses WHERE studentId = :studentId LIMIT 1")
    suspend fun getStudentStatus(studentId: String): StudentStatusEntity?

    @Query("SELECT * FROM student_statuses")
    fun getAllStudentStatusesFlow(): Flow<List<StudentStatusEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentStatus(status: StudentStatusEntity)
}
