package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String,
    val email: String,
    val fullName: String,
    val phoneNumber: String,
    val role: String, // "PARENT", "TEACHER", "STUDENT"
    
    // Parent specific
    val linkedStudentId: String? = null,
    val homeLat: Double? = null,
    val homeLng: Double? = null,
    val schoolLat: Double? = null,
    val schoolLng: Double? = null,
    val isRouteSet: Boolean = false,
    
    // Student specific
    val studentGrade: String? = null, // "الصف الأول", "الصف الثاني", "الصف الثالث"
    val studentAge: Int? = null,
    val studentGender: String? = null, // "ذكر" / "أنثى"
    
    // Extended profile details (User editable)
    val quadName: String? = null, // الاسم رباعي
    val birthDate: String? = null, // تاريخ الميلاد
    val hobby1: String? = null,
    val hobby2: String? = null,
    val hobby3: String? = null,
    val address: String? = null, // العنوان
    val bio: String? = null, // سيرة ذاتية
    val avatarIndex: Int = 0, // Profile picture avatar index (0..5)
    val isProfileHidden: Boolean = false, // اخفاء الصفحة الشخصية عن بقية الطلاب
    val blockedUserIds: String = "", // List of blocked userIds separated by comma e.g. "student_2,student_3"
    
    // Verification state (WhatsApp OTP & Firebase)
    val isVerified: Boolean = false,
    val verificationStatus: String = "غير مُفعل",

    // Teacher specific class tracking details
    val teacherGrade: String? = null, // "الصف الأول", "الصف الثاني", "الصف الثالث"
    val teacherClassCode: String? = null // Code to unlock tracking for their grade
)
