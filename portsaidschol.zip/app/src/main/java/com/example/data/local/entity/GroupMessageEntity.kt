package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "group_messages")
data class GroupMessageEntity(
    @PrimaryKey(autoGenerate = true) val messageId: Int = 0,
    val groupId: String,
    val senderId: String,
    val senderName: String,
    val senderRole: String,
    val senderAvatarIndex: Int = 0,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
