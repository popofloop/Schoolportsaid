package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.CommuteLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CommuteLogDao {
    @Query("SELECT * FROM commute_logs WHERE studentId = :studentId ORDER BY logId DESC")
    fun getCommuteLogsForStudentFlow(studentId: String): Flow<List<CommuteLogEntity>>

    @Query("SELECT * FROM commute_logs ORDER BY logId DESC")
    fun getAllCommuteLogsFlow(): Flow<List<CommuteLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommuteLog(log: CommuteLogEntity)

    @Query("DELETE FROM commute_logs")
    suspend fun deleteAllLogs()
}
