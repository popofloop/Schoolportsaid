package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.TimelinePostEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TimelinePostDao {
    @Query("SELECT * FROM timeline_posts ORDER BY timestamp DESC")
    fun getAllTimelinePostsFlow(): Flow<List<TimelinePostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: TimelinePostEntity)

    @Delete
    suspend fun deletePost(post: TimelinePostEntity)
}
