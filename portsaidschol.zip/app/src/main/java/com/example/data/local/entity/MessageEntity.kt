package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val messageId: Long = 0,
    val senderId: String,
    val senderName: String,
    val senderRole: String, // "PARENT", "TEACHER", "STUDENT"
    val receiverId: String, // Specific user ID or "ALL"
    val text: String,
    val voiceBytes: ByteArray? = null, // Holds raw voice bytes
    val timestamp: Long = System.currentTimeMillis()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as MessageEntity
        if (messageId != other.messageId) return false
        if (senderId != other.senderId) return false
        if (senderName != other.senderName) return false
        if (senderRole != other.senderRole) return false
        if (receiverId != other.receiverId) return false
        if (text != other.text) return false
        if (voiceBytes != null) {
            if (other.voiceBytes == null) return false
            if (!voiceBytes.contentEquals(other.voiceBytes)) return false
        } else if (other.voiceBytes != null) return false
        if (timestamp != other.timestamp) return false
        return true
    }

    override fun hashCode(): Int {
        var result = messageId.hashCode()
        result = 31 * result + senderId.hashCode()
        result = 31 * result + senderName.hashCode()
        result = 31 * result + senderRole.hashCode()
        result = 31 * result + receiverId.hashCode()
        result = 31 * result + text.hashCode()
        result = 31 * result + (voiceBytes?.contentHashCode() ?: 0)
        result = 31 * result + timestamp.hashCode()
        return result
    }
}
