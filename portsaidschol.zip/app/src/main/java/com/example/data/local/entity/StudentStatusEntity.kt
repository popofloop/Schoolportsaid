package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_statuses")
data class StudentStatusEntity(
    @PrimaryKey val studentId: String,
    val currentLat: Double,
    val currentLng: Double,
    val isAtSchool: Boolean = false,
    val isAtHome: Boolean = false,
    val isDeviated: Boolean = false,
    val isGpsEnabled: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis()
)
