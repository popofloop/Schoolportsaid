package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "commute_logs")
data class CommuteLogEntity(
    @PrimaryKey(autoGenerate = true) val logId: Int = 0,
    val studentId: String,
    val studentName: String,
    val date: String, // e.g. "2026-07-15"
    val departureTime: String, // e.g. "07:32 AM"
    val arrivalTime: String, // e.g. "07:55 AM" or "Not Arrived yet"
    val status: String // e.g. "ARRIVED", "ON_WAY", "DEVIATED"
)
