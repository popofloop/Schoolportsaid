package com.example.data.repository

import com.example.data.local.dao.MessageDao
import com.example.data.local.dao.StudentStatusDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.CommuteLogDao
import com.example.data.local.dao.TimelinePostDao
import com.example.data.local.dao.GroupDao
import com.example.data.local.entity.MessageEntity
import com.example.data.local.entity.StudentStatusEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.CommuteLogEntity
import com.example.data.local.entity.TimelinePostEntity
import com.example.data.local.entity.GroupEntity
import com.example.data.local.entity.GroupMessageEntity
import kotlinx.coroutines.flow.Flow

class SchoolRepository(
    private val userDao: UserDao,
    private val messageDao: MessageDao,
    private val studentStatusDao: StudentStatusDao,
    private val commuteLogDao: CommuteLogDao,
    private val timelinePostDao: TimelinePostDao,
    private val groupDao: GroupDao
) {
    // User functions
    fun getUserFlow(userId: String): Flow<UserEntity?> = userDao.getUserFlow(userId)
    suspend fun getUser(userId: String): UserEntity? = userDao.getUser(userId)
    fun getAllStudentsFlow(): Flow<List<UserEntity>> = userDao.getAllStudentsFlow()
    suspend fun insertUser(user: UserEntity) = userDao.insertUser(user)
    suspend fun deleteUser(userId: String) = userDao.deleteUser(userId)

    // Chat functions
    fun getChatMessagesFlow(userId1: String, userId2: String): Flow<List<MessageEntity>> =
        messageDao.getChatMessagesFlow(userId1, userId2)

    fun getAllMyMessagesFlow(userId: String): Flow<List<MessageEntity>> =
        messageDao.getAllMyMessagesFlow(userId)

    suspend fun insertMessage(message: MessageEntity) = messageDao.insertMessage(message)

    // GPS Status functions
    fun getStudentStatusFlow(studentId: String): Flow<StudentStatusEntity?> =
        studentStatusDao.getStudentStatusFlow(studentId)

    suspend fun getStudentStatus(studentId: String): StudentStatusEntity? =
        studentStatusDao.getStudentStatus(studentId)

    fun getAllStudentStatusesFlow(): Flow<List<StudentStatusEntity>> =
        studentStatusDao.getAllStudentStatusesFlow()

    suspend fun insertStudentStatus(status: StudentStatusEntity) =
        studentStatusDao.insertStudentStatus(status)

    // Historical Commute Log functions
    fun getCommuteLogsForStudentFlow(studentId: String): Flow<List<CommuteLogEntity>> =
        commuteLogDao.getCommuteLogsForStudentFlow(studentId)

    fun getAllCommuteLogsFlow(): Flow<List<CommuteLogEntity>> =
        commuteLogDao.getAllCommuteLogsFlow()

    suspend fun insertCommuteLog(log: CommuteLogEntity) =
        commuteLogDao.insertCommuteLog(log)

    suspend fun deleteAllLogs() =
        commuteLogDao.deleteAllLogs()

    // Timeline functions
    fun getAllTimelinePostsFlow(): Flow<List<TimelinePostEntity>> =
        timelinePostDao.getAllTimelinePostsFlow()

    suspend fun insertTimelinePost(post: TimelinePostEntity) =
        timelinePostDao.insertPost(post)

    suspend fun deleteTimelinePost(post: TimelinePostEntity) =
        timelinePostDao.deletePost(post)

    // Group functions
    fun getAllGroupsFlow(): Flow<List<GroupEntity>> =
        groupDao.getAllGroupsFlow()

    suspend fun getGroupById(groupId: String): GroupEntity? =
        groupDao.getGroupById(groupId)

    suspend fun insertGroup(group: GroupEntity) =
        groupDao.insertGroup(group)

    fun getGroupMessagesFlow(groupId: String): Flow<List<GroupMessageEntity>> =
        groupDao.getGroupMessagesFlow(groupId)

    suspend fun insertGroupMessage(message: GroupMessageEntity) =
        groupDao.insertGroupMessage(message)
}
