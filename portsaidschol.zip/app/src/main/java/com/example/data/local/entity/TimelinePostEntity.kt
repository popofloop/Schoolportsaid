package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timeline_posts")
data class TimelinePostEntity(
    @PrimaryKey(autoGenerate = true) val postId: Int = 0,
    val authorId: String,
    val authorName: String,
    val authorRole: String,
    val authorAvatarIndex: Int = 0,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
