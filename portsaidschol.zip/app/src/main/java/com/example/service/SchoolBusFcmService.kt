package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.auth.FirebaseAuth

class SchoolBusFcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM Token generated: $token")
        saveTokenToFirebase(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message received from: ${remoteMessage.from}")

        val title = remoteMessage.notification?.title 
            ?: remoteMessage.data["title"] 
            ?: "تنبيه الحافلة المدرسية FCM 🚌"

        val body = remoteMessage.notification?.body 
            ?: remoteMessage.data["body"] 
            ?: "الحافلة المدرسية في الطريق إلى محطتك!"

        val busId = remoteMessage.data["busId"] ?: "BUS-101"
        val distance = remoteMessage.data["distanceMeters"]?.toFloatOrNull() ?: 500f

        showNotification(applicationContext, title, body, busId, distance)
    }

    companion object {
        private const val TAG = "SchoolBusFcmService"
        const val CHANNEL_ID = "bus_proximity_alerts_channel"
        const val CHANNEL_NAME = "تنبيهات اقتراب الحافلة المدرسية (FCM)"

        fun saveTokenToFirebase(token: String) {
            try {
                val currentUid = FirebaseAuth.getInstance().currentUser?.uid ?: "anonymous_device"
                val tokenData = mapOf(
                    "fcmToken" to token,
                    "updatedAt" to System.currentTimeMillis(),
                    "device" to "Android App"
                )
                FirebaseDatabase.getInstance()
                    .getReference("fcm_tokens")
                    .child(currentUid)
                    .setValue(tokenData)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save FCM token: ${e.message}")
            }
        }

        fun showNotification(
            context: Context,
            title: String,
            body: String,
            busId: String = "BUS-101",
            distanceMeters: Float = 0f
        ) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "إشعارات فايربيس (FCM) عند اقتراب الحافلة المدرسية من منزل الطالب"
                    enableVibration(true)
                    enableLights(true)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("screen", "BUS_TRACKING")
                putExtra("busId", busId)
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            val notificationId = (System.currentTimeMillis() % 10000).toInt()
            notificationManager.notify(notificationId, notification)
        }
    }
}
