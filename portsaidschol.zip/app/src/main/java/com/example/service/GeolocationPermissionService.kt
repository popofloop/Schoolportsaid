package com.example.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.example.data.local.entity.UserEntity
import java.util.Calendar

/**
 * Data class representing the evaluated status of Smart GPS tracking.
 */
data class SmartGpsStatus(
    val isActive: Boolean,
    val statusTitleAr: String,
    val statusTitleEn: String,
    val explanationAr: String,
    val explanationEn: String,
    val reasonCategory: String,
    val isSchoolHours: Boolean = false,
    val isSchoolDay: Boolean = false
)

/**
 * Service to handle device-level GPS permission requests, application-level
 * access authorization, and smart energy-saving background location logic.
 */
object GeolocationPermissionService {

    /**
     * Checks if physical GPS/location permission is granted on the device.
     */
    fun hasLocationPermission(context: Context): Boolean {
        val appContext = context.applicationContext
        val fineLocation = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        
        val coarseLocation = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        
        return fineLocation || coarseLocation
    }

    /**
     * Checks if the active user is a student and needs location permission.
     */
    fun shouldTriggerLocationRequestForUser(user: UserEntity?): Boolean {
        if (user == null) return false
        // Geolocation requests are specifically triggered for STUDENT accounts
        return user.role.uppercase() == "STUDENT"
    }

    /**
     * Business logic time & date checker function:
     * Validates whether the current time is between 7:00 AM and 4:00 PM,
     * and whether today is an official school day (Sunday through Thursday).
     * Automatically returns FALSE on Fridays, Saturdays, and official weekend holidays.
     */
    fun isSchoolHoursAndSchoolDay(calendar: Calendar = Calendar.getInstance()): Boolean {
        val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        // Sunday (1), Monday (2), Tuesday (3), Wednesday (4), Thursday (5) -> School Days
        // Friday (6), Saturday (7) -> Weekend / Holidays
        val isSchoolDay = dayOfWeek != Calendar.FRIDAY && dayOfWeek != Calendar.SATURDAY
        
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        
        // 7:00 AM (07:00) to 4:00 PM (16:00)
        val isSchoolHours = (hour in 7..15) || (hour == 16 && minute == 0)
        
        return isSchoolDay && isSchoolHours
    }

    /**
     * Evaluates Smart GPS Background Location status based on Role-Specific Rules:
     * 1. Student: Auto GPS runs ONLY 7:00 AM - 4:00 PM on school days (Sun-Thu). Auto-paused Fri/Sat and after hours.
     * 2. Parent: Exception! Location tracking is controlled manually via Parent Settings toggle without time cutoff.
     * 3. Driver: Bus GPS starts on trip launch and powers off completely when 'End Trip' is pressed.
     */
    fun evaluateSmartGpsStatus(
        role: String,
        parentManualToggle: Boolean = true,
        isDriverTripActive: Boolean = false,
        calendar: Calendar = Calendar.getInstance()
    ): SmartGpsStatus {
        val uppercaseRole = role.uppercase()
        val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
        val isSchoolDay = dayOfWeek != Calendar.FRIDAY && dayOfWeek != Calendar.SATURDAY
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val isSchoolHours = (hour in 7..15) || (hour == 16 && minute == 0)

        return when (uppercaseRole) {
            "STUDENT" -> {
                val active = isSchoolDay && isSchoolHours
                if (active) {
                    SmartGpsStatus(
                        isActive = true,
                        statusTitleAr = "🟢 التتبع الذكي للطلاب نشط أوتوماتيكياً",
                        statusTitleEn = "🟢 Automatic Student Tracking Active",
                        explanationAr = "يعمل الجي بي اس بالخلفية أوتوماتيكياً (أيام الدراسة: الأحد - الخميس | 07:00 ص - 04:00 م).",
                        explanationEn = "GPS runs in background automatically (School Days: Sun-Thu | 07:00 AM - 04:00 PM).",
                        reasonCategory = "STUDENT_AUTO",
                        isSchoolHours = isSchoolHours,
                        isSchoolDay = isSchoolDay
                    )
                } else {
                    val causeAr = if (!isSchoolDay) "العطلة الأسبوعية (الجمعة/السبت)" else "خارج مواعيد الدراسة (المواعيد الرسمية 07:00 ص - 04:00 م)"
                    val causeEn = if (!isSchoolDay) "Weekend Off (Friday/Saturday)" else "Outside school hours (Official: 07:00 AM - 04:00 PM)"
                    SmartGpsStatus(
                        isActive = false,
                        statusTitleAr = "⏸️ التتبع متوقف أوتوماتيكياً (توفير الطاقة والبيانات)",
                        statusTitleEn = "⏸️ Tracking Auto-Paused (Battery & Data Saver)",
                        explanationAr = "تم إيقاف خدمة الموقع بالخلفية أوتوماتيكياً بسبب: $causeAr.",
                        explanationEn = "Background location auto-paused due to: $causeEn.",
                        reasonCategory = "STUDENT_AUTO",
                        isSchoolHours = isSchoolHours,
                        isSchoolDay = isSchoolDay
                    )
                }
            }
            "PARENT" -> {
                if (parentManualToggle) {
                    SmartGpsStatus(
                        isActive = true,
                        statusTitleAr = "⚙️ تتبع ولي الأمر: مفعل يدوياً (مستثنى من التوقف الآلي)",
                        statusTitleEn = "⚙️ Parent Tracking: Manually Enabled (Exempt from auto-pause)",
                        explanationAr = "استثناء لولي الأمر: يستمر التتبع حسب اختيارك اليدوي في الإعدادات دون التقيد بساعات الدراسة.",
                        explanationEn = "Parent Exception: Tracking remains active per your manual setting regardless of school hours.",
                        reasonCategory = "PARENT_MANUAL",
                        isSchoolHours = isSchoolHours,
                        isSchoolDay = isSchoolDay
                    )
                } else {
                    SmartGpsStatus(
                        isActive = false,
                        statusTitleAr = "🛑 تتبع ولي الأمر: معطل يدوياً من الإعدادات",
                        statusTitleEn = "🛑 Parent Tracking: Manually Disabled in Settings",
                        explanationAr = "تم إيقاف تتبع الجي بي اس بناءً على اختيارك اليدوي من مفتاح الإعدادات.",
                        explanationEn = "GPS tracking paused as requested manually from Parent Settings.",
                        reasonCategory = "PARENT_MANUAL",
                        isSchoolHours = isSchoolHours,
                        isSchoolDay = isSchoolDay
                    )
                }
            }
            "DRIVER" -> {
                if (isDriverTripActive) {
                    SmartGpsStatus(
                        isActive = true,
                        statusTitleAr = "🚌 تتبع الحافلة: نشط أثناء الرحلة المباشرة",
                        statusTitleEn = "🚌 Bus GPS: Active During Live Trip",
                        explanationAr = "يتم مشاركة موقع الحافلة والسرعة والمحطات أونلاين طوال فترة الرحلة المدرسية.",
                        explanationEn = "Live bus location, speed, and stops are shared during the trip.",
                        reasonCategory = "DRIVER_TRIP",
                        isSchoolHours = isSchoolHours,
                        isSchoolDay = isSchoolDay
                    )
                } else {
                    SmartGpsStatus(
                        isActive = false,
                        statusTitleAr = "🛑 تتبع الحافلة: مغلق تماماً (تم إنهاء الرحلة)",
                        statusTitleEn = "🛑 Bus GPS: Shut Down (Trip Ended)",
                        explanationAr = "تم إغلاق خدمة الجي بي اس تماماً للحفاظ على بطارية وموارد السائق عقب ضغط 'إنهاء الرحلة'.",
                        explanationEn = "GPS completely powered off after pressing 'End Trip' to save driver battery.",
                        reasonCategory = "DRIVER_TRIP",
                        isSchoolHours = isSchoolHours,
                        isSchoolDay = isSchoolDay
                    )
                }
            }
            else -> {
                SmartGpsStatus(
                    isActive = false,
                    statusTitleAr = "ℹ️ خدمة تحديد الموقع المعيارية",
                    statusTitleEn = "ℹ️ Standard Location Service",
                    explanationAr = "وضع تحديد الموقع القياسي.",
                    explanationEn = "Standard location service mode.",
                    reasonCategory = "STANDARD",
                    isSchoolHours = isSchoolHours,
                    isSchoolDay = isSchoolDay
                )
            }
        }
    }

    /**
     * Business logic authorization check:
     * Ensures student tracking data is ONLY accessible to authorized viewers (i.e. linked parent or teacher).
     */
    fun isTrackingAuthorized(viewer: UserEntity?, targetStudentId: String, targetStudentGrade: String? = null): Boolean {
        if (viewer == null) return false
        
        val viewerRole = viewer.role.uppercase()
        val viewerId = viewer.userId
        
        return when (viewerRole) {
            "STUDENT" -> {
                // A student can ONLY access their own tracking data
                viewerId == targetStudentId
            }
            "PARENT" -> {
                // A parent can ONLY access the tracking data of their explicitly linked student profile
                viewer.linkedStudentId == targetStudentId
            }
            "TEACHER" -> {
                // A teacher is authorized to track students of their grade only
                viewer.teacherGrade != null && viewer.teacherGrade == targetStudentGrade
            }
            else -> false
        }
    }
}

